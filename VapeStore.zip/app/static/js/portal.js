/* VapeStore Worker Portal — POS, Hours, Analytics */
const API = '';
const token = localStorage.getItem('token');
const user = JSON.parse(localStorage.getItem('user') || '{}');
const store = JSON.parse(localStorage.getItem('store') || '{}');
const headers = { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };

// ── Cart State ──
let cart = [];
let lastReceipt = null;
let posMode = 'venta'; // 'venta' or 'refund'
let currentSalesFilter = 'all'; // 'all', 'paid', 'refunded'

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
    if (!token) { window.location.href = '/pin-login'; return; }
    document.getElementById('userName').textContent = user.name || '';
    document.getElementById('userAvatar').textContent = (user.name || '?')[0].toUpperCase();
    document.getElementById('storeName').textContent = store.name || 'Sin tienda';

    // Search on Enter
    document.getElementById('posSearch').addEventListener('keydown', e => {
        if (e.key === 'Enter') searchProducts();
    });

    loadRecentSales();
    loadHoursSummary();
    loadShifts();
});

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('store');
    window.location.href = '/pin-login';
}

// ── Tab Switching ──
function switchTab(tab) {
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.portal-nav button').forEach(b => b.classList.remove('active'));
    document.getElementById(`tab-${tab}`).classList.add('active');
    document.getElementById(`nav-${tab}`).classList.add('active');

    if (tab === 'hours') { loadHoursSummary(); loadShifts(); renderCalendar(); }
    if (tab === 'analytics') loadAnalytics();
    if (tab === 'pos') loadRecentSales();
}

// ── Mode Toggle (Venta / Reembolso) ──
function setMode(mode) {
    posMode = mode;
    const ventaBtn = document.getElementById('modeVenta');
    const refundBtn = document.getElementById('modeRefund');
    const cartSection = document.getElementById('cartSection');

    if (mode === 'venta') {
        ventaBtn.className = 'mode-btn active';
        refundBtn.className = 'mode-btn';
        cartSection.classList.remove('refund-mode');
        document.getElementById('posSearch').placeholder = '🔍 Buscar producto o escanear código...';
    } else {
        ventaBtn.className = 'mode-btn';
        refundBtn.className = 'mode-btn refund-active';
        cartSection.classList.add('refund-mode');
        document.getElementById('posSearch').placeholder = '🔄 Buscar producto a reembolsar...';
    }
    // Clear cart when switching modes
    cart = [];
    renderCart();
    document.getElementById('posResults').innerHTML = '';
}

// ══════════════════════════════════════════════
// POS — Search & Scan
// ══════════════════════════════════════════════

async function searchProducts() {
    const q = document.getElementById('posSearch').value.trim();
    if (!q) return;

    const container = document.getElementById('posResults');
    container.innerHTML = '<p style="color:var(--text-secondary);text-align:center">Buscando...</p>';

    try {
        const sid = store.id ? `&store_id=${store.id}` : '';
        const res = await fetch(`${API}/api/worker/products/search?q=${encodeURIComponent(q)}${sid}`, { headers });
        const data = await res.json();

        if (data.products.length === 0) {
            container.innerHTML = '<p style="color:var(--text-secondary);text-align:center;padding:20px">No se encontraron productos</p>';
            return;
        }

        container.innerHTML = data.products.map(p => `
            <div class="pos-product-card" onclick="addToCart(${p.id}, '${esc(p.name)}', ${p.price}, ${p.stock})">
                <div class="product-info">
                    <div class="product-name">${esc(p.name)}</div>
                    <div class="product-meta">${esc(p.brand_name || '')} ${esc(p.model_name || '')} · ${esc(p.category_name || '')}</div>
                </div>
                <div style="text-align:right">
                    <div class="product-price">$${p.price.toFixed(2)}</div>
                    <div class="product-stock">Stock: ${p.stock}</div>
                </div>
            </div>
        `).join('');

        // Also try barcode exact match
        if (q.length >= 6) {
            try {
                const scanRes = await fetch(`${API}/api/worker/products/scan/${q}${store.id ? '?store_id=' + store.id : ''}`, { headers });
                if (scanRes.ok) {
                    const product = await scanRes.json();
                    // Add to cart directly if barcode match
                    const existing = cart.find(i => i.id === product.id);
                    if (!existing) {
                        addToCart(product.id, product.name, product.price, product.stock);
                        container.innerHTML = `<div style="text-align:center;padding:8px;color:var(--success,#22c55e)">✅ Escaneado: ${esc(product.name)}</div>` + container.innerHTML;
                    }
                }
            } catch (e) { /* not a barcode */ }
        }
    } catch (e) {
        container.innerHTML = `<p style="color:var(--danger,#ef4444);text-align:center">Error: ${e.message}</p>`;
    }
}

// ══════════════════════════════════════════════
// POS — Cart
// ══════════════════════════════════════════════

function addToCart(id, name, price, stock) {
    const existing = cart.find(i => i.id === id);
    if (existing) {
        if (existing.qty >= stock) { showToast(`Stock máximo: ${stock}`); return; }
        existing.qty++;
    } else {
        cart.push({ id, name, price, stock, qty: 1 });
    }
    renderCart();
    document.getElementById('posSearch').value = '';
    document.getElementById('posResults').innerHTML = '';
}

function removeFromCart(id) {
    cart = cart.filter(i => i.id !== id);
    renderCart();
}

function updateQty(id, delta) {
    const item = cart.find(i => i.id === id);
    if (!item) return;
    item.qty = Math.max(1, Math.min(item.stock, item.qty + delta));
    renderCart();
}

function renderCart() {
    const section = document.getElementById('cartSection');
    if (cart.length === 0) { section.style.display = 'none'; return; }
    section.style.display = 'block';

    const isRefund = posMode === 'refund';
    const qtyDisplay = isRefund ? qty => `-${qty}` : qty => `${qty}`;

    document.getElementById('cartCount').textContent = cart.reduce((s, i) => s + Math.abs(i.qty), 0);

    document.getElementById('cartItems').innerHTML = cart.map(i => `
        <div class="cart-item">
            <div class="item-details">
                <div class="item-name">${esc(i.name)}</div>
                <div class="item-unit-price">$${i.price.toFixed(2)} c/u</div>
            </div>
            <div class="qty-controls">
                <button class="qty-btn" onclick="updateQty(${i.id}, -1)">−</button>
                <span class="qty-value" style="${isRefund ? 'color:var(--danger,#ef4444)' : ''}">${qtyDisplay(Math.abs(i.qty))}</span>
                <button class="qty-btn" onclick="updateQty(${i.id}, 1)">+</button>
            </div>
            <div class="item-total" style="${isRefund ? 'color:var(--danger,#ef4444)' : ''}">$${(i.price * i.qty).toFixed(2)}</div>
            <button class="item-remove" onclick="removeFromCart(${i.id})">✕</button>
        </div>
    `).join('');

    const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
    const tax = subtotal * 0.13;
    const total = subtotal + tax;

    document.getElementById('cartSubtotal').textContent = `$${subtotal.toFixed(2)}`;
    document.getElementById('cartTax').textContent = `$${tax.toFixed(2)}`;
    document.getElementById('cartTotal').textContent = `$${total.toFixed(2)}`;

    // Update payment buttons for mode
    const payCash = document.getElementById('payCash');
    const payCard = document.getElementById('payCard');
    const paySplit = document.getElementById('paySplit');
    if (isRefund) {
        payCash.innerHTML = '🔄 Reembolso';
        payCash.className = 'pay-btn refund';
        payCard.style.display = 'none';
        paySplit.style.display = 'none';
    } else {
        payCash.innerHTML = '💵 Efectivo';
        payCash.className = 'pay-btn cash';
        payCard.style.display = '';
        payCard.innerHTML = '💳 Tarjeta';
        paySplit.style.display = '';
    }
}

// ══════════════════════════════════════════════
// POS — Payment
// ══════════════════════════════════════════════

async function processPayment(method) {
    if (cart.length === 0) return;

    const isRefund = posMode === 'refund';
    const btn = document.getElementById('payCash');
    btn.disabled = true;
    btn.innerHTML = '<span>⏳</span> Procesando...';

    try {
        const endpoint = isRefund ? `${API}/api/worker/pos/refund-items` : `${API}/api/worker/pos/checkout`;
        const body = isRefund
            ? { items: cart.map(i => ({ product_option_id: i.id, quantity: Math.abs(i.qty) })), reason: document.getElementById('customerName').value.trim() || 'Reembolso desde POS' }
            : { items: cart.map(i => ({ product_option_id: i.id, quantity: i.qty })), payment_method: method, tax_rate: 0.13, customer_name: document.getElementById('customerName').value.trim() || null };

        const res = await fetch(endpoint, {
            method: 'POST',
            headers,
            body: JSON.stringify(body),
        });

        if (!res.ok) {
            const err = await res.json();
            showToast(err.detail || 'Error al procesar', 'error');
            btn.disabled = false;
            btn.innerHTML = isRefund ? '🔄 Reembolso' : (method === 'cash' ? '💵 Efectivo' : '💳 Tarjeta');
            return;
        }

        const data = await res.json();
        if (isRefund) {
            showToast(`Reembolso de $${data.total.toFixed(2)} procesado ✅`);
            cart = [];
            renderCart();
            document.getElementById('customerName').value = '';
            loadRecentSales();
        } else {
            lastReceipt = data;
            showReceipt(data);
            cart = [];
            renderCart();
            document.getElementById('customerName').value = '';
            loadRecentSales();
        }
    } catch (e) {
        showToast(`Error: ${e.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.innerHTML = isRefund ? '🔄 Reembolso' : (method === 'cash' ? '💵 Efectivo' : '💳 Tarjeta');
    }
}

function showReceipt(data) {
    const overlay = document.getElementById('receiptOverlay');
    document.getElementById('receiptDetails').innerHTML = `
        <div class="row"><span>Orden #</span><span>${data.order_id}</span></div>
        <div class="row"><span>Subtotal</span><span>$${data.subtotal.toFixed(2)}</span></div>
        <div class="row"><span>Impuesto</span><span>$${data.tax.toFixed(2)}</span></div>
        ${data.discount > 0 ? `<div class="row"><span>Descuento</span><span>-$${data.discount.toFixed(2)}</span></div>` : ''}
        <div class="row" style="font-weight:700;font-size:16px;margin-top:8px"><span>Total</span><span>$${data.total.toFixed(2)}</span></div>
        <div class="row"><span>Método</span><span>${data.payment_method === 'cash' ? '💵 Efectivo' : '💳 Tarjeta'}</span></div>
        <div class="row"><span>Puntos ganados</span><span>⭐ ${data.points_earned}</span></div>
        <div style="margin-top:12px;font-size:12px;color:var(--text-secondary)">
            ${data.items.map(i => `${i.quantity}x ${i.product_name} @ $${i.unit_price.toFixed(2)}`).join('<br>')}
        </div>
    `;
    overlay.classList.add('show');
}

function closeReceipt() {
    document.getElementById('receiptOverlay').classList.remove('show');
    document.getElementById('posSearch').focus();
}

function goToDashboard() {
    window.location.href = '/portal';
}

function printReceipt() {
    if (!lastReceipt) return;
    const r = lastReceipt;
    const isSplit = r.payment_method === 'split';
    const payLabel = isSplit ? '💳💵 Mixto' : (r.payment_method === 'cash' ? '💵 Efectivo' : '💳 Tarjeta');

    const itemsHtml = r.items.map(i =>
        `<div style="display:flex;justify-content:space-between"><span>${i.quantity}x ${i.product_name}</span><span>$${i.line_total.toFixed(2)}</span></div>`
    ).join('');

    const printWindow = window.open('', '_blank', 'width=320,height=600');
    printWindow.document.write(`
        <html><head><title>Recibo #${r.order_id}</title>
        <style>
            body { font-family: 'Courier New', monospace; font-size: 12px; padding: 16px; max-width: 280px; margin: 0 auto; }
            .center { text-align: center; }
            .bold { font-weight: bold; }
            .line { border-top: 1px dashed #000; margin: 8px 0; }
            .row { display: flex; justify-content: space-between; }
            h2 { margin: 4px 0; font-size: 16px; }
            h3 { margin: 2px 0; font-size: 12px; font-weight: normal; }
        </style></head><body>
            <div class="center">
                <h2>🏪 VapeStore</h2>
                <h3>${store.name || 'Tienda'}</h3>
                <h3>${new Date().toLocaleDateString('es')} ${new Date().toLocaleTimeString('es', {hour:'2-digit',minute:'2-digit'})}</h3>
            </div>
            <div class="line"></div>
            <div class="center bold">ORDEN #${r.order_id}</div>
            <div class="line"></div>
            ${itemsHtml}
            <div class="line"></div>
            <div class="row"><span>Subtotal:</span><span>$${r.subtotal.toFixed(2)}</span></div>
            <div class="row"><span>Impuesto (13%):</span><span>$${r.tax.toFixed(2)}</span></div>
            ${r.discount > 0 ? `<div class="row"><span>Descuento:</span><span>-$${r.discount.toFixed(2)}</span></div>` : ''}
            <div class="row bold" style="font-size:14px;margin-top:4px"><span>TOTAL:</span><span>$${r.total.toFixed(2)}</span></div>
            <div class="line"></div>
            <div class="row"><span>Método:</span><span>${payLabel}</span></div>
            <div class="row"><span>Puntos ganados:</span><span>⭐ ${r.points_earned}</span></div>
            ${r.customer_name ? `<div class="row"><span>Cliente:</span><span>${r.customer_name}</span></div>` : ''}
            <div class="line"></div>
            <div class="center" style="margin-top:12px;font-size:10px">
                ¡Gracias por su compra!<br>Pipilacha.ca
            </div>
        </body></html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// ══════════════════════════════════════════════
// POS — Recent Sales
// ══════════════════════════════════════════════

function filterSales(filter) {
    currentSalesFilter = filter;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('filter' + filter.charAt(0).toUpperCase() + filter.slice(1)).classList.add('active');
    loadRecentSales();
}

async function loadRecentSales() {
    try {
        const sid = store.id ? `&store_id=${store.id}` : '';
        const statusParam = currentSalesFilter !== 'all' ? `&status=${currentSalesFilter}` : '';
        const res = await fetch(`${API}/api/worker/pos/recent-sales?limit=30${sid}${statusParam}`, { headers });
        const data = await res.json();
        const container = document.getElementById('recentSalesList');
        const section = document.getElementById('recentSalesSection');

        section.style.display = 'block';

        if (data.sales.length === 0) {
            container.innerHTML = '<div style="text-align:center;padding:16px;color:var(--text-secondary);font-size:13px">Sin transacciones</div>';
            return;
        }

        container.innerHTML = data.sales.slice(0, 10).map(s => {
            const customer = s.notes ? (s.notes.match(/cliente=(.+)/)?.[1] || '') : '';
            const isRefunded = s.status === 'refunded';
            return `
                <div class="shift-card" style="opacity:${isRefunded ? '0.5' : '1'};cursor:pointer" onclick="openOrderDetail(${s.id})">
                    <div>
                        <div class="shift-date">#${s.id} — ${formatDate(s.created_at)}${isRefunded ? ' <span style="color:var(--danger,#ef4444)">🔄 REEMBOLSADO</span>' : ''}</div>
                        <div class="shift-times">${customer ? '👤 ' + esc(customer) : (s.notes ? s.notes.split('|')[0].trim() : 'Venta')}</div>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px">
                        <div class="shift-hours" style="${isRefunded ? 'color:var(--danger,#ef4444)' : ''}">${isRefunded ? '-' : ''}$${Math.abs(s.total).toFixed(2)}</div>
                        ${!isRefunded ? `<button onclick="event.stopPropagation();openRefund(${s.id}, ${s.total})" style="padding:6px 10px;border-radius:8px;border:1px solid var(--danger,#ef4444);background:rgba(239,68,68,0.1);color:var(--danger,#ef4444);font-size:12px;cursor:pointer;white-space:nowrap">🔄</button>` : ''}
                    </div>
                </div>
            `;
        }).join('');
    } catch (e) { /* silent */ }
}

// ══════════════════════════════════════════════
// Hours
// ══════════════════════════════════════════════

let activeShiftId = null;

async function checkActiveShift() {
    try {
        const res = await fetch(`${API}/api/worker/shifts`, { headers });
        const data = await res.json();
        const active = data.shifts.find(s => !s.clock_out);
        const btn = document.getElementById('clockBtn');
        const text = document.getElementById('clockText');

        if (active) {
            activeShiftId = active.id;
            btn.className = 'clock-btn active-shift';
            text.textContent = 'Clock Out';
        } else {
            activeShiftId = null;
            btn.className = 'clock-btn in';
            text.textContent = 'Clock In';
        }
    } catch (e) { /* silent */ }
}

async function toggleClock() {
    const endpoint = activeShiftId ? 'clock-out' : 'clock-in';
    try {
        const res = await fetch(`${API}/api/worker/${endpoint}`, { method: 'POST', headers });
        const data = await res.json();
        showToast(data.message);
        checkActiveShift();
        loadHoursSummary();
        loadShifts();
    } catch (e) {
        const err = e.message ? {detail: e.message} : await e.json?.();
        showToast(err?.detail || 'Error', 'error');
    }
}

async function loadHoursSummary() {
    try {
        const res = await fetch(`${API}/api/worker/shifts/summary`, { headers });
        const data = await res.json();
        document.getElementById('hoursToday').textContent = `${data.today_hours}h`;
        document.getElementById('hoursWeek').textContent = `${data.week_hours}h`;
        document.getElementById('hoursMonth').textContent = `${data.month_hours}h`;
    } catch (e) { /* silent */ }
}

async function loadShifts() {
    try {
        const res = await fetch(`${API}/api/worker/shifts`, { headers });
        const data = await res.json();
        const container = document.getElementById('shiftsList');

        if (data.shifts.length === 0) {
            container.innerHTML = '<div class="empty-state"><div class="empty-icon">🕐</div><p>No hay turnos registrados</p></div>';
            return;
        }

        container.innerHTML = data.shifts.map(s => {
            const status = s.clock_out ? '✅' : '🟢 Activo';
            const hours = s.hours_worked ? `${s.hours_worked}h` : 'En curso...';
            return `
                <div class="shift-card">
                    <div>
                        <div class="shift-date">${formatDate(s.clock_in)}</div>
                        <div class="shift-times">${formatTime(s.clock_in)} → ${s.clock_out ? formatTime(s.clock_out) : '...'} ${status}</div>
                    </div>
                    <div class="shift-hours">${hours}</div>
                </div>
            `;
        }).join('');
    } catch (e) { /* silent */ }
}

// ══════════════════════════════════════════════
// Analytics
// ══════════════════════════════════════════════

async function loadAnalytics() {
    try {
        const res = await fetch(`${API}/api/worker/analytics`, { headers });
        const data = await res.json();

        // Stats cards
        document.getElementById('analyticsStats').innerHTML = `
            <div class="stat-card">
                <div class="stat-value">$${data.today.revenue?.toFixed(2) || '0.00'}</div>
                <div class="stat-label">Ventas hoy</div>
                <div class="stat-compare">${data.today.orders || 0} órdenes</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$${data.week.revenue?.toFixed(2) || '0.00'}</div>
                <div class="stat-label">Esta semana</div>
                <div class="stat-compare">${data.week.orders || 0} órdenes</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$${data.month.revenue?.toFixed(2) || '0.00'}</div>
                <div class="stat-label">Este mes</div>
                <div class="stat-compare">${data.month.orders || 0} órdenes</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">$${data.all_time.revenue?.toFixed(2) || '0.00'}</div>
                <div class="stat-label">Total histórico</div>
                <div class="stat-compare">${data.all_time.orders || 0} órdenes</div>
            </div>
        `;

        // Top products
        const topContainer = document.getElementById('topProductsList');
        if (data.top_products.length === 0) {
            topContainer.innerHTML = '<div class="empty-state"><div class="empty-icon">📦</div><p>Aún no hay ventas</p></div>';
        } else {
            topContainer.innerHTML = data.top_products.map((p, i) => `
                <div class="top-product-row">
                    <div class="rank">${i + 1}</div>
                    <div class="product-name">${esc(p.name)}</div>
                    <div class="product-qty">${p.qty} uds</div>
                    <div class="product-rev">$${p.revenue.toFixed(2)}</div>
                </div>
            `).join('');
        }

        // Payment methods
        const pmContainer = document.getElementById('paymentMethodsList');
        if (data.payment_methods.length === 0) {
            pmContainer.innerHTML = '<div class="empty-state"><p>Sin datos de pago</p></div>';
        } else {
            pmContainer.innerHTML = data.payment_methods.map(pm => `
                <div class="shift-card">
                    <div>
                        <div class="shift-date">${pm.method}</div>
                        <div class="shift-times">${pm.count} ventas</div>
                    </div>
                    <div class="shift-hours">$${pm.total.toFixed(2)}</div>
                </div>
            `).join('');
        }

        // Sales chart (doughnut with top products)
        renderSalesChart(data.sales_chart || [], data.top_products || []);
    } catch (e) {
        console.error('Analytics error:', e);
    }
}

// ══════════════════════════════════════════════
// Refund
// ══════════════════════════════════════════════

let pendingRefundId = null;

function openRefund(orderId, total) {
    pendingRefundId = orderId;
    document.getElementById('refundDetails').innerHTML = `
        <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span>Orden #</span><span>${orderId}</span></div>
        <div style="display:flex;justify-content:space-between;font-weight:700;color:var(--danger,#ef4444)"><span>Monto</span><span>$${total.toFixed(2)}</span></div>
        <div style="margin-top:8px;font-size:12px;color:var(--text-secondary)">Se restaurará el stock de todos los productos de esta orden.</div>
    `;
    document.getElementById('refundReason').value = '';
    document.getElementById('refundOverlay').classList.add('show');
}

function closeRefund() {
    pendingRefundId = null;
    document.getElementById('refundOverlay').classList.remove('show');
}

async function confirmRefund() {
    if (!pendingRefundId) return;
    const reason = document.getElementById('refundReason').value.trim();
    try {
        const res = await fetch(`${API}/api/worker/pos/refund`, {
            method: 'POST',
            headers,
            body: JSON.stringify({ order_id: pendingRefundId, reason: reason || 'Sin razón', full_refund: true }),
        });
        const data = await res.json();
        if (!res.ok) { showToast(data.detail || 'Error', 'error'); return; }
        showToast(`Reembolso de $${data.refund_amount.toFixed(2)} procesado ✅`);
        closeRefund();
        loadRecentSales();
    } catch (e) {
        showToast(`Error: ${e.message}`, 'error');
    }
}

// ══════════════════════════════════════════════
// Order Detail Modal
// ══════════════════════════════════════════════

async function openOrderDetail(orderId) {
    try {
        const res = await fetch(`${API}/api/worker/pos/order/${orderId}`, { headers });
        if (!res.ok) { showToast('Error al cargar detalle', 'error'); return; }
        const data = await res.json();
        const order = data.order;
        const items = data.items;
        const isRefunded = order.status === 'refunded';
        const customer = order.notes ? (order.notes.match(/cliente=(.+)/)?.[1] || '') : '';
        const paymentMethod = order.notes ? (order.notes.match(/cash|card|split/)?.[0] || '') : '';
        const splitInfo = order.notes ? (order.notes.match(/cash=(\S+) card=(\S+)/) || []) : [];

        document.getElementById('detailIcon').textContent = isRefunded ? '🔄' : '📋';
        document.getElementById('detailTitle').textContent = `Orden #${order.id}`;

        let itemsHtml = items.map(i => `
            <div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--glass-border)">
                <div>
                    <div style="font-weight:600">${esc(i.product_name || 'Producto')}</div>
                    <div style="font-size:11px;color:var(--text-secondary)">${i.quantity} x $${i.unit_price.toFixed(2)}</div>
                </div>
                <div style="font-weight:700">${isRefunded ? '-' : ''}$${Math.abs(i.quantity * i.unit_price).toFixed(2)}</div>
            </div>
        `).join('');

        document.getElementById('orderDetailContent').innerHTML = `
            <div style="display:flex;justify-content:space-between;margin-bottom:8px">
                <span style="color:var(--text-secondary)">Estado</span>
                <span style="font-weight:600;color:${isRefunded ? 'var(--danger,#ef4444)' : 'var(--success,#22c55e)'}">${isRefunded ? '🔄 REEMBOLSADO' : '✅ Pagado'}</span>
            </div>
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                <span style="color:var(--text-secondary)">Fecha</span>
                <span>${formatDate(order.created_at)} ${formatTime(order.created_at)}</span>
            </div>
            ${customer ? `<div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="color:var(--text-secondary)">Cliente</span><span>👤 ${esc(customer)}</span></div>` : ''}
            ${paymentMethod ? `<div style="display:flex;justify-content:space-between;margin-bottom:4px"><span style="color:var(--text-secondary)">Método</span><span>${paymentMethod === 'split' ? '💳💵 Mixto' : paymentMethod === 'cash' ? '💵 Efectivo' : '💳 Tarjeta'}${splitInfo.length > 2 ? ` (${splitInfo[1]} cash + ${splitInfo[2]} card)` : ''}</span></div>` : ''}
            <div style="display:flex;justify-content:space-between;margin-bottom:12px">
                <span style="color:var(--text-secondary)">Trabajador</span>
                <span>${esc(order.worker_name || '—')}</span>
            </div>
            <div style="border-top:1px solid var(--glass-border);padding-top:10px;margin-bottom:8px">
                <div style="font-weight:700;margin-bottom:6px">Productos</div>
                ${itemsHtml || '<div style="color:var(--text-secondary);font-size:12px">Sin detalles de productos</div>'}
            </div>
            <div style="border-top:1px solid var(--glass-border);padding-top:10px">
                <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span>Subtotal</span><span>$${Math.abs(order.total / 1.13).toFixed(2)}</span></div>
                <div style="display:flex;justify-content:space-between;margin-bottom:4px"><span>Impuesto (13%)</span><span>$${Math.abs(order.total - order.total / 1.13).toFixed(2)}</span></div>
                <div style="display:flex;justify-content:space-between;font-size:16px;font-weight:800;color:${isRefunded ? 'var(--danger,#ef4444)' : 'var(--accent)'}">
                    <span>${isRefunded ? 'Reembolsado' : 'Total'}</span>
                    <span>${isRefunded ? '-' : ''}$${Math.abs(order.total).toFixed(2)}</span>
                </div>
            </div>
        `;
        document.getElementById('orderDetailOverlay').classList.add('show');
    } catch (e) {
        showToast(`Error: ${e.message}`, 'error');
    }
}

function closeOrderDetail() {
    document.getElementById('orderDetailOverlay').classList.remove('show');
}

// ══════════════════════════════════════════════
// Split Payment
// ══════════════════════════════════════════════

function openSplitPayment() {
    if (cart.length === 0) { showToast('Carrito vacío', 'error'); return; }
    if (posMode === 'refund') { showToast('No aplica en modo reembolso', 'error'); return; }
    const total = cart.reduce((s, i) => s + i.price * i.qty, 0) * 1.13;
    document.getElementById('splitTotal').textContent = `$${total.toFixed(2)}`;
    document.getElementById('splitCash').value = '';
    document.getElementById('splitCard').value = '';
    document.getElementById('splitRemainder').textContent = `$${total.toFixed(2)}`;
    document.getElementById('splitConfirmBtn').disabled = true;
    document.getElementById('splitOverlay').classList.add('show');
}

function closeSplitPayment() {
    document.getElementById('splitOverlay').classList.remove('show');
}

function updateSplitRemainder() {
    const total = cart.reduce((s, i) => s + i.price * i.qty, 0) * 1.13;
    const cash = parseFloat(document.getElementById('splitCash').value) || 0;
    const card = parseFloat(document.getElementById('splitCard').value) || 0;
    const remainder = total - cash - card;
    const remainderEl = document.getElementById('splitRemainder');
    const confirmBtn = document.getElementById('splitConfirmBtn');

    remainderEl.textContent = `$${remainder.toFixed(2)}`;
    if (remainder < -0.01) {
        remainderEl.style.color = 'var(--danger, #ef4444)';
        confirmBtn.disabled = true;
    } else if (Math.abs(remainder) < 0.01) {
        remainderEl.style.color = 'var(--success, #22c55e)';
        confirmBtn.disabled = false;
    } else {
        remainderEl.style.color = 'var(--text-secondary)';
        confirmBtn.disabled = true;
    }
}

async function confirmSplitPayment() {
    if (cart.length === 0) return;
    const cash = parseFloat(document.getElementById('splitCash').value) || 0;
    const card = parseFloat(document.getElementById('splitCard').value) || 0;
    const btn = document.getElementById('splitConfirmBtn');
    btn.disabled = true;
    btn.textContent = '⏳ Procesando...';

    try {
        const res = await fetch(`${API}/api/worker/pos/checkout`, {
            method: 'POST',
            headers,
            body: JSON.stringify({
                items: cart.map(i => ({ product_option_id: i.id, quantity: i.qty })),
                payment_method: 'split',
                tax_rate: 0.13,
                customer_name: document.getElementById('customerName').value.trim() || null,
                split_cash: cash,
                split_card: card,
            }),
        });

        if (!res.ok) {
            const err = await res.json();
            showToast(err.detail || 'Error al procesar', 'error');
            return;
        }

        const data = await res.json();
        lastReceipt = data;
        showReceipt(data);
        cart = [];
        renderCart();
        document.getElementById('customerName').value = '';
        closeSplitPayment();
        loadRecentSales();
    } catch (e) {
        showToast(`Error: ${e.message}`, 'error');
    } finally {
        btn.disabled = false;
        btn.textContent = '💳💵 Pagar mixto';
    }
}

// ══════════════════════════════════════════════
// Sales Chart (Chart.js)
// ══════════════════════════════════════════════

let salesChartInstance = null;

function renderSalesChart(salesData, topProducts) {
    const canvas = document.getElementById('salesChart');
    if (!canvas) return;

    if (salesChartInstance) salesChartInstance.destroy();

    // Use top_products for doughnut (better visual than time-series bar on mobile)
    const products = (topProducts || []).slice(0, 8);
    if (products.length === 0) {
        canvas.style.display = 'none';
        return;
    }
    canvas.style.display = '';

    const palette = [
        '#6C5CE7', '#00B894', '#E17055', '#0984E3',
        '#FDCB6E', '#E84393', '#00CEC9', '#A29BFE'
    ];

    const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#6C5CE7';
    const textColor = getComputedStyle(document.documentElement).getPropertyValue('--text-primary').trim() || '#333';

    salesChartInstance = new Chart(canvas, {
        type: 'doughnut',
        data: {
            labels: products.map(p => p.name),
            datasets: [{
                data: products.map(p => p.revenue),
                backgroundColor: palette.slice(0, products.length),
                borderColor: 'transparent',
                borderWidth: 2,
                hoverOffset: 8,
            }],
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            cutout: '55%',
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: textColor,
                        padding: 12,
                        font: { size: 11 },
                        usePointStyle: true,
                        pointStyleWidth: 10,
                    },
                },
                tooltip: {
                    callbacks: {
                        label: ctx => ` $${ctx.parsed.toFixed(2)}`
                    }
                },
            },
        },
    });
}

// ── Helpers ──
function esc(s) { if (!s) return ''; const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }

function formatDate(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString('es', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' });
}

// ── Calendar ──
let calWeekStart = getMonday(new Date());

function getMonday(d) {
    const date = new Date(d);
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    date.setDate(diff);
    date.setHours(0, 0, 0, 0);
    return date;
}

function addDays(d, n) {
    const r = new Date(d);
    r.setDate(r.getDate() + n);
    return r;
}

function fmtDateISO(d) {
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function fmtDayLabel(d) {
    const days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
    return days[(d.getDay() + 6) % 7];
}

function calPrev() { calWeekStart = addDays(calWeekStart, -7); renderCalendar(); }
function calNext() { calWeekStart = addDays(calWeekStart, 7); renderCalendar(); }

async function renderCalendar() {
    const grid = document.getElementById('portalCalendar');
    if (!grid) return;

    const startDate = fmtDateISO(calWeekStart);
    const endDate = fmtDateISO(addDays(calWeekStart, 6));

    // Week label
    const monthNames = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    const s = calWeekStart;
    const e = addDays(calWeekStart, 6);
    document.getElementById('calWeekLabel').textContent =
        `${s.getDate()} ${monthNames[s.month]} — ${e.getDate()} ${monthNames[e.month]} ${e.getFullYear()}`;

    try {
        const res = await fetch(`${API}/api/worker/shifts?start=${startDate}T00:00:00&end=${endDate}T23:59:59`, { headers });
        const data = await res.json();
        const shifts = data.shifts || [];

        // Build days array
        const days = [];
        for (let i = 0; i < 7; i++) days.push(addDays(calWeekStart, i));

        const todayStr = fmtDateISO(new Date());
        const todayIdx = days.findIndex(d => fmtDateISO(d) === todayStr);

        // Build shift map: dateStr → shift
        const shiftMap = {};
        shifts.forEach(s => {
            if (!s.clock_in) return;
            const d = new Date(s.clock_in);
            const key = fmtDateISO(d);
            shiftMap[key] = s;
        });

        let html = '';
        // Header
        html += '<div class="cal-cell header"></div>';
        days.forEach((d, i) => {
            const cls = i === todayIdx ? 'cal-cell header today' : 'cal-cell header';
            html += `<div class="${cls}">${fmtDayLabel(d)}<br>${d.getDate()}</div>`;
        });

        // Shift row
        html += '<div class="cal-cell" style="font-size:10px;color:var(--text-secondary)">Turnos</div>';
        let weekHours = 0;
        days.forEach((d, i) => {
            const key = fmtDateISO(d);
            const shift = shiftMap[key];
            const cls = i === todayIdx ? 'cal-cell today' : 'cal-cell';

            if (shift) {
                const isActive = !shift.clock_out;
                const shiftCls = isActive ? 'cal-shift active' : 'cal-shift';
                const ci = new Date(shift.clock_in);
                const timeIn = ci.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' });
                let timeOut = '...';
                if (shift.clock_out) {
                    const co = new Date(shift.clock_out);
                    timeOut = co.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' });
                    weekHours += shift.hours_worked || 0;
                }
                const hours = shift.hours_worked ? parseFloat(shift.hours_worked).toFixed(1) + 'h' : 'Activo';
                html += `<div class="${cls}"><div class="${shiftCls}"><div class="shift-time">${timeIn}-${timeOut}</div><div class="shift-hours">${hours}</div></div></div>`;
            } else {
                html += `<div class="${cls}"><span class="cal-empty">—</span></div>`;
            }
        });

        grid.innerHTML = html;
    } catch (e) {
        grid.innerHTML = '<div style="padding:10px;text-align:center;color:var(--text-secondary)">Error al cargar calendario</div>';
    }
}

function showToast(msg, type = 'success') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position:fixed;top:80px;left:50%;transform:translateX(-50%);z-index:300;
        padding:12px 24px;border-radius:12px;font-size:14px;font-weight:600;
        background:${type === 'error' ? 'var(--danger,#ef4444)' : 'var(--success,#22c55e)'};
        color:white;backdrop-filter:blur(10px);animation:fadeIn 0.2s;
    `;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

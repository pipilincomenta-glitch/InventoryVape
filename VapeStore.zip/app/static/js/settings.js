/* ═══════════════════════════════════════════════════
   VapeStore - Settings Panel JavaScript
   Shared across all authenticated pages
   ═══════════════════════════════════════════════════ */

const THEMES = [
    { id: 'light',  label: 'Claro',   icon: '☀️',  circleClass: 'light-circle'  },
    { id: 'dark',   label: 'Oscuro',  icon: '🌙',  circleClass: 'dark-circle'   },
    { id: 'green',  label: 'Verde',   icon: '🌿',  circleClass: 'green-circle'  },
];

// ── Theme Engine ──────────────────────────────────
function applyTheme() {
    const saved = localStorage.getItem('vs_theme') || localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', saved);
    // Migrate old key
    if (localStorage.getItem('theme') && !localStorage.getItem('vs_theme')) {
        localStorage.setItem('vs_theme', localStorage.getItem('theme'));
    }
}

function setTheme(themeId) {
    document.documentElement.setAttribute('data-theme', themeId);
    localStorage.setItem('vs_theme', themeId);
    // Update active state in panel
    document.querySelectorAll('.theme-option').forEach(el => {
        el.classList.toggle('active', el.dataset.theme === themeId);
    });
}

function cycleTheme() {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const idx = THEMES.findIndex(t => t.id === current);
    const next = THEMES[(idx + 1) % THEMES.length].id;
    setTheme(next);
}

// ── Settings Panel ────────────────────────────────
function openSettings() {
    const panel = document.getElementById('settingsPanel');
    const overlay = document.getElementById('settingsOverlay');
    if (!panel || !overlay) return;

    // Sync active theme
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    document.querySelectorAll('.theme-option').forEach(el => {
        el.classList.toggle('active', el.dataset.theme === current);
    });

    // Sync user info
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    if (user) {
        const nameEl = document.getElementById('settingsUserName');
        const roleEl = document.getElementById('settingsUserRole');
        const avatarEl = document.getElementById('settingsUserAvatar');
        if (nameEl) nameEl.textContent = user.name || user.email;
        if (roleEl) roleEl.textContent = user.role || '';
        if (avatarEl) avatarEl.textContent = (user.name || user.email || '?')[0].toUpperCase();
    }

    panel.classList.add('open');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeSettings() {
    const panel = document.getElementById('settingsPanel');
    const overlay = document.getElementById('settingsOverlay');
    if (!panel || !overlay) return;
    panel.classList.remove('open');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
}

// ── Inject Settings HTML ──────────────────────────
function injectSettingsPanel() {
    // Avoid double-inject
    if (document.getElementById('settingsPanel')) return;

    const html = `
    <!-- Settings Overlay -->
    <div class="settings-overlay" id="settingsOverlay" onclick="closeSettings()"></div>

    <!-- Settings Panel -->
    <div class="settings-panel" id="settingsPanel">
        <div class="settings-header">
            <h2>⚙️ Ajustes</h2>
            <button class="settings-close" onclick="closeSettings()" title="Cerrar">✕</button>
        </div>

        <!-- User Info -->
        <div class="settings-section">
            <h3>Cuenta</h3>
            <div class="user-info-card">
                <div class="user-avatar" id="settingsUserAvatar">?</div>
                <div class="user-details">
                    <div class="user-name" id="settingsUserName">—</div>
                    <div class="user-role" id="settingsUserRole">—</div>
                </div>
            </div>
        </div>

        <!-- Theme Selector -->
        <div class="settings-section">
            <h3>Apariencia</h3>
            <div class="theme-grid">
                ${THEMES.map(t => `
                    <div class="theme-option" data-theme="${t.id}" onclick="setTheme('${t.id}')">
                        <div class="theme-circle ${t.circleClass}">${t.icon}</div>
                        <span class="theme-label">${t.label}</span>
                    </div>
                `).join('')}
            </div>
        </div>

        <div class="settings-footer">VapeStore v1.0 — Pipilacha</div>
    </div>`;

    document.body.insertAdjacentHTML('beforeend', html);
}

// ── Add settings button to navbar ─────────────────
function addSettingsButton() {
    const navLinks = document.querySelector('.nav-links');
    if (!navLinks || document.querySelector('.settings-btn')) return;

    const btn = document.createElement('button');
    btn.className = 'settings-btn';
    btn.title = 'Ajustes';
    btn.textContent = '⚙️';
    btn.onclick = openSettings;

    // Insert before the first button (theme-toggle or logout)
    const firstBtn = navLinks.querySelector('button');
    if (firstBtn) {
        navLinks.insertBefore(btn, firstBtn);
    } else {
        navLinks.appendChild(btn);
    }
}

// ── Init ──────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    applyTheme();
    injectSettingsPanel();
    addSettingsButton();
});

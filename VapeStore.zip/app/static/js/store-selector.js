/* ═══════════════════════════════════════════════
   store-selector.js — Global store filter for admin pages
   Provides getStoreId() and renders a dropdown in navbar
   ═══════════════════════════════════════════════ */

(function() {
    const STORE_KEY = 'vapestore_selected_store';

    // Expose globally
    window.getStoreId = function() {
        const v = localStorage.getItem(STORE_KEY);
        return v && v !== 'all' ? parseInt(v) : null;
    };

    window.setStoreId = function(id) {
        if (id === 'all' || !id) {
            localStorage.removeItem(STORE_KEY);
        } else {
            localStorage.setItem(STORE_KEY, String(id));
        }
    };

    // Append store selector into navbar (or sidebar for pages without nav-links)
    window.initStoreSelector = async function() {
        // Managers are locked to their assigned store — no dropdown needed
        const user = JSON.parse(localStorage.getItem('user') || 'null');
        if (user && user.role === 'manager') {
            // Show store name as badge instead of dropdown
            let nav = document.querySelector('.nav-links');
            if (!nav) nav = document.querySelector('.po-sidebar .sidebar-header') || document.querySelector('.sidebar-header');
            if (nav && user.store_name) {
                const badge = document.createElement('span');
                badge.style.cssText = 'display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:8px;font-size:12px;font-weight:600;background:var(--accent,#0071e3);color:#fff;margin-right:8px;';
                badge.textContent = '🏪 ' + user.store_name;
                nav.insertBefore(badge, nav.firstChild);
            }
            return;
        }

        let nav = document.querySelector('.nav-links');
        if (!nav) {
            // Pages with sidebar layout (orders, inventory, etc.)
            nav = document.querySelector('.po-sidebar .sidebar-header') ||
                  document.querySelector('.sidebar-header') ||
                  document.querySelector('.nav-links');
        }
        if (!nav) return;

        try {
            const token = localStorage.getItem('token');
            const res = await fetch('/api/admin/stores', {
                headers: { Authorization: `Bearer ${token}` }
            });
            if (!res.ok) return;
            const data = await res.json();
            const stores = data.stores || [];
            if (stores.length === 0) return;

            const saved = localStorage.getItem(STORE_KEY) || 'all';

            // Create selector element
            const wrapper = document.createElement('span');
            wrapper.style.cssText = 'display:inline-flex;align-items:center;gap:6px;margin-right:12px;';
            wrapper.innerHTML = `
                <label style="font-size:12px;color:var(--text-secondary,#86868b);white-space:nowrap;">🏪</label>
                <select id="storeSelector" style="
                    padding:5px 10px;border:1.5px solid var(--glass-border,rgba(0,0,0,0.15));
                    border-radius:8px;font-size:12px;background:var(--glass-bg,rgba(255,255,255,0.8));
                    color:var(--text,#1d1d1f);cursor:pointer;
                ">
                    <option value="all">Todas las tiendas</option>
                    ${stores.map(s => `<option value="${s.id}">${s.name}</option>`).join('')}
                </select>
            `;

            // Insert before the user info / logout
            nav.insertBefore(wrapper, nav.firstChild);

            const select = document.getElementById('storeSelector');
            select.value = saved;

            select.addEventListener('change', () => {
                setStoreId(select.value);
                // Reload current page to apply filter
                if (typeof window.onStoreChange === 'function') {
                    window.onStoreChange();
                } else {
                    location.reload();
                }
            });
        } catch (e) {
            console.warn('Store selector init failed:', e);
        }
    };

    // Auto-init on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initStoreSelector);
    } else {
        initStoreSelector();
    }
})();

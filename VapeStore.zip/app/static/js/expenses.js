/* ═══════════════════════════════════════════════════
   VapeStore - Expenses / Budget Tracking
   ═══════════════════════════════════════════════════ */

const API = '';
const tok = () => localStorage.getItem('token') || '';
const hdr = () => ({ 'Authorization': `Bearer ${tok()}`, 'Content-Type': 'application/json' });
if (!tok()) window.location.href = '/login';

const $ = id => document.getElementById(id);
const fmt = n => '$' + (parseFloat(n) || 0).toFixed(2);

let allExpenses = [];
let isReadonly = false;

// ── Toast ──
function toast(msg, type = 'success') {
    const existing = document.querySelector('.toast-msg');
    if (existing) existing.remove();
    const el = document.createElement('div');
    el.className = 'toast-msg';
    el.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:500;z-index:9999;color:#fff;transition:opacity .3s;' +
        (type === 'error' ? 'background:var(--danger,#ff3b30)' : 'background:var(--success,#34c759)');
    el.textContent = (type === 'error' ? '❌ ' : '✅ ') + msg;
    document.body.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 400); }, 3000);
}

// ── Check read-only mode ──
function checkReadonly() {
    const params = new URLSearchParams(window.location.search);
    isReadonly = params.get('readonly') === 'true';
    if (isReadonly) {
        const formCard = $('formCard');
        if (formCard) formCard.style.display = 'none';
        const badge = $('readonlyBadge');
        if (badge) badge.style.display = '';
        document.title = 'Gastos (Solo Lectura) - VapeStore';
    }
}

// ── Load expenses ──
async function loadExpenses() {
    try {
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const res = await fetch(`${API}/api/admin/expenses${sidParam}`, { headers: hdr() });
        if (!res.ok) throw new Error('Error');
        const data = await res.json();
        allExpenses = data.expenses || [];
        renderAll();
    } catch (e) {
        console.error(e);
        toast('Error al cargar gastos', 'error');
    }
}

// ── Render everything ──
function renderAll() {
    renderSummary();
    renderProviderSummary();
    renderTable();
    updateProviderDatalist();
}

// ── Summary cards ──
function renderSummary() {
    const total = allExpenses.reduce((s, e) => s + (parseFloat(e.amount) || 0), 0);
    const providers = [...new Set(allExpenses.map(e => e.provider))];
    if ($('totalExpenses')) $('totalExpenses').textContent = fmt(total);
    if ($('totalEntries')) $('totalEntries').textContent = allExpenses.length;
    if ($('totalProviders')) $('totalProviders').textContent = providers.length;
}

// ── Provider summary ──
function renderProviderSummary() {
    const container = $('providerList2');
    if (!container) return;

    if (!allExpenses.length) {
        container.innerHTML = '<div class="empty-state"><div class="icon">📭</div><p>Sin gastos registrados</p></div>';
        return;
    }

    // Group by provider
    const byProvider = {};
    allExpenses.forEach(e => {
        if (!byProvider[e.provider]) byProvider[e.provider] = { total: 0, count: 0 };
        byProvider[e.provider].total += parseFloat(e.amount) || 0;
        byProvider[e.provider].count++;
    });

    // Sort by total desc
    const sorted = Object.entries(byProvider).sort((a, b) => b[1].total - a[1].total);

    container.innerHTML = sorted.map(([name, data]) => `
        <div class="provider-row">
            <div>
                <span class="name">${esc(name)}</span>
                <span class="count"> · ${data.count} registro${data.count > 1 ? 's' : ''}</span>
            </div>
            <div class="total">${fmt(data.total)}</div>
        </div>
    `).join('');
}

// ── Expenses table ──
function renderTable() {
    const container = $('expensesTable');
    if (!container) return;

    if (!allExpenses.length) {
        container.innerHTML = '<div class="empty-state"><div class="icon">📭</div><p>Sin gastos registrados</p></div>';
        return;
    }

    container.innerHTML = `
        <table class="exp-table">
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Proveedor</th>
                    <th>Monto</th>
                    <th>Notas</th>
                    ${isReadonly ? '' : '<th></th>'}
                </tr>
            </thead>
            <tbody>
                ${allExpenses.map(e => `
                    <tr>
                        <td>${formatDate(e.expense_date)}</td>
                        <td><span class="provider-tag">${esc(e.provider)}</span></td>
                        <td class="amount">${fmt(e.amount)}</td>
                        <td style="color:var(--text-secondary);font-size:13px;">${esc(e.notes || '—')}</td>
                        ${isReadonly ? '' : `<td><button class="btn-sm danger" onclick="deleteExpense(${e.id})">🗑️</button></td>`}
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
}

// ── Provider datalist ──
function updateProviderDatalist() {
    const dl = $('providerList');
    if (!dl) return;
    const providers = [...new Set(allExpenses.map(e => e.provider))];
    dl.innerHTML = providers.map(p => `<option value="${esc(p)}">`).join('');
}

// ── Submit expense ──
async function submitExpense(e) {
    e.preventDefault();
    if (isReadonly) return;

    const provider = $('expProvider')?.value?.trim();
    const amount = parseFloat($('expAmount')?.value);
    const date = $('expDate')?.value;
    const notes = $('expNotes')?.value?.trim() || '';

    if (!provider || !amount || !date) {
        toast('Completa proveedor, monto y fecha', 'error');
        return;
    }

    try {
        const res = await fetch(`${API}/api/admin/expenses?provider=${encodeURIComponent(provider)}&amount=${amount}&expense_date=${date}&notes=${encodeURIComponent(notes)}`, {
            method: 'POST', headers: hdr()
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast('Gasto registrado');
        $('expenseForm')?.reset();
        // Set today's date
        $('expDate').value = new Date().toISOString().slice(0, 10);
        loadExpenses();
    } catch (e) { toast(e.message, 'error'); }
}

// ── Delete expense ──
async function deleteExpense(id) {
    if (isReadonly) return;
    if (!confirm('¿Eliminar este gasto?')) return;
    try {
        const res = await fetch(`${API}/api/admin/expenses/${id}`, { method: 'DELETE', headers: hdr() });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast('Gasto eliminado');
        loadExpenses();
    } catch (e) { toast(e.message, 'error'); }
}

// ── Export CSV ──
function exportCSV() {
    if (!allExpenses.length) { toast('No hay datos para exportar', 'error'); return; }

    const headers = ['Fecha', 'Proveedor', 'Monto', 'Notas'];
    const rows = allExpenses.map(e => [
        e.expense_date,
        `"${(e.provider || '').replace(/"/g, '""')}"`,
        e.amount,
        `"${(e.notes || '').replace(/"/g, '""')}"`
    ]);

    // Add provider summary
    const byProvider = {};
    allExpenses.forEach(e => {
        if (!byProvider[e.provider]) byProvider[e.provider] = 0;
        byProvider[e.provider] += parseFloat(e.amount) || 0;
    });

    let csv = headers.join(',') + '\n';
    rows.forEach(r => csv += r.join(',') + '\n');
    csv += '\nRESUMEN POR PROVEEDOR\n';
    csv += 'Proveedor,Total\n';
    Object.entries(byProvider).sort((a, b) => b[1] - a[1]).forEach(([name, total]) => {
        csv += `"${name.replace(/"/g, '""')}",${total.toFixed(2)}\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gastos-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast('CSV descargado');
}

// ── Helpers ──
function esc(s) { return String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function formatDate(d) {
    if (!d) return '—';
    return new Date(d + 'T00:00:00').toLocaleDateString('es', { day: '2-digit', month: 'short', year: 'numeric' });
}

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
    checkReadonly();
    // Set default date to today
    if (!isReadonly) {
        const dateInput = $('expDate');
        if (dateInput && !dateInput.value) {
            dateInput.value = new Date().toISOString().slice(0, 10);
        }
    }
    loadExpenses();
});

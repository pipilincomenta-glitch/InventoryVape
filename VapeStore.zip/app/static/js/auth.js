/* Auth JavaScript - Login, Register, Logout */
const API = '';

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
}

function getUser() {
    return JSON.parse(localStorage.getItem('user'));
}

function updateNav() {
    const user = getUser();
    const nav = document.getElementById('userNav');
    if (!nav) return;
    if (user) {
        nav.innerHTML = `<span class="user-badge">${user.name} (${user.role})</span>`;
    }
}

// Login form
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const error = document.getElementById('error');

    try {
        const res = await fetch(`${API}/api/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
        });
        const data = await res.json();

        if (!res.ok) {
            error.textContent = data.detail || 'Error al iniciar sesión';
            return;
        }

        localStorage.setItem('token', data.access_token);
        localStorage.setItem('user', JSON.stringify(data.user));

        const role = data.user.role;
        if (role === 'admin') window.location.href = '/admin';
        else if (role === 'worker') window.location.href = '/worker';
        else window.location.href = '/catalog';
    } catch (err) {
        error.textContent = 'Error de conexión';
    }
});

// Register form
document.getElementById('registerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const phone = document.getElementById('phone').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const error = document.getElementById('error');

    if (password !== confirmPassword) {
        error.textContent = 'Las contraseñas no coinciden';
        return;
    }

    try {
        const res = await fetch(`${API}/api/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, email, phone, password, role: 'client' }),
        });
        const data = await res.json();

        if (!res.ok) {
            error.textContent = data.detail || 'Error al registrar';
            return;
        }

        localStorage.setItem('token', data.access_token);
        localStorage.setItem('user', JSON.stringify(data.user));
        window.location.href = '/catalog';
    } catch (err) {
        error.textContent = 'Error de conexión';
    }
});

document.addEventListener('DOMContentLoaded', updateNav);

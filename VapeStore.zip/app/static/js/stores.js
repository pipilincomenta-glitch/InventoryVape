/* ═══════════════════════════════════════════════
   stores.js — Tiendas management + PIN assignment
   ═══════════════════════════════════════════════ */

const API = '';
const token = localStorage.getItem('token');
const user = JSON.parse(localStorage.getItem('user') || '{}');
const h = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };

let allStores = [];
let allWorkers = [];

// ── Auth guard ──
if (!token || user.role !== 'admin') { window.location.href = '/login'; }

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
    loadStores();
    loadWorkers();
    setupNav();
});

// ── Navbar user info ──
(function() {
    const nav = document.getElementById('userNav');
    if (nav && user.name) nav.innerHTML = `<span style="font-size:13px;color:var(--text-secondary)">👤 ${user.name}</span>`;
})();

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('store');
    window.location.href = '/login';
}

// ═══ NAV ═══
function setupNav() {
    // Check hash for initial view
    const hash = window.location.hash.slice(1);
    if (hash === 'pins') showView('pins');
}

function showView(view) {
    document.getElementById('view-stores').style.display = view === 'stores' ? 'block' : 'none';
    document.getElementById('view-pins').style.display = view === 'pins' ? 'block' : 'none';
    document.getElementById('navStores').className = view === 'stores' ? 'active' : '';
    document.getElementById('navPins').className = view === 'pins' ? 'active' : '';
    if (view === 'pins') loadWorkerPins();
}

// ═══ STORES ═══
async function loadStores() {
    try {
        const res = await fetch(`${API}/api/admin/stores`, { headers: h });
        if (!res.ok) throw new Error('Error cargando tiendas');
        const data = await res.json();
        allStores = data.stores || [];
        renderStores();
    } catch (e) {
        toast(e.message, 'error');
    }
}

function renderStores() {
    const grid = document.getElementById('storeGrid');
    if (allStores.length === 0) {
        grid.innerHTML = `<div class="empty-state"><div class="icon">🏪</div><p>No hay tiendas creadas aún</p></div>`;
        return;
    }
    grid.innerHTML = allStores.map(s => `
        <div class="store-card ${s.active ? '' : 'inactive'}">
            <div class="card-header">
                <h3 class="store-name">${esc(s.name)}</h3>
                <span class="store-status ${s.active ? 'active' : 'inactive'}">${s.active ? 'Activa' : 'Inactiva'}</span>
            </div>
            <div class="store-meta">
                <div>📍 ${esc(s.address || 'Sin dirección')}</div>
                <div>📞 ${esc(s.phone || 'Sin teléfono')}</div>
                <div>👥 ${s.worker_count || 0} trabajador${s.worker_count !== 1 ? 'es' : ''}</div>
            </div>
            <div class="card-actions">
                <button class="btn secondary" onclick="openEditStore(${s.id})">✏️ Editar</button>
                ${s.active
                    ? `<button class="btn danger" onclick="deactivateStore(${s.id},'${esc(s.name)}')">🚫 Desactivar</button>`
                    : `<button class="btn primary" onclick="activateStore(${s.id})">✅ Activar</button>`
                }
            </div>
        </div>
    `).join('');
}

// ── Create / Edit Store ──
function openCreateStore() {
    document.getElementById('storeModalTitle').textContent = 'Nueva Tienda';
    document.getElementById('storeId').value = '';
    document.getElementById('storeName').value = '';
    document.getElementById('storeAddress').value = '';
    document.getElementById('storePhone').value = '';
    openModal('storeModal');
}

function openEditStore(id) {
    const store = allStores.find(s => s.id === id);
    if (!store) return;
    document.getElementById('storeModalTitle').textContent = 'Editar Tienda';
    document.getElementById('storeId').value = store.id;
    document.getElementById('storeName').value = store.name;
    document.getElementById('storeAddress').value = store.address || '';
    document.getElementById('storePhone').value = store.phone || '';
    openModal('storeModal');
}

async function saveStore(e) {
    e.preventDefault();
    const id = document.getElementById('storeId').value;
    const name = document.getElementById('storeName').value.trim();
    const address = document.getElementById('storeAddress').value.trim();
    const phone = document.getElementById('storePhone').value.trim();
    if (!name) return;

    try {
        let res;
        if (id) {
            res = await fetch(`${API}/api/admin/stores/${id}?name=${encodeURIComponent(name)}&address=${encodeURIComponent(address)}&phone=${encodeURIComponent(phone)}&active=1`, {
                method: 'PUT', headers: h
            });
        } else {
            res = await fetch(`${API}/api/admin/stores?name=${encodeURIComponent(name)}&address=${encodeURIComponent(address)}&phone=${encodeURIComponent(phone)}`, {
                method: 'POST', headers: h
            });
        }
        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.detail || 'Error guardando tienda');
        }
        toast(id ? 'Tienda actualizada' : 'Tienda creada', 'success');
        closeModal('storeModal');
        loadStores();
    } catch (e) {
        toast(e.message, 'error');
    }
}

async function deactivateStore(id, name) {
    if (!confirm(`¿Desactivar "${name}"?\nLos trabajadores no podrán iniciar sesión con PIN en esta tienda.`)) return;
    try {
        const res = await fetch(`${API}/api/admin/stores/${id}`, { method: 'DELETE', headers: h });
        if (!res.ok) throw new Error('Error desactivando tienda');
        toast('Tienda desactivada', 'success');
        loadStores();
    } catch (e) {
        toast(e.message, 'error');
    }
}

async function activateStore(id) {
    const store = allStores.find(s => s.id === id);
    if (!store) return;
    try {
        const res = await fetch(`${API}/api/admin/stores/${id}?name=${encodeURIComponent(store.name)}&address=${encodeURIComponent(store.address || '')}&phone=${encodeURIComponent(store.phone || '')}&active=1`, {
            method: 'PUT', headers: h
        });
        if (!res.ok) throw new Error('Error activando tienda');
        toast('Tienda activada', 'success');
        loadStores();
    } catch (e) {
        toast(e.message, 'error');
    }
}

// ═══ WORKERS ═══
async function loadWorkers() {
    try {
        const res = await fetch(`${API}/api/auth/workers`, { headers: h });
        if (!res.ok) throw new Error('Error cargando trabajadores');
        const data = await res.json();
        allWorkers = data.workers || [];
        populateWorkerSelect();
    } catch (e) {
        console.error(e);
    }
}

function populateWorkerSelect() {
    const sel = document.getElementById('pinWorkerSelect');
    sel.innerHTML = '<option value="">Seleccionar trabajador...</option>' +
        allWorkers.filter(w => w.role === 'worker' && w.active).map(w =>
            `<option value="${w.id}">${esc(w.name)} (${esc(w.email)})</option>`
        ).join('');
}

// ═══ PIN ASSIGNMENT ═══
async function loadWorkerPins() {
    const workerId = document.getElementById('pinWorkerSelect').value;
    const area = document.getElementById('workerPinsArea');
    if (!workerId) {
        area.innerHTML = '<p style="color:var(--text-secondary);font-size:14px;">Selecciona un trabajador para ver sus PINs</p>';
        return;
    }

    try {
        const res = await fetch(`${API}/api/admin/workers/${workerId}/pins`, { headers: h });
        if (!res.ok) throw new Error('Error cargando PINs');
        const data = await res.json();
        const pins = data.pins || [];

        let html = `
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                <h3 style="margin:0;font-size:16px;">PINs de ${esc(allWorkers.find(w => w.id == workerId)?.name || '')}</h3>
                <button class="btn primary" onclick="openAddPin(${workerId})">+ Asignar PIN</button>
            </div>`;

        if (pins.length === 0) {
            html += '<p style="color:var(--text-secondary);font-size:14px;">Este trabajador no tiene PINs asignados</p>';
        } else {
            html += `
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">
                    ${pins.map(p => `
                        <div class="store-card">
                            <div class="card-header">
                                <h3 class="store-name">🏪 ${esc(p.store_name)}</h3>
                                ${p.is_primary ? '<span class="store-status active">Principal</span>' : ''}
                            </div>
                            <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                                <span style="font-size:28px;font-weight:700;letter-spacing:4px;color:var(--accent);font-family:monospace;">${esc(p.pin)}</span>
                            </div>
                            <div class="card-actions">
                                <button class="btn secondary" onclick="openEditPin(${workerId},${p.id},'${esc(p.pin)}',${p.is_primary})">✏️ Editar</button>
                                <button class="btn danger" onclick="deletePin(${workerId},${p.id})">🗑️ Eliminar</button>
                            </div>
                        </div>
                    `).join('')}
                </div>`;
        }

        area.innerHTML = html;
    } catch (e) {
        area.innerHTML = `<p style="color:var(--danger);">Error: ${esc(e.message)}</p>`;
    }
}

function openAddPin(workerId) {
    document.getElementById('pinWorkerId').value = workerId;
    document.getElementById('pinId').value = '';
    document.getElementById('pinValue').value = '';
    document.getElementById('pinPrimary').checked = false;
    populatePinStoreSelect();
    openModal('pinModal');
}

function openEditPin(workerId, pinId, pin, isPrimary) {
    document.getElementById('pinWorkerId').value = workerId;
    document.getElementById('pinId').value = pinId;
    document.getElementById('pinValue').value = pin;
    document.getElementById('pinPrimary').checked = !!isPrimary;
    populatePinStoreSelect();
    // Disable store select when editing
    document.getElementById('pinStoreSelect').disabled = true;
    openModal('pinModal');
}

function populatePinStoreSelect() {
    const sel = document.getElementById('pinStoreSelect');
    sel.disabled = false;
    sel.innerHTML = allStores.filter(s => s.active).map(s =>
        `<option value="${s.id}">${esc(s.name)}</option>`
    ).join('');
}

async function savePin(e) {
    e.preventDefault();
    const workerId = document.getElementById('pinWorkerId').value;
    const pinId = document.getElementById('pinId').value;
    const storeId = document.getElementById('pinStoreSelect').value;
    const pin = document.getElementById('pinValue').value.trim();
    const isPrimary = document.getElementById('pinPrimary').checked ? 1 : 0;

    if (!pin || pin.length < 4) { toast('PIN debe tener al menos 4 dígitos', 'error'); return; }

    try {
        let res;
        if (pinId) {
            // Update existing PIN
            res = await fetch(`${API}/api/admin/workers/${workerId}/pins/${pinId}?pin=${pin}&is_primary=${isPrimary}`, {
                method: 'PUT', headers: h
            });
        } else {
            // Create new PIN
            res = await fetch(`${API}/api/admin/workers/${workerId}/pins?store_id=${storeId}&pin=${pin}&is_primary=${isPrimary}`, {
                method: 'POST', headers: h
            });
        }
        if (!res.ok) {
            const err = await res.json();
            throw new Error(err.detail || 'Error guardando PIN');
        }
        toast(pinId ? 'PIN actualizado' : 'PIN asignado', 'success');
        closeModal('pinModal');
        loadWorkerPins();
        loadStores(); // refresh worker counts
    } catch (e) {
        toast(e.message, 'error');
    }
}

async function deletePin(workerId, pinId) {
    if (!confirm('¿Eliminar este PIN?')) return;
    try {
        const res = await fetch(`${API}/api/admin/workers/${workerId}/pins/${pinId}`, {
            method: 'DELETE', headers: h
        });
        if (!res.ok) throw new Error('Error eliminando PIN');
        toast('PIN eliminado', 'success');
        loadWorkerPins();
        loadStores();
    } catch (e) {
        toast(e.message, 'error');
    }
}

// ═══ HELPERS ═══
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

function toast(msg, type = 'success') {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.className = `toast ${type} show`;
    setTimeout(() => el.classList.remove('show'), 3000);
}

function esc(s) {
    if (!s) return '';
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
}

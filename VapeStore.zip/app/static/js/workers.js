/* Workers Management — VapeStore */
const API = '';
const tok = () => localStorage.getItem('token') || '';
const hdr = () => ({ 'Authorization': `Bearer ${tok()}`, 'Content-Type': 'application/json' });
if (!tok()) window.location.href = '/login';

// ── State ──
let allWorkers = [];
let selectedWorkerId = null;

// ── Helpers ──
const $ = id => document.getElementById(id);
const esc = s => String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
const fmt = n => '$' + (parseFloat(n) || 0).toFixed(2);
const fmtHours = h => (parseFloat(h) || 0).toFixed(1) + 'h';
function fmtDate(d) { return d ? new Date(d).toLocaleString('es', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' }) : '—'; }
function fmtTime(d) { return d ? new Date(d).toLocaleTimeString('es', { hour:'2-digit', minute:'2-digit' }) : '—'; }

function toast(msg, type = 'success') {
    const existing = document.querySelector('.toast-msg');
    if (existing) existing.remove();
    const el = document.createElement('div');
    el.className = 'toast-msg';
    el.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:500;z-index:9999;color:#fff;transition:opacity .3s;' +
        (type === 'error' ? 'background:var(--danger,#ff3b30)' : 'background:var(--success,#34c759)');
    el.textContent = (type === 'error' ? '❌ ' : '✅ ') + msg;
    document.body.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 400); }, 3000);
}

// ── Tab Navigation ──
function showTab(name) {
    document.querySelectorAll('[id^="tab-"]').forEach(t => t.style.display = 'none');
    const tab = $('tab-' + name);
    if (tab) tab.style.display = '';
    document.querySelectorAll('.wk-sidebar nav a').forEach(a => a.classList.remove('active'));
    const nav = $('nav-' + name);
    if (nav) nav.classList.add('active');
    if (name === 'list') loadWorkers();
    if (name === 'hours') {
        populateWorkerSelect();
        calRenderWeek();
        loadShifts(selectedWorkerId || null);
    }
    if (name === 'analytics') { loadAllStats(); loadFilterOptions(); }
}

// ═══════════════════════════════════════════════
// TAB 1: TRABAJADORES
// ═══════════════════════════════════════════════
async function loadWorkers() {
    try {
        const sid = getStoreId();
        const sidParam = sid ? `&store_id=${sid}` : '';
        const res = await fetch(`${API}/api/admin/workers/all-stats?days=30${sidParam}`, { headers: hdr() });
        if (!res.ok) throw new Error('Error');
        const data = await res.json();
        allWorkers = data.workers || [];
        renderWorkerList();
    } catch (e) {
        console.error(e);
        toast('Error al cargar trabajadores', 'error');
    }
}

function renderWorkerList() {
    const container = $('workersGrid');
    const empty = $('workersEmpty');
    if (!container) return;

    // Stats
    const active = allWorkers.filter(w => w.active);
    const inactive = allWorkers.filter(w => !w.active);
    const totalRev = allWorkers.reduce((s, w) => s + (w.total_revenue || 0), 0);
    if ($('totalWorkers')) $('totalWorkers').textContent = allWorkers.length;
    if ($('activeWorkers')) $('activeWorkers').textContent = active.length;
    if ($('inactiveWorkers')) $('inactiveWorkers').textContent = inactive.length;
    if ($('totalRevenue')) $('totalRevenue').textContent = fmt(totalRev);

    if (!allWorkers.length) {
        container.innerHTML = '';
        if (empty) { empty.style.display = ''; empty.innerHTML = '<p>No hay trabajadores registrados. Crea uno con "+ Crear Trabajador".</p>'; }
        return;
    }
    if (empty) empty.style.display = 'none';

    container.innerHTML = allWorkers.map(w => {
        const isActive = w.active !== false;
        return `
        <div class="worker-card">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px;">
                <div>
                    <h3 style="margin:0;font-size:17px;">${esc(w.name)}</h3>
                    <p style="margin:4px 0;font-size:13px;color:var(--text-secondary);">${esc(w.email)}</p>
                    <p style="margin:2px 0;font-size:13px;color:var(--text-secondary);">📞 ${esc(w.phone || 'Sin teléfono')}</p>
                </div>
                <span style="padding:4px 12px;border-radius:8px;font-size:12px;font-weight:600;${isActive ? 'background:var(--success-glow);color:var(--success)' : 'background:var(--danger-glow);color:var(--danger)'}">${isActive ? 'Activo' : 'Inactivo'}</span>
            </div>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:12px 0;padding:12px;background:var(--glass-bg,rgba(0,0,0,0.03));border-radius:10px;">
                <div style="text-align:center;"><div style="font-size:20px;font-weight:700;color:var(--accent,#0071e3);">${w.total_orders || 0}</div><div style="font-size:11px;color:var(--text-secondary);">Órdenes</div></div>
                <div style="text-align:center;"><div style="font-size:20px;font-weight:700;color:var(--success);">${fmt(w.total_revenue || 0)}</div><div style="font-size:11px;color:var(--text-secondary);">Ventas</div></div>
                <div style="text-align:center;"><div style="font-size:20px;font-weight:700;">${fmtHours(w.total_hours || 0)}</div><div style="font-size:11px;color:var(--text-secondary);">Horas</div></div>
                <div style="text-align:center;"><div style="font-size:20px;font-weight:700;">${w.total_shifts || 0}</div><div style="font-size:11px;color:var(--text-secondary);">Turnos</div></div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;">
                <button class="btn-sm secondary" onclick="openEditModal(${w.id})">✏️ Editar</button>
                <button class="btn-sm ${isActive ? 'danger' : 'primary'}" onclick="toggleActive(${w.id}, ${isActive})">${isActive ? '🚫 Desactivar' : '✅ Activar'}</button>
                <button class="btn-sm secondary" onclick="openResetModal(${w.id}, '${esc(w.name)}')">🔑 Reset Pass</button>
            </div>
        </div>`;
    }).join('');
}

// ── Search filter ──
function filterWorkers() {
    const q = ($('searchWorkers')?.value || '').toLowerCase().trim();
    if (!q) { renderWorkerList(); return; }
    const filtered = allWorkers.filter(w => (w.name || '').toLowerCase().includes(q) || (w.email || '').toLowerCase().includes(q));
    const container = $('workersGrid');
    if (!container) return;
    // Temporarily swap and render
    const orig = allWorkers;
    allWorkers = filtered;
    renderWorkerList();
    allWorkers = orig;
}

// ═══════════════════════════════════════════════
// TAB 2: HORAS
// ═══════════════════════════════════════════════
// ── Calendar State ──
let calWeekStart = getMonday(new Date());

// ── Date Helpers ──
function getMonday(date) {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1);
    d.setDate(diff);
    d.setHours(0, 0, 0, 0);
    return d;
}

function addDays(date, n) {
    const d = new Date(date);
    d.setDate(d.getDate() + n);
    return d;
}

function fmtDateISO(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
}

function fmtDayLabel(date) {
    const days = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    return days[date.getDay()] + ' ' + date.getDate();
}

function fmtWeekRange(mondayDate) {
    const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    const end = addDays(mondayDate, 6);
    return `${mondayDate.getDate()} ${months[mondayDate.getMonth()]} - ${end.getDate()} ${months[end.getMonth()]} ${end.getFullYear()}`;
}

function fmtShiftTime(start, end) {
    const fmtH = d => new Date(d).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit', hour12: false });
    return `${fmtH(start)} - ${fmtH(end)}`;
}

function isToday(date) {
    const now = new Date();
    return date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth() && date.getDate() === now.getDate();
}

function toISODateStr(date) {
    return fmtDateISO(date);
}

// ── Week Navigation ──
function changeWeek(dir) {
    calWeekStart = addDays(calWeekStart, dir * 7);
    updateWeekLabel();
    calRenderWeek();
}

function prevWeek() {
    calWeekStart = addDays(calWeekStart, -7);
    updateWeekLabel();
    calRenderWeek();
}

function nextWeek() {
    calWeekStart = addDays(calWeekStart, 7);
    updateWeekLabel();
    calRenderWeek();
}

function updateWeekLabel() {
    const el = $('weekLabel');
    if (el) el.textContent = fmtWeekRange(calWeekStart);
}

// ── Calendar Rendering ──
async function calRenderWeek() {
    updateWeekLabel();
    const grid = $('calendarGrid');
    if (!grid) return;

    try {
        const startDate = toISODateStr(calWeekStart);
        const endDate = fmtDateISO(addDays(calWeekStart, 6));

        // Fetch actual clocked shifts AND scheduled shifts in parallel
        const sid = getStoreId();
        const sidParam = sid ? `&store_id=${sid}` : '';
        const [shiftsRes, schedRes] = await Promise.all([
            fetch(`${API}/api/admin/shifts/week?start=${startDate}${sidParam}`, { headers: hdr() }),
            fetch(`${API}/api/admin/scheduled-shifts?start=${startDate}&end=${endDate}${sidParam}`, { headers: hdr() })
        ]);

        if (!shiftsRes.ok) throw new Error('Error loading shifts');
        const shiftsData = await shiftsRes.json();
        const shifts = shiftsData.shifts || [];

        let scheduledShifts = [];
        if (schedRes.ok) {
            const schedData = await schedRes.json();
            scheduledShifts = schedData.shifts || [];
        }

        const workers = allWorkers || [];

        // Build day columns (7 days starting from Monday)
        const days = [];
        for (let i = 0; i < 7; i++) {
            days.push(addDays(calWeekStart, i));
        }

        // Build lookup: shiftMap[worker_id][dateStr] = shift object
        const shiftMap = {};
        shifts.forEach(s => {
            if (!s.clock_in) return;
            const clockDate = new Date(s.clock_in);
            const key = fmtDateISO(clockDate);
            const wid = s.worker_id;
            if (!shiftMap[wid]) shiftMap[wid] = {};
            shiftMap[wid][key] = s;
        });

        // Build lookup: schedMap[worker_id][dateStr] = [array of scheduled shifts]
        const schedMap = {};
        scheduledShifts.forEach(s => {
            const wid = s.worker_id;
            const dateKey = s.date; // already YYYY-MM-DD
            if (!schedMap[wid]) schedMap[wid] = {};
            if (!schedMap[wid][dateKey]) schedMap[wid][dateKey] = [];
            schedMap[wid][dateKey].push(s);
        });

        // Find today column index
        const todayDate = new Date();
        const todayStr = fmtDateISO(todayDate);
        const todayColIdx = days.findIndex(d => fmtDateISO(d) === todayStr);

        let html = '';

        // Header row — flat cells (no row wrapper, direct grid children)
        html += '<div class="cal-cell header name-cell" style="min-height:auto;"></div>';
        days.forEach((d, i) => {
            const cls = i === todayColIdx ? 'cal-cell header today' : 'cal-cell header';
            html += `<div class="${cls}">${fmtDayLabel(d)}</div>`;
        });

        // Worker rows — flat cells
        const dailyTotals = new Array(7).fill(0);

        workers.forEach(w => {
            html += `<div class="cal-cell name-cell">${esc(w.name)}</div>`;

            days.forEach((d, i) => {
                const dateStr = fmtDateISO(d);
                const shift = shiftMap[w.id]?.[dateStr];
                const schedShifts = schedMap[w.id]?.[dateStr] || [];
                const cls = i === todayColIdx ? 'cal-cell today' : 'cal-cell';
                const hasAnyShift = shift || schedShifts.length > 0;

                let cellContent = '';

                // First: render scheduled shifts (purple blocks)
                schedShifts.forEach(ss => {
                    const st = ss.start_time || '09:00';
                    const et = ss.end_time || '17:00';
                    const schedId = ss.id || 0;
                    cellContent += `<div class="cal-sched" onclick="event.stopPropagation(); openScheduledShiftModal(${w.id}, '${dateStr}', ${schedId})"><div class="shift-time">${esc(st)} - ${esc(et)}</div><div class="shift-hours" style="font-size:10px;color:#b388ff;">Programado</div></div>`;
                });

                // Then: render actual clocked shifts (green blocks)
                if (shift) {
                    const isActive = shift.clock_out === null || shift.clock_out === undefined;
                    const shiftCls = isActive ? 'cal-shift active' : 'cal-shift';
                    const hours = shift.hours_worked || 0;
                    dailyTotals[i] += hours;
                    const timeRange = shift.clock_out
                        ? fmtShiftTime(shift.clock_in, shift.clock_out)
                        : fmtTime(shift.clock_in) + ' - ...';
                    const hoursLabel = shift.hours_worked ? parseFloat(hours).toFixed(1) + 'h' : 'En curso';
                    cellContent += `<div class="${shiftCls}"><div class="shift-time">${esc(timeRange)}</div><div class="shift-hours">${hoursLabel}</div></div>`;
                }

                // Cell with or without content — clickable to create scheduled shift
                if (cellContent) {
                    html += `<div class="${cls}" onclick="openScheduledShiftModal(${w.id}, '${dateStr}', 0)">${cellContent}</div>`;
                } else {
                    html += `<div class="${cls}" style="cursor:pointer;" onclick="openScheduledShiftModal(${w.id}, '${dateStr}', 0)"></div>`;
                }
            });
        });

        // Totals row — flat cells
        if (workers.length > 0) {
            html += '<div class="cal-cell name-cell totals" style="min-height:auto;font-weight:700;">Total</div>';
            dailyTotals.forEach((total, i) => {
                const cls = i === todayColIdx ? 'cal-cell totals today' : 'cal-cell totals';
                html += `<div class="${cls}">${total > 0 ? total.toFixed(1) + 'h' : '—'}</div>`;
            });
        }

        grid.innerHTML = html;
    } catch (e) {
        console.error('calRenderWeek error:', e);
        grid.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-secondary);">Error al cargar el calendario</div>';
    }
}

// ── Worker Select (Clock-in/out panel) ──
function populateWorkerSelect() {
    const sel = $('clockWorkerSelect');
    if (!sel) return;
    sel.innerHTML = '<option value="">Seleccionar trabajador...</option>' +
        allWorkers.map(w => `<option value="${w.id}" ${w.id === selectedWorkerId ? 'selected' : ''}>${esc(w.name)} ${w.active ? '' : '(inactivo)'}</option>`).join('');
    sel.onchange = () => {
        selectedWorkerId = parseInt(sel.value) || null;
        calRenderWeek();
        loadShifts(selectedWorkerId || null);
        if (!selectedWorkerId) updateClockButtons(false);
    };
}

// ── Shift History & Stats ──
async function loadShifts(workerId) {
    try {
        let shifts = [];
        if (workerId) {
            const res = await fetch(`${API}/api/admin/workers/${workerId}/shifts?days=30`, { headers: hdr() });
            const data = await res.json();
            shifts = data.shifts || [];
        } else {
            // Fetch shifts for all workers
            const allPromises = (allWorkers || []).map(w =>
                fetch(`${API}/api/admin/workers/${w.id}/shifts?days=30`, { headers: hdr() })
                    .then(r => r.json()).then(d => d.shifts || []).catch(() => [])
            );
            const results = await Promise.all(allPromises);
            shifts = results.flat();
        }

        // Check if any active (clocked in)
        const hasActive = shifts.some(s => !s.clock_out);
        if (workerId) updateClockButtons(hasActive);
        else updateClockButtons(false);

        // Summary stats
        const today = new Date().toISOString().slice(0, 10);
        const weekAgo = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
        const monthAgo = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
        const hToday = shifts.filter(s => s.clock_in?.startsWith(today) && s.hours_worked).reduce((sum, s) => sum + s.hours_worked, 0);
        const hWeek = shifts.filter(s => s.clock_in?.slice(0,10) >= weekAgo && s.hours_worked).reduce((sum, s) => sum + s.hours_worked, 0);
        const hMonth = shifts.filter(s => s.clock_in?.slice(0,10) >= monthAgo && s.hours_worked).reduce((sum, s) => sum + s.hours_worked, 0);
        const totalShifts = shifts.length;
        if ($('hoursToday')) $('hoursToday').textContent = fmtHours(hToday);
        if ($('hoursWeek')) $('hoursWeek').textContent = fmtHours(hWeek);
        if ($('hoursMonth')) $('hoursMonth').textContent = fmtHours(hMonth);
        if ($('totalShifts')) $('totalShifts').textContent = totalShifts;

        // Render history table
        const tbody = $('shiftsBody');
        const empty = $('shiftsEmpty');

        if (!shifts.length) {
            if (tbody) tbody.innerHTML = '';
            if (empty) { empty.style.display = ''; empty.innerHTML = '<p>Sin turnos registrados en los últimos 30 días.</p>'; }
            return;
        }
        if (empty) empty.style.display = 'none';

        // Sort by clock_in descending
        shifts.sort((a, b) => new Date(b.clock_in || 0) - new Date(a.clock_in || 0));

        tbody.innerHTML = shifts.map(s => {
            const workerName = s.worker_name || (allWorkers.find(w => w.id === s.worker_id)?.name || '');
            return `
                <tr>
                    <td>${workerName ? esc(workerName) : '—'}</td>
                    <td>${s.clock_in ? new Date(s.clock_in).toLocaleDateString('es') : '—'}</td>
                    <td>${fmtTime(s.clock_in)}</td>
                    <td>${s.clock_out ? fmtTime(s.clock_out) : '<span style="color:var(--success);font-weight:600;">🔴 Activo</span>'}</td>
                    <td>${s.hours_worked ? fmtHours(s.hours_worked) : 'En curso...'}</td>
                    <td><button class="btn-sm danger" onclick="deleteWorkShift(${s.worker_id}, ${s.id})">🗑️</button></td>
                </tr>
            `;
        }).join('');
    } catch (e) { console.error('loadShifts error:', e); }
}

async function deleteWorkShift(workerId, shiftId) {
    if (!confirm('¿Eliminar este registro de horas?')) return;
    try {
        const res = await fetch(`${API}/api/admin/workers/${workerId}/shifts/${shiftId}`, {
            method: 'DELETE', headers: hdr()
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error al eliminar');
        toast('Turno eliminado');
        loadShifts(selectedWorkerId || null);
        calRenderWeek();
    } catch (e) { toast(e.message, 'error'); }
}

// ── Clock In / Out ──
function updateClockButtons(isClockedIn) {
    const btnIn = $('btnClockIn');
    const btnOut = $('btnClockOut');
    if (btnIn) { btnIn.disabled = isClockedIn; btnIn.style.opacity = isClockedIn ? '0.5' : '1'; }
    if (btnOut) { btnOut.disabled = !isClockedIn; btnOut.style.opacity = isClockedIn ? '1' : '0.5'; }
}

async function clockIn() {
    if (!selectedWorkerId) { toast('Selecciona un trabajador', 'error'); return; }
    try {
        const res = await fetch(`${API}/api/admin/workers/${selectedWorkerId}/clock-in`, { method: 'POST', headers: hdr() });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast('Entrada registrada');
        loadShifts(selectedWorkerId);
        calRenderWeek();
        loadWorkers();
    } catch (e) { toast(e.message, 'error'); }
}

async function clockOut() {
    if (!selectedWorkerId) { toast('Selecciona un trabajador', 'error'); return; }
    try {
        const res = await fetch(`${API}/api/admin/workers/${selectedWorkerId}/clock-out`, { method: 'POST', headers: hdr() });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast('Salida registrada');
        loadShifts(selectedWorkerId);
        calRenderWeek();
        loadWorkers();
    } catch (e) { toast(e.message, 'error'); }
}

// ═══════════════════════════════════════════════
// TAB 3: ANALÍTICAS
// ═══════════════════════════════════════════════

// ── Helper: percentage comparison ──
function fmtPct(current, prev) {
    const cur = parseFloat(current) || 0;
    const prv = parseFloat(prev) || 0;
    if (prv === 0 && cur === 0) return { text: '—', class: 'flat' };
    if (prv === 0) return { text: '— sin datos previos', class: 'flat' };
    const pct = ((cur - prv) / Math.abs(prv)) * 100;
    if (pct === 0) return { text: '0%', class: 'flat' };
    const sign = pct > 0 ? '+' : '';
    return { text: `${sign}${pct.toFixed(1)}%`, class: pct > 0 ? 'up' : 'down' };
}

// ── Helper: render product bar rows ──
function renderProductBars(containerId, items, valueKey) {
    const container = $(containerId);
    if (!container) return;
    if (!items || !items.length) {
        container.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">Sin datos</p>';
        return;
    }
    items = items.slice(0, 10);
    const maxVal = Math.max(...items.map(it => parseFloat(it[valueKey]) || 0));
    container.innerHTML = items.map(it => {
        const val = parseFloat(it[valueKey]) || 0;
        const pct = maxVal > 0 ? (val / maxVal) * 100 : 0;
        const displayVal = valueKey === 'revenue' ? fmt(val) : val;
        return `
            <div class="product-bar-row" style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
                <span style="flex:0 0 160px;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${esc(it.name)}">${esc(it.name)}</span>
                <div style="flex:1;background:rgba(255,255,255,0.06);border-radius:6px;height:22px;overflow:hidden;">
                    <div style="height:100%;width:${pct}%;background:var(--accent,#0071e3);border-radius:6px;transition:width .4s ease;"></div>
                </div>
                <span style="flex:0 0 80px;text-align:right;font-size:13px;font-weight:600;">${displayVal}</span>
            </div>`;
    }).join('');
}

// ── Helper: sales chart (doughnut) ──
let _salesChart = null;
function loadSalesChart(topProducts) {
    if (_salesChart) { _salesChart.destroy(); _salesChart = null; }

    const canvas = $('salesChart');
    const emptyEl = $('chartEmpty');
    if (!topProducts || !topProducts.length) {
        if (canvas) canvas.style.display = 'none';
        if (emptyEl) emptyEl.style.display = '';
        return;
    }
    if (canvas) canvas.style.display = '';
    if (emptyEl) emptyEl.style.display = 'none';

    function draw() {
        const ctx = canvas.getContext('2d');
        const palette = ['#6C5CE7', '#00B894', '#E17055', '#0984E3', '#FDCB6E', '#E84393', '#00CEC9', '#A29BFE'];
        const textColor = getComputedStyle(document.documentElement).getPropertyValue('--text-primary').trim() || '#333';

        _salesChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: topProducts.map(p => p.name),
                datasets: [{
                    data: topProducts.map(p => p.revenue),
                    backgroundColor: palette.slice(0, topProducts.length),
                    borderColor: 'transparent',
                    borderWidth: 2,
                    hoverOffset: 8,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                cutout: '55%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: textColor, padding: 12, font: { size: 11 }, usePointStyle: true, pointStyleWidth: 10 },
                    },
                    tooltip: { callbacks: { label: ctx => ' $' + ctx.parsed.toFixed(2) } },
                },
            },
        });
    }

    if (typeof Chart === 'undefined') {
        return new Promise((resolve) => {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4/dist/chart.umd.min.js';
            script.onload = () => { draw(); resolve(); };
            script.onerror = () => { console.error('Failed to load Chart.js'); resolve(); };
            document.head.appendChild(script);
        });
    }
    draw();
}

// ── Helper: status badge ──
function _statusBadge(status) {
    const s = (status || '').toLowerCase();
    const colors = {
        paid:      'background:var(--success-glow);color:var(--success);',
        completed: 'background:var(--accent-glow-strong);color:var(--accent);',
        pending:   'background:var(--warning-glow);color:var(--warning);',
    };
    const label = { paid: 'Pagado', completed: 'Completado', pending: 'Pendiente' }[s] || status || '—';
    return `<span style="padding:2px 8px;border-radius:6px;font-size:11px;font-weight:600;${colors[s] || ''}">${label}</span>`;
}

// ── Top Products Filters ──
let _brandsCache = null;
let _catsCache = null;

async function loadFilterOptions() {
    try {
        const [bRes, cRes] = await Promise.all([
            fetch(`${API}/api/catalog/brands`, { headers: hdr() }),
            fetch(`${API}/api/products/categories`, { headers: hdr() }),
        ]);
        if (bRes.ok) _brandsCache = (await bRes.json()).brands || [];
        if (cRes.ok) _catsCache = (await cRes.json()).categories || [];
    } catch (e) { console.warn('Filter load error:', e); }

    // Populate all 4 dropdowns
    ['qtyBrandFilter', 'revBrandFilter'].forEach(id => {
        const el = $(id);
        if (!el || !_brandsCache) return;
        el.innerHTML = '<option value="">Todas las marcas</option>' +
            _brandsCache.map(b => `<option value="${b.id}">${esc(b.name)}</option>`).join('');
    });
    ['qtyCatFilter', 'revCatFilter'].forEach(id => {
        const el = $(id);
        if (!el || !_catsCache) return;
        el.innerHTML = '<option value="">Todas las categorías</option>' +
            _catsCache.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
    });
}

async function applyTopFilters() {
    const brandFilter = $('qtyBrandFilter');
    const catFilter = $('qtyCatFilter');
    const revBrandFilter = $('revBrandFilter');
    const revCatFilter = $('revCatFilter');

    // Sync dropdowns across both sections
    const brandId = (brandFilter?.value || revBrandFilter?.value) || '';
    const catId = (catFilter?.value || revCatFilter?.value) || '';
    if (brandFilter && revBrandFilter) { revBrandFilter.value = brandFilter.value; brandFilter.value = revBrandFilter.value; }
    if (catFilter && revCatFilter) { revCatFilter.value = catFilter.value; catFilter.value = revCatFilter.value; }

    const sid = getStoreId();
    let url = `${API}/api/admin/analytics/comparison?`;
    if (sid) url += `store_id=${sid}&`;
    if (brandId) url += `brand_id=${brandId}&`;
    else if (catId) url += `category_id=${catId}&`;

    try {
        const res = await fetch(url, { headers: hdr() });
        if (!res.ok) return;
        const data = await res.json();
        renderProductBars('topQtyList', data.top_by_qty || [], 'qty');
        renderProductBars('topRevList', data.top_by_rev || [], 'revenue');
    } catch (e) { console.error('Filter error:', e); }
}

// ── Main analytics loader ──
async function loadAllStats() {
    try {
        // Fetch comparison analytics and worker stats in parallel
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const sidParam2 = sid ? `&store_id=${sid}` : '';
        const [compRes, workersRes] = await Promise.all([
            fetch(`${API}/api/admin/analytics/comparison${sidParam}`, { headers: hdr() }),
            fetch(`${API}/api/admin/workers/all-stats?days=30${sidParam2}`, { headers: hdr() })
        ]);

        // Process comparison data (non-fatal if endpoint doesn't exist yet)
        let compData = {};
        if (compRes.ok) {
            compData = await compRes.json();
        } else {
            console.warn('Analytics comparison endpoint returned', compRes.status);
        }

        // Process worker stats
        let workers = [];
        if (workersRes.ok) {
            const wData = await workersRes.json();
            workers = wData.workers || [];
        }

        // ── Summary Cards ──
        const today = compData.today || {};
        const week  = compData.week || {};
        const month = compData.month || {};
        const avgT  = compData.avg_ticket || {};

        function _setCompare(elId, cur, prev) {
            const el = $(elId);
            if (!el) return;
            const p = fmtPct(cur, prev);
            el.textContent = p.text;
            el.style.color = p.class === 'up' ? 'var(--success)' : p.class === 'down' ? 'var(--danger)' : 'var(--text-secondary)';
        }

        if ($('todayRevenue'))  $('todayRevenue').textContent  = fmt(today.current_revenue);
        _setCompare('todayCompare', today.current_revenue, today.prev_revenue);

        if ($('weekRevenue'))   $('weekRevenue').textContent   = fmt(week.current_revenue);
        _setCompare('weekCompare', week.current_revenue, week.prev_revenue);

        if ($('monthRevenue'))  $('monthRevenue').textContent  = fmt(month.current_revenue);
        _setCompare('monthCompare', month.current_revenue, month.prev_revenue);

        if ($('avgTicket'))     $('avgTicket').textContent     = fmt(avgT.current);
        _setCompare('ticketCompare', avgT.current, avgT.prev);

        // ── Top Products ──
        const topQty = compData.top_by_qty || [];
        const topRev = compData.top_by_rev || [];
        renderProductBars('topQtyList', topQty, 'qty');
        renderProductBars('topRevList', topRev, 'revenue');

        // ── Recent Orders ──
        const orders = compData.recent_orders || [];
        const tbody  = $('recentOrdersBody');
        const emptyO = $('recentOrdersEmpty');

        if (!orders.length) {
            if (tbody) tbody.innerHTML = '';
            if (emptyO) { emptyO.style.display = ''; emptyO.innerHTML = '<p style="color:var(--text-secondary);font-size:13px;">Sin pedidos recientes</p>'; }
        } else {
            if (emptyO) emptyO.style.display = 'none';
            if (tbody) {
                tbody.innerHTML = orders.map((o, i) => {
                    const dateStr = o.created_at ? new Date(o.created_at).toLocaleDateString('es', { day:'2-digit', month:'short', year:'numeric' }) : '—';
                    return `<tr>
                        <td>${i + 1}</td>
                        <td>${dateStr}</td>
                        <td>${esc(o.worker_name || '—')}</td>
                        <td>${fmt(o.total || o.total_amount || 0)}</td>
                        <td>${_statusBadge(o.status)}</td>
                    </tr>`;
                }).join('');
            }
        }

        // ── Worker Ranking ──
        const rankBody = $('rankingBody');
        const rankEmpty = $('rankingEmpty');
        const sorted = [...workers].sort((a, b) => (b.total_revenue || 0) - (a.total_revenue || 0));

        if (!sorted.length) {
            if (rankBody) rankBody.innerHTML = '';
            if (rankEmpty) { rankEmpty.style.display = ''; rankEmpty.innerHTML = '<p>Sin datos de ventas.</p>'; }
        } else {
            if (rankEmpty) rankEmpty.style.display = 'none';
            if (rankBody) {
                const medals = ['🥇', '🥈', '🥉'];
                rankBody.innerHTML = sorted.map((w, i) => {
                    return `<tr>
                        <td style="font-size:18px;">${medals[i] || (i + 1)}</td>
                        <td><strong>${esc(w.name)}</strong></td>
                        <td>${w.total_orders || 0}</td>
                        <td>${fmt(w.total_revenue || 0)}</td>
                        <td>${fmtHours(w.total_hours || 0)}</td>
                        <td><span style="padding:2px 8px;border-radius:6px;font-size:11px;font-weight:600;${w.active ? 'background:var(--success-glow);color:var(--success)' : 'background:var(--danger-glow);color:var(--danger)'}">${w.active ? 'Activo' : 'Inactivo'}</span></td>
                    </tr>`;
                }).join('');
            }
        }

    } catch (e) { console.error('loadAllStats error:', e); }
}

// ═══════════════════════════════════════════════
// MODALS
// ═══════════════════════════════════════════════
function openCreateModal() { $('modalCreate').classList.add('open'); }
function closeCreateModal() { $('modalCreate').classList.remove('open'); $('createForm')?.reset(); }

async function submitCreate(e) {
    e.preventDefault();
    const name = $('createName')?.value?.trim();
    const email = $('createEmail')?.value?.trim();
    const phone = $('createPhone')?.value?.trim();
    const password = $('createPassword')?.value;
    const role = $('createRole')?.value || 'worker';
    if (!name || !email || !password) { toast('Completa nombre, email y contraseña', 'error'); return; }
    try {
        const res = await fetch(`${API}/api/auth/register-worker`, {
            method: 'POST', headers: hdr(),
            body: JSON.stringify({ name, email, phone, password, role }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast('Trabajador creado');
        closeCreateModal();
        loadWorkers();
    } catch (e) { toast(e.message, 'error'); }
}

function openEditModal(id) {
    const w = allWorkers.find(x => x.id === id);
    if (!w) return;
    $('editWorkerId').value = id;
    $('editName').value = w.name || '';
    $('editEmail').value = w.email || '';
    $('editPhone').value = w.phone || '';
    $('modalEdit').classList.add('open');
}
function closeEditModal() { $('modalEdit').classList.remove('open'); }

async function submitEdit(e) {
    e.preventDefault();
    const id = $('editWorkerId')?.value;
    const name = $('editName')?.value?.trim();
    const email = $('editEmail')?.value?.trim();
    const phone = $('editPhone')?.value?.trim();
    try {
        const res = await fetch(`${API}/api/auth/workers/${id}`, {
            method: 'PUT', headers: hdr(),
            body: JSON.stringify({ name, email, phone, password: '' }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast('Trabajador actualizado');
        closeEditModal();
        loadWorkers();
    } catch (e) { toast(e.message, 'error'); }
}

function openResetModal(id, name) {
    $('resetWorkerId').value = id;
    $('resetWorkerName').textContent = name;
    $('modalReset').classList.add('open');
}
function closeResetModal() { $('modalReset').classList.remove('open'); $('resetForm')?.reset(); }

async function submitReset(e) {
    e.preventDefault();
    const id = $('resetWorkerId')?.value;
    const password = $('resetPassword')?.value;
    const confirm = $('resetConfirm')?.value;
    if (password !== confirm) { toast('Las contraseñas no coinciden', 'error'); return; }
    try {
        const res = await fetch(`${API}/api/auth/workers/${id}/reset-password`, {
            method: 'POST', headers: hdr(),
            body: JSON.stringify({ password }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast('Contraseña actualizada');
        closeResetModal();
    } catch (e) { toast(e.message, 'error'); }
}

async function toggleActive(id, isActive) {
    const action = isActive ? 'desactivar' : 'activar';
    if (!confirm(`¿${action.charAt(0).toUpperCase() + action.slice(1)} este trabajador?`)) return;
    try {
        let res;
        if (isActive) {
            res = await fetch(`${API}/api/auth/workers/${id}`, { method: 'DELETE', headers: hdr() });
        } else {
            res = await fetch(`${API}/api/auth/workers/${id}/reactivate`, { method: 'PUT', headers: hdr() });
        }
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error');
        toast(`Trabajador ${action}do`);
        loadWorkers();
    } catch (e) { toast(e.message, 'error'); }
}

// ═══════════════════════════════════════════════
// SCHEDULED SHIFTS MODAL
// ═══════════════════════════════════════════════

async function openScheduledShiftModal(workerId, dateStr, shiftId) {
    const modal = $('modalScheduledShift');
    if (!modal) return;

    // Store state
    $('schedWorkerId').value = workerId;
    $('schedDate').value = dateStr;
    $('schedShiftId').value = shiftId;

    // Find worker name
    const worker = allWorkers.find(w => w.id === workerId);
    const workerName = worker ? worker.name : 'Trabajador';

    // Format date for display
    const displayDate = new Date(dateStr + 'T00:00:00').toLocaleDateString('es', {
        weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
    });

    // Set subtitle
    const subtitle = $('schedModalSubtitle');
    if (subtitle) subtitle.textContent = `${workerName} — ${displayDate}`;

    const deleteBtn = $('schedDeleteBtn');
    const titleEl = $('schedModalTitle');

    if (shiftId > 0) {
        // EDIT mode — fetch shift data
        if (titleEl) titleEl.textContent = 'Editar Turno';
        if (deleteBtn) deleteBtn.style.display = '';

        try {
            const res = await fetch(`${API}/api/admin/scheduled-shifts/${shiftId}`, { headers: hdr() });
            if (res.ok) {
                const data = await res.json();
                const ss = data.shift || data;
                $('schedStartTime').value = ss.start_time || '09:00';
                $('schedEndTime').value = ss.end_time || '17:00';
                $('schedNotes').value = ss.notes || '';
            } else {
                // Fallback defaults
                $('schedStartTime').value = '09:00';
                $('schedEndTime').value = '17:00';
                $('schedNotes').value = '';
            }
        } catch (e) {
            console.error('Error loading scheduled shift:', e);
            $('schedStartTime').value = '09:00';
            $('schedEndTime').value = '17:00';
            $('schedNotes').value = '';
        }
    } else {
        // CREATE mode
        if (titleEl) titleEl.textContent = 'Programar Turno';
        if (deleteBtn) deleteBtn.style.display = 'none';
        $('schedStartTime').value = '09:00';
        $('schedEndTime').value = '17:00';
        $('schedNotes').value = '';
    }

    modal.classList.add('open');
}

function closeModal(modalId) {
    const el = document.getElementById(modalId);
    if (el) el.classList.remove('open');
}

function closeScheduledShiftModal() {
    const modal = $('modalScheduledShift');
    if (modal) modal.classList.remove('open');
}

async function submitScheduledShift(e) {
    e.preventDefault();

    const workerId = parseInt($('schedWorkerId').value);
    const date = $('schedDate').value;
    const shiftId = parseInt($('schedShiftId').value) || 0;
    const start_time = $('schedStartTime').value;
    const end_time = $('schedEndTime').value;
    const notes = $('schedNotes')?.value || '';

    if (!workerId || !date || !start_time || !end_time) {
        toast('Completa todos los campos', 'error');
        return;
    }

    try {
        let res;
        if (shiftId > 0) {
            // UPDATE
            res = await fetch(`${API}/api/admin/scheduled-shifts/${shiftId}`, {
                method: 'PUT',
                headers: hdr(),
                body: JSON.stringify({ start_time, end_time, notes })
            });
        } else {
            // CREATE
            res = await fetch(`${API}/api/admin/scheduled-shifts`, {
                method: 'POST',
                headers: hdr(),
                body: JSON.stringify({ worker_id: workerId, date, start_time, end_time, notes })
            });
        }

        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error al guardar turno');

        closeScheduledShiftModal();
        calRenderWeek();
        toast(shiftId > 0 ? 'Turno actualizado' : 'Turno programado');
    } catch (e) {
        toast(e.message, 'error');
    }
}

async function deleteScheduledShift() {
    const shiftId = parseInt($('schedShiftId').value) || 0;
    if (!shiftId) return;

    if (!confirm('¿Eliminar este turno programado?')) return;

    try {
        const res = await fetch(`${API}/api/admin/scheduled-shifts/${shiftId}`, {
            method: 'DELETE',
            headers: hdr()
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error al eliminar');

        closeScheduledShiftModal();
        calRenderWeek();
        toast('Turno eliminado');
    } catch (e) {
        toast(e.message, 'error');
    }
}

async function copyWeek() {
    // Calculate current week start
    const fromStart = fmtDateISO(calWeekStart);

    // Default target = next week
    const nextWeek = fmtDateISO(addDays(calWeekStart, 7));
    const targetInput = prompt(`Copiar programación de esta semana a:\n(YYYY-MM-DD)`, nextWeek);

    if (!targetInput) return;

    // Validate date format
    if (!/^\d{4}-\d{2}-\d{2}$/.test(targetInput)) {
        toast('Formato de fecha inválido (usa YYYY-MM-DD)', 'error');
        return;
    }

    try {
        const res = await fetch(`${API}/api/admin/scheduled-shifts/copy-week?from_start=${fromStart}&to_start=${targetInput}`, {
            method: 'POST',
            headers: hdr()
        });

        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'Error al copiar semana');

        // Navigate to target week
        calWeekStart = getMonday(new Date(targetInput + 'T00:00:00'));
        updateWeekLabel();
        calRenderWeek();
        toast('Semana copiada correctamente');
    } catch (e) {
        toast(e.message, 'error');
    }
}

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
    loadWorkers();
    // Auto-select tab from URL hash (e.g. /admin/workers#analytics)
    const hash = window.location.hash.replace('#', '');
    if (hash && ['list', 'hours', 'analytics'].includes(hash)) {
        showTab(hash);
    }
});

/* Worker JavaScript - Inventory (status toggle only), Scanner, Orders */
const API = '';
const token = localStorage.getItem('token');
const headers = { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
}

function updateNav() {
    const user = JSON.parse(localStorage.getItem('user'));
    const nav = document.getElementById('userNav');
    if (nav && user) nav.innerHTML = `<span class="user-badge">${user.name}</span>`;
    const nameEl = document.getElementById('workerName');
    if (nameEl && user) nameEl.textContent = `Hola, ${user.name}`;
}

// Tab switching
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(tab.dataset.tab).classList.add('active');
        if (tab.dataset.tab === 'inventory') loadInventory();
        if (tab.dataset.tab === 'orders') loadPendingOrders();
    });
});

async function loadInventory() {
    const res = await fetch(`${API}/api/products`, { headers });
    const { products } = await res.json();
    const container = document.getElementById('inventory');
    container.innerHTML = `
        <div class="inventory-header">
            <h2>Inventario</h2>
        </div>
        <div class="inventory-list">
            ${products.map(p => {
                let statusText = '✅ Disponible';
                let statusClass = 'available';
                if (p.out_of_service) { statusText = '🔴 Fuera de servicio'; statusClass = 'unavailable'; }
                else if (p.stock <= 0) { statusText = '⚠️ Sin stock'; statusClass = 'out'; }

                return `
                <div class="inventory-item ${p.out_of_service ? 'unavailable' : ''}">
                    <div class="item-info">
                        <strong>${p.name}</strong>
                        <span class="stock">Stock: ${p.stock}</span>
                        <span class="status-badge ${statusClass}">${statusText}</span>
                    </div>
                    <div class="item-actions">
                        <button class="btn-sm" onclick="toggleService(${p.id})"
                                title="${p.out_of_service ? 'Poner disponible' : 'Poner fuera de servicio'}">
                            ${p.out_of_service ? '✅ Disponible' : '🔴 Fuera de servicio'}
                        </button>
                        <button class="btn-sm ${p.stock > 0 ? 'danger' : 'warning'}"
                                onclick="toggleStock(${p.id})"
                                title="${p.stock > 0 ? 'Marcar sin stock' : 'Restaurar stock'}">
                            ${p.stock > 0 ? '📦 Sin stock' : '📦 Restaurar stock'}
                        </button>
                    </div>
                </div>
            `}).join('')}
        </div>
    `;
}

async function toggleService(productId) {
    await fetch(`${API}/api/products/${productId}/toggle-service`, { method: 'POST', headers });
    loadInventory();
}

async function toggleStock(productId) {
    await fetch(`${API}/api/products/${productId}/toggle-stock`, { method: 'POST', headers });
    loadInventory();
}

async function scanBarcode() {
    const code = document.getElementById('barcodeInput').value;
    if (!code) return;
    const res = await fetch(`${API}/api/products?barcode=${code}`, { headers });
    const { products } = await res.json();
    const container = document.getElementById('scanResult');
    if (products.length === 0) {
        container.innerHTML = '<p class="error">Producto no encontrado</p>';
    } else {
        const p = products[0];
        let statusText = '✅ Disponible';
        if (p.out_of_service) statusText = '🔴 Fuera de servicio';
        else if (p.stock <= 0) statusText = '⚠️ Sin stock';

        container.innerHTML = `
            <div class="scan-result">
                <h3>${p.name}</h3>
                <p>Stock: ${p.stock} | ${statusText}</p>
                <div class="scan-actions">
                    <button class="btn-sm" onclick="toggleService(${p.id}); scanBarcode();">
                        ${p.out_of_service ? '✅ Activar' : '🔴 Desactivar'}
                    </button>
                    <button class="btn-sm ${p.stock > 0 ? 'danger' : 'warning'}"
                            onclick="toggleStock(${p.id}); scanBarcode();">
                        ${p.stock > 0 ? '📦 Sin stock' : '📦 Restaurar'}
                    </button>
                </div>
            </div>
        `;
    }
}

async function loadPendingOrders() {
    const res = await fetch(`${API}/api/orders/pending`, { headers });
    const { orders } = await res.json();
    const container = document.getElementById('orders');
    container.innerHTML = orders.length === 0
        ? '<p class="empty">No hay pedidos pendientes 🎉</p>'
        : orders.map(o => `
            <div class="order-card">
                <div class="order-header">
                    <strong>Pedido #${o.id}</strong>
                    <span class="client-name">👤 ${o.client_name}</span>
                </div>
                <div class="order-items">
                    ${o.items.map(i => `<span>${i.quantity}x ${i.product_name}</span>`).join('')}
                </div>
                <div class="order-total">Total: $${o.total.toFixed(2)}</div>
                <div class="order-actions">
                    <button class="btn primary" onclick="payOrder(${o.id})">💰 Cobrar</button>
                    <button class="btn secondary" onclick="cancelOrder(${o.id})">Cancelar</button>
                </div>
            </div>
        `).join('');
}

async function payOrder(orderId) {
    const user = JSON.parse(localStorage.getItem('user'));
    await fetch(`${API}/api/orders/${orderId}/pay`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ worker_id: user.id }),
    });
    alert('✅ Pedido cobrado');
    loadPendingOrders();
}

async function cancelOrder(orderId) {
    if (!confirm('¿Cancelar este pedido?')) return;
    await fetch(`${API}/api/orders/${orderId}/cancel`, { method: 'POST', headers });
    loadPendingOrders();
}

document.addEventListener('DOMContentLoaded', () => {
    updateNav();
    loadInventory();
});

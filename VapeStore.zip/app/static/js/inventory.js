/* ═══════════════════════════════════════════════════
   VapeStore - Inventario JavaScript
   Hierarchical tree: Categories → Brands → Models → Options
   ═══════════════════════════════════════════════════ */

const API = '';

// ── Auth ─────────────────────────────────────────
const token = localStorage.getItem('token');
if (!token) window.location.href = '/login';

const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
};

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
}

function updateNav() {
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    const nav = document.getElementById('userNav');
    if (nav && user) nav.innerHTML = `<span class="user-badge">${user.name} (${user.role})</span>`;
}

// ── Theme ────────────────────────────────────────
// Handled by settings.js (applyTheme, setTheme, cycleTheme)

// ── State ────────────────────────────────────────
let catalogTree = [];
let selectedBrandId = null;
let searchQuery = '';

// Category icons
const catIcons = {
    'desechable': '💨', 'jugo': '🧪', 'dispositivos': '📱',
    'cartuchos': '🔋', 'semi-desechable': '🔄',
};

// ── API helpers ──────────────────────────────────
async function api(url, opts = {}) {
    try {
        const res = await fetch(`${API}${url}`, { headers, ...opts });
        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            throw new Error(data.detail || `Error ${res.status}`);
        }
        return res.json();
    } catch (e) {
        toast(e.message, 'error');
        throw e;
    }
}

// ── Toast ────────────────────────────────────────
function toast(msg, type = 'success') {
    const el = document.getElementById('toast');
    el.textContent = (type === 'success' ? '✅ ' : '❌ ') + msg;
    el.className = `toast ${type} show`;
    setTimeout(() => el.classList.remove('show'), 3000);
}

// ── Modals ───────────────────────────────────────
function showModal(id) {
    document.getElementById(id).classList.remove('hidden');
}
function closeModal(id) {
    document.getElementById(id).classList.add('hidden');
}

// Close modals on backdrop click
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal') && !e.target.classList.contains('hidden')) {
        e.target.classList.add('hidden');
    }
});

// ── Confirm dialog ───────────────────────────────
function confirmAction(text) {
    return new Promise((resolve) => {
        document.getElementById('confirmText').innerHTML = text;
        const btn = document.getElementById('confirmYesBtn');
        const handler = () => { btn.removeEventListener('click', handler); resolve(true); };
        btn.addEventListener('click', () => { closeModal('confirmModal'); resolve(true); });
        showModal('confirmModal');
    });
}

// ── Load catalog tree ────────────────────────────
async function loadTree() {
    try {
        const data = await api('/api/catalog/tree');
        catalogTree = data.tree || [];
        renderTree();
    } catch (e) {
        document.getElementById('sidebarTree').innerHTML =
            '<div class="empty-state"><div class="empty-icon">⚠️</div><p>Error al cargar el catálogo</p></div>';
    }
}

// ── Render tree ──────────────────────────────────
function renderTree() {
    const container = document.getElementById('sidebarTree');
    if (catalogTree.length === 0) {
        container.innerHTML = '<div class="empty-state"><div class="empty-icon">📂</div><p>No hay categorías</p></div>';
        return;
    }

    let html = '';
    for (const cat of catalogTree) {
        const catName = cat.name || 'Sin nombre';
        const icon = catIcons[catName.toLowerCase()] || '📁';
        const brandCount = (cat.brands || []).length;

        // Filter check
        if (searchQuery && !matchesSearch(cat)) continue;

        html += `<div class="tree-node tree-cat" data-cat-id="${cat.id}">
            <div class="tree-row" onclick="toggleNode(this)">
                <span class="tree-chevron">▶</span>
                <span class="tree-icon">${icon}</span>
                <span class="tree-label">${catName}</span>
                <span class="tree-count">${brandCount} marca${brandCount !== 1 ? 's' : ''}</span>
                <div class="tree-actions">
                    <button class="tree-action-btn" onclick="event.stopPropagation();openBrandModal(${cat.id})" title="Añadir marca">+</button>
                </div>
            </div>
            <div class="tree-children collapsed">`;

        for (const brand of (cat.brands || [])) {
            const brandIcon = brand.logo_url
                ? `<img src="${brand.logo_url}" style="width:18px;height:18px;border-radius:4px;object-fit:cover;" alt="">`
                : '🏷️';
            const modelCount = (brand.models || []).length;

            if (searchQuery && !matchesSearchBrand(brand, cat)) continue;

            html += `<div class="tree-node tree-brand" data-brand-id="${brand.id}">
                <div class="tree-row" onclick="selectBrand(${brand.id}, event)">
                    <span class="tree-chevron" onclick="event.stopPropagation();toggleNode(this.parentElement)">▶</span>
                    <span class="tree-icon">${brandIcon}</span>
                    <span class="tree-label">${brand.name}</span>
                    <span class="tree-count">${modelCount} modelo${modelCount !== 1 ? 's' : ''}</span>
                    <div class="tree-actions">
                        <button class="tree-action-btn" onclick="event.stopPropagation();openBrandModal(${cat.id},${brand.id})" title="Editar">✏️</button>
                        <button class="tree-action-btn danger" onclick="event.stopPropagation();deleteBrand(${brand.id},'${brand.name.replace(/'/g,"\\'")}')" title="Eliminar">🗑️</button>
                    </div>
                </div>
                <div class="tree-children collapsed">`;

            for (const model of (brand.models || [])) {
                const optionCount = model.option_count || (model.options || []).length;

                html += `<div class="tree-node tree-model" data-model-id="${model.id}">
                    <div class="tree-row" onclick="toggleNode(this)">
                        <span class="tree-chevron">▶</span>
                        <span class="tree-icon">📦</span>
                        <span class="tree-label">${model.name}</span>
                        <span class="tree-count">${optionCount} opción${optionCount !== 1 ? 'es' : ''}</span>
                    </div>
                    <div class="tree-children collapsed">
                        <div class="tree-node tree-option" style="padding-left:40px;">
                            <div class="tree-row">
                                <span class="tree-icon">•</span>
                                <span class="tree-label" style="color:var(--text-secondary);font-style:italic;font-size:12px;">Haz clic en la marca para ver opciones</span>
                            </div>
                        </div>
                    </div>
                </div>`;
            }

            html += `</div></div>`;
        }

        html += `</div></div>`;
    }

    container.innerHTML = html;
}

// ── Search filter ────────────────────────────────
function matchesSearch(cat) {
    for (const brand of (cat.brands || [])) {
        if (brand.name.toLowerCase().includes(searchQuery)) return true;
        for (const model of (brand.models || [])) {
            if (model.name.toLowerCase().includes(searchQuery)) return true;
        }
    }
    return false;
}

function matchesSearchBrand(brand, cat) {
    if (brand.name.toLowerCase().includes(searchQuery)) return true;
    for (const model of (brand.models || [])) {
        if (model.name.toLowerCase().includes(searchQuery)) return true;
    }
    return false;
}

function filterTree(query) {
    searchQuery = query.trim().toLowerCase();
    renderTree();
    // Auto-expand matching nodes
    if (searchQuery) {
        document.querySelectorAll('.tree-children.collapsed').forEach(el => {
            el.classList.remove('collapsed');
            el.previousElementSibling?.classList.add('expanded');
        });
    }
}

// ── Tree toggle ──────────────────────────────────
function toggleNode(row) {
    const children = row.parentElement.querySelector(':scope > .tree-children');
    if (!children) return;
    const isCollapsed = children.classList.contains('collapsed');
    children.classList.toggle('collapsed');
    row.classList.toggle('expanded', isCollapsed);
}

// ── Select brand ─────────────────────────────────
async function selectBrand(brandId, event) {
    if (event) event.stopPropagation();

    // Highlight in tree
    document.querySelectorAll('.tree-row.selected').forEach(el => el.classList.remove('selected'));
    const brandNode = document.querySelector(`.tree-brand[data-brand-id="${brandId}"] > .tree-row`);
    if (brandNode) brandNode.classList.add('selected');

    // Expand children
    const children = document.querySelector(`.tree-brand[data-brand-id="${brandId}"] > .tree-children`);
    if (children && children.classList.contains('collapsed')) {
        children.classList.remove('collapsed');
        brandNode?.classList.add('expanded');
    }

    selectedBrandId = brandId;
    await loadBrandDetail(brandId);

    // Close sidebar on mobile after selecting a brand
    if (typeof closeSidebar === 'function' && window.innerWidth <= 1024) {
        closeSidebar();
    }
}

// ── Load brand detail ────────────────────────────
async function loadBrandDetail(brandId) {
    const panel = document.getElementById('detailPanel');
    panel.innerHTML = '<div class="loading-spinner">Cargando...</div>';

    try {
        const brand = await api(`/api/catalog/brands/${brandId}`);
        renderBrandDetail(brand);
    } catch (e) {
        panel.innerHTML = '<div class="empty-state"><div class="empty-icon">⚠️</div><p>Error al cargar la marca</p></div>';
    }
}

// ── Render brand detail ──────────────────────────
function renderBrandDetail(brand) {
    const panel = document.getElementById('detailPanel');
    const logoHtml = brand.logo_url
        ? `<img src="${brand.logo_url}" alt="${brand.name}">`
        : '🏷️';

    let modelsHtml = '';
    const models = brand.models || [];

    if (models.length === 0) {
        modelsHtml = `
            <div class="empty-state">
                <div class="empty-icon">📦</div>
                <p>No hay modelos. Agrega el primero.</p>
            </div>`;
    } else {
        for (const model of models) {
            modelsHtml += renderModelCard(model);
        }
    }

    panel.innerHTML = `
        <div class="detail-header">
            <div class="brand-logo">${logoHtml}</div>
            <div class="brand-info">
                <h1>${brand.name}</h1>
                <div class="brand-meta">${brand.category_name || 'Sin categoría'} · ${models.length} modelo${models.length !== 1 ? 's' : ''}</div>
            </div>
            <div class="header-actions">
                <button class="btn-sm primary" onclick="openBrandModal(${brand.category_id},${brand.id})">✏️ Editar Marca</button>
                <button class="btn-sm danger" onclick="deleteBrand(${brand.id},'${brand.name.replace(/'/g,"\\'")}')">🗑️ Eliminar</button>
            </div>
        </div>

        <div class="models-section">
            <h2>📦 Modelos <button class="btn-sm primary" onclick="openModelModal(${brand.id})" style="font-size:12px;padding:6px 12px;">+ Nuevo</button></h2>
            ${modelsHtml}
        </div>

        <button class="add-model-btn" onclick="openModelModal(${brand.id})">
            + Agregar Modelo
        </button>
    `;
}

// ── Render model card ────────────────────────────
function renderModelCard(model) {
    const options = model.options || [];
    let optionsHtml = '';

    if (options.length === 0) {
        optionsHtml = '<div class="empty-state" style="padding:16px;"><p style="font-size:13px;">Sin opciones. Agrega la primera.</p></div>';
    } else {
        optionsHtml = '<div class="options-list">';
        for (const opt of options) {
            const typeClass = ['flavor', 'color', 'size'].includes(opt.option_type) ? opt.option_type : 'default';
            const stockClass = opt.stock > 10 ? 'ok' : opt.stock > 0 ? 'low' : 'out';
            optionsHtml += `
                <div class="option-item">
                    <span class="option-name">${opt.name}</span>
                    <span class="option-type ${typeClass}">${opt.option_type || '—'}</span>
                    <span class="option-price">$${parseFloat(opt.price || 0).toFixed(2)}</span>
                    <span class="option-stock ${stockClass}">${opt.stock ?? 0}</span>
                    <span class="option-barcode">${opt.barcode || '—'}</span>
                    <div class="option-actions">
                        <button class="tree-action-btn" onclick="openOptionModal(${model.id},${opt.id})" title="Editar">✏️</button>
                        <button class="tree-action-btn danger" onclick="deleteOption(${opt.id},'${opt.name.replace(/'/g,"\\'")}')" title="Eliminar">🗑️</button>
                    </div>
                </div>`;
        }
        optionsHtml += '</div>';
    }

    return `
        <div class="model-card" data-model-id="${model.id}">
            <div class="model-card-header">
                <h3>📦 ${model.name}</h3>
                <div class="model-actions">
                    <button class="btn-sm primary" onclick="openOptionModal(${model.id})">+ Opción</button>
                    <button class="btn-sm" onclick="openModelModal(${selectedBrandId},${model.id})">✏️</button>
                    <button class="btn-sm danger" onclick="deleteModel(${model.id},'${model.name.replace(/'/g,"\\'")}')">🗑️</button>
                </div>
            </div>
            ${model.description ? `<div class="model-desc">${model.description}</div>` : ''}
            ${optionsHtml}
        </div>`;
}

// ═══════════════════════════════════════════════════
// CRUD: Brands
// ═══════════════════════════════════════════════════

function openBrandModal(categoryId, editId = null) {
    document.getElementById('brandCategoryId').value = categoryId;
    document.getElementById('brandEditId').value = editId || '';
    document.getElementById('brandForm').reset();
    if (editId) {
        let brand = null;
        for (const cat of catalogTree) {
            if (cat.brands) brand = cat.brands.find(b => b.id === editId);
            if (brand) break;
        }
        if (brand) {
            document.getElementById('brandName').value = brand.name || '';
            document.getElementById('brandLogoUrl').value = brand.logo_url || '';
            document.getElementById('brandModalTitle').textContent = 'Editar Marca';
            document.getElementById('brandSubmitBtn').textContent = 'Guardar Cambios';
        }
    } else {
        document.getElementById('brandModalTitle').textContent = 'Nueva Marca';
        document.getElementById('brandSubmitBtn').textContent = 'Crear Marca';
    }
    showModal('brandModal');
    document.getElementById('brandName').focus();
}

document.getElementById('brandForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const editId = document.getElementById('brandEditId').value;
    const categoryId = document.getElementById('brandCategoryId').value;
    const body = {
        name: document.getElementById('brandName').value.trim(),
        logo_url: document.getElementById('brandLogoUrl').value.trim() || null,
    };
    if (!body.name) { toast('El nombre es requerido', 'error'); return; }
    try {
        if (editId) {
            await api(`/api/catalog/brands/${editId}`, { method: 'PUT', body: JSON.stringify(body) });
            toast('Marca actualizada');
        } else {
            body.category_id = parseInt(categoryId);
            await api('/api/catalog/brands', { method: 'POST', body: JSON.stringify(body) });
            toast('Marca creada');
        }
        closeModal('brandModal');
        await loadTree();
        if (selectedBrandId) await loadBrandDetail(selectedBrandId);
    } catch (e) { /* toast already shown */ }
});

async function deleteBrand(id, name) {
    const ok = await confirmAction(`¿Eliminar la marca <strong>${name}</strong>?<br>Se desactivarán todos sus modelos y opciones.`);
    if (!ok) return;
    try {
        await api(`/api/catalog/brands/${id}`, { method: 'DELETE' });
        toast('Marca eliminada');
        if (selectedBrandId === id) {
            selectedBrandId = null;
            document.getElementById('detailPanel').innerHTML = `
                <div class="detail-placeholder">
                    <div class="big-icon">📦</div>
                    <p>Selecciona una marca del árbol para ver sus detalles</p>
                </div>`;
        }
        await loadTree();
    } catch (e) { /* toast already shown */ }
}

// ═══════════════════════════════════════════════════
// CRUD: Models
// ═══════════════════════════════════════════════════

function openModelModal(brandId, editId = null) {
    document.getElementById('modelBrandId').value = brandId;
    document.getElementById('modelEditId').value = editId || '';
    document.getElementById('modelForm').reset();
    if (editId) {
        let model = null;
        for (const cat of catalogTree) {
            if (cat.brands) {
                for (const brand of cat.brands) {
                    if (brand.models) model = brand.models.find(m => m.id === editId);
                    if (model) break;
                }
            }
            if (model) break;
        }
        if (model) {
            document.getElementById('modelName').value = model.name || '';
            document.getElementById('modelDescription').value = model.description || '';
            document.getElementById('modelModalTitle').textContent = 'Editar Modelo';
            document.getElementById('modelSubmitBtn').textContent = 'Guardar Cambios';
        }
    } else {
        document.getElementById('modelModalTitle').textContent = 'Nuevo Modelo';
        document.getElementById('modelSubmitBtn').textContent = 'Crear Modelo';
    }
    showModal('modelModal');
    document.getElementById('modelName').focus();
}

document.getElementById('modelForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const editId = document.getElementById('modelEditId').value;
    const body = {
        name: document.getElementById('modelName').value.trim(),
        description: document.getElementById('modelDescription').value.trim() || null,
    };
    if (!body.name) { toast('El nombre es requerido', 'error'); return; }
    try {
        if (editId) {
            await api(`/api/catalog/models/${editId}`, { method: 'PUT', body: JSON.stringify(body) });
            toast('Modelo actualizado');
        } else {
            body.brand_id = parseInt(document.getElementById('modelBrandId').value);
            await api('/api/catalog/models', { method: 'POST', body: JSON.stringify(body) });
            toast('Modelo creado');
        }
        closeModal('modelModal');
        await loadTree();
        if (selectedBrandId) await loadBrandDetail(selectedBrandId);
    } catch (e) { /* toast already shown */ }
});

async function deleteModel(id, name) {
    const ok = await confirmAction(`¿Eliminar el modelo <strong>${name}</strong>?<br>Se desactivarán todas sus opciones.`);
    if (!ok) return;
    try {
        await api(`/api/catalog/models/${id}`, { method: 'DELETE' });
        toast('Modelo eliminado');
        await loadTree();
        if (selectedBrandId) await loadBrandDetail(selectedBrandId);
    } catch (e) { /* toast already shown */ }
}
// ═══════════════════════════════════════════════════
// CRUD: Options (category-aware)
// ═══════════════════════════════════════════════════

// ── Category-aware option field schemas ────────────
const OPTION_FIELDS = {
    'desechable': [
        { id: 'optionName',      label: 'Nombre (Sabor)',     type: 'text',     placeholder: 'Ej: Fresa Ice', required: true },
        { id: 'optionFamilia',   label: 'Familia',            type: 'text',     placeholder: 'Ej: Edición Especial, Summer, etc.' },
        { id: 'optionPrice',     label: 'Precio ($)',         type: 'number',   step: '0.01', min: '0', required: true, grid: true },
        { id: 'optionStock',     label: 'Stock',              type: 'number',   min: '0', value: '0', required: true, grid: true },
        { id: 'optionBarcode',   label: 'Código de barras',   type: 'text',     placeholder: 'Ej: 7501234567890' },
        { id: 'optionImageUrl',  label: 'Foto (URL)',         type: 'url',      placeholder: 'https://ejemplo.com/foto.jpg' },
    ],
    'jugo': [
        { id: 'optionName',      label: 'Nombre (Sabor)',     type: 'text',     placeholder: 'Ej: Fresa Ice', required: true },
        { id: 'optionFamilia',   label: 'Familia',            type: 'text',     placeholder: 'Ej: Edition, Summer, etc.' },
        { id: 'optionNicotine',  label: 'Nicotina (mg)',      type: 'select',   options: [
            { value: '0',  label: '0 mg' },
            { value: '3',  label: '3 mg' },
            { value: '6',  label: '6 mg' },
            { value: '10', label: '10 mg' },
            { value: '12', label: '12 mg' },
            { value: '15', label: '15 mg' },
            { value: '20', label: '20 mg' },
        ]},
        { id: 'optionPrice',     label: 'Precio ($)',         type: 'number',   step: '0.01', min: '0', required: true, grid: true },
        { id: 'optionStock',     label: 'Stock',              type: 'number',   min: '0', value: '0', required: true, grid: true },
        { id: 'optionBarcode',   label: 'Código de barras',   type: 'text',     placeholder: 'Ej: 7501234567890' },
        { id: 'optionImageUrl',  label: 'Foto (URL)',         type: 'url',      placeholder: 'https://ejemplo.com/foto.jpg' },
    ],
    'dispositivos': [
        { id: 'optionName',      label: 'Nombre (Color)',     type: 'text',     placeholder: 'Ej: Negro Mate', required: true },
        { id: 'optionFamilia',   label: 'Familia',            type: 'text',     placeholder: 'Ej: Edición Especial' },
        { id: 'optionDeviceType', label: 'Tipo',              type: 'select',   options: [
            { value: 'kit',  label: 'Kit' },
            { value: 'tank', label: 'Tank' },
        ]},
        { id: 'optionPrice',     label: 'Precio ($)',         type: 'number',   step: '0.01', min: '0', required: true, grid: true },
        { id: 'optionStock',     label: 'Stock',              type: 'number',   min: '0', value: '0', required: true, grid: true },
        { id: 'optionBarcode',   label: 'Código de barras',   type: 'text',     placeholder: 'Ej: 7501234567890' },
        { id: 'optionImageUrl',  label: 'Foto (URL)',         type: 'url',      placeholder: 'https://ejemplo.com/foto.jpg' },
    ],
    'cartuchos': [
        { id: 'optionName',      label: 'Nombre (Cartucho)',  type: 'text',     placeholder: 'Ej: Voopoo PnP', required: true },
        { id: 'optionFamilia',   label: 'Familia',            type: 'text',     placeholder: 'Ej: Edición Especial' },
        { id: 'optionOhm',       label: 'Ohm',                type: 'text',     placeholder: 'Ej: 0.3, 0.8, 1.2' },
        { id: 'optionCartType',  label: 'Tipo',               type: 'select',   options: [
            { value: 'pod',        label: 'Pod' },
            { value: 'resistencia', label: 'Resistencia' },
        ]},
        { id: 'optionPrice',     label: 'Precio ($)',         type: 'number',   step: '0.01', min: '0', required: true, grid: true },
        { id: 'optionStock',     label: 'Stock',              type: 'number',   min: '0', value: '0', required: true, grid: true },
        { id: 'optionBarcode',   label: 'Código de barras',   type: 'text',     placeholder: 'Ej: 7501234567890' },
        { id: 'optionImageUrl',  label: 'Foto (URL)',         type: 'url',      placeholder: 'https://ejemplo.com/foto.jpg' },
        { id: 'optionDesc',      label: 'Descripción',        type: 'text',     placeholder: 'Detalles del cartucho...' },
    ],
    'semi-desechable': [
        { id: 'optionName',      label: 'Nombre (Sabor)',     type: 'text',     placeholder: 'Ej: Fresa Ice', required: true },
        { id: 'optionFamilia',   label: 'Familia',            type: 'text',     placeholder: 'Ej: Edición Especial' },
        { id: 'optionPuffs',     label: 'Número de Puffs',    type: 'number',   placeholder: 'Ej: 5000', min: '0', required: true },
        { id: 'optionPrice',     label: 'Precio ($)',         type: 'number',   step: '0.01', min: '0', required: true, grid: true },
        { id: 'optionStock',     label: 'Stock',              type: 'number',   min: '0', value: '0', required: true, grid: true },
        { id: 'optionBarcode',   label: 'Código de barras',   type: 'text',     placeholder: 'Ej: 7501234567890' },
        { id: 'optionImageUrl',  label: 'Foto (URL)',         type: 'url',      placeholder: 'https://ejemplo.com/foto.jpg' },
    ],
    'accesorios': [
        { id: 'optionName',      label: 'Nombre',             type: 'text',     placeholder: 'Ej: Cable USB-C', required: true },
        { id: 'optionDesc',      label: 'Descripción',        type: 'text',     placeholder: 'Detalles del accesorio...' },
        { id: 'optionPrice',     label: 'Precio ($)',         type: 'number',   step: '0.01', min: '0', required: true, grid: true },
        { id: 'optionStock',     label: 'Stock',              type: 'number',   min: '0', value: '0', required: true, grid: true },
        { id: 'optionBarcode',   label: 'Código de barras',   type: 'text',     placeholder: 'Ej: 7501234567890' },
        { id: 'optionImageUrl',  label: 'Foto (URL)',         type: 'url',      placeholder: 'https://ejemplo.com/foto.jpg' },
    ],
    '_default': [
        { id: 'optionName',      label: 'Nombre / Sabor',     type: 'text',     placeholder: 'Ej: Fresa', required: true },
        { id: 'optionFamilia',   label: 'Familia',            type: 'text',     placeholder: 'Ej: Edición Especial' },
        { id: 'optionType',      label: 'Tipo',               type: 'select',   options: [
            { value: 'flavor', label: 'Sabor' },
            { value: 'color',  label: 'Color' },
            { value: 'size',   label: 'Tamaño' },
            { value: 'default',label: 'Estándar' },
        ]},
        { id: 'optionPrice',     label: 'Precio ($)',         type: 'number',   step: '0.01', min: '0', required: true, grid: true },
        { id: 'optionStock',     label: 'Stock',              type: 'number',   min: '0', value: '0', required: true, grid: true },
        { id: 'optionBarcode',   label: 'Código de barras',   type: 'text',     placeholder: 'Ej: 7501234567890' },
        { id: 'optionImageUrl',  label: 'Foto (URL)',         type: 'url',      placeholder: 'https://ejemplo.com/foto.jpg' },
    ],
};

function getOptionFields(categoryName) {
    const key = (categoryName || '').toLowerCase().trim();
    return OPTION_FIELDS[key] || OPTION_FIELDS['_default'];
}

function renderOptionFields(categoryName, values = {}) {
    const fields = getOptionFields(categoryName);
    const container = document.getElementById('optionFields');
    document.getElementById('optionCategoryName').value = categoryName || '';
    let html = '';
    let inGrid = false;
    for (const f of fields) {
        if (f.grid && !inGrid) { html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">'; inGrid = true; }
        if (!f.grid && inGrid) { html += '</div>'; inGrid = false; }
        html += `<div class="input-group"><label>${f.label}</label>`;
        if (f.type === 'select') {
            html += `<select id="${f.id}">`;
            for (const opt of f.options) {
                const sel = (values[f.id] || values.option_type || '') === opt.value ? ' selected' : '';
                html += `<option value="${opt.value}"${sel}>${opt.label}</option>`;
            }
            html += '</select>';
        } else {
            const val = values[f.id] !== undefined ? values[f.id] : (f.value || '');
            const attrs = [`type="${f.type}"`, `id="${f.id}"`, `value="${String(val).replace(/"/g, '&quot;')}"`];
            if (f.placeholder) attrs.push(`placeholder="${f.placeholder}"`);
            if (f.step) attrs.push(`step="${f.step}"`);
            if (f.min) attrs.push(`min="${f.min}"`);
            if (f.required) attrs.push('required');
            html += `<input ${attrs.join(' ')}>`;
        }
        html += '</div>';
    }
    if (inGrid) html += '</div>';
    container.innerHTML = html;
}

function findCategoryForModel(modelId) {
    for (const cat of catalogTree) {
        if (cat.brands) {
            for (const brand of cat.brands) {
                if (brand.models) {
                    if (brand.models.find(m => m.id === modelId)) return cat.name;
                }
            }
        }
    }
    return '';
}

function openOptionModal(modelId, editId = null) {
    document.getElementById('optionModelId').value = modelId;
    document.getElementById('optionEditId').value = editId || '';
    const categoryName = findCategoryForModel(modelId);

    if (editId) {
        let option = null;
        for (const cat of catalogTree) {
            if (cat.brands) {
                for (const brand of cat.brands) {
                    if (brand.models) {
                        for (const model of brand.models) {
                            if (model.options) option = model.options.find(o => o.id === editId);
                            if (option) break;
                        }
                    }
                    if (option) break;
                }
            }
            if (option) break;
        }
        if (option) {
            renderOptionFields(categoryName, {
                optionName: option.name || '',
                optionType: option.option_type || 'flavor',
                optionFamilia: option.familia || '',
                optionNicotine: option.nicotine_mg || '',
                optionDeviceType: option.device_type || '',
                optionCartType: option.cart_type || '',
                optionPuffs: option.puffs || '',
                optionOhm: option.ohm || '',
                optionDesc: option.description || '',
                optionPrice: option.price || 0,
                optionStock: option.stock ?? 0,
                optionBarcode: option.barcode || '',
                optionImageUrl: option.image_url || '',
            });
            document.getElementById('optionModalTitle').textContent = 'Editar Opción';
            document.getElementById('optionSubmitBtn').textContent = 'Guardar Cambios';
        }
    } else {
        renderOptionFields(categoryName);
        document.getElementById('optionModalTitle').textContent = 'Nueva Opción';
        document.getElementById('optionSubmitBtn').textContent = 'Crear Opción';
    }
    showModal('optionModal');
    const firstInput = document.querySelector('#optionFields input, #optionFields select');
    if (firstInput) firstInput.focus();
}

document.getElementById('optionForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const editId = document.getElementById('optionEditId').value;
    const body = {
        name: (document.getElementById('optionName')?.value || '').trim(),
        option_type: (document.getElementById('optionType')?.value || 'flavor'),
        familia: (document.getElementById('optionFamilia')?.value || '').trim(),
        nicotine_mg: (document.getElementById('optionNicotine')?.value || '').trim(),
        device_type: (document.getElementById('optionDeviceType')?.value || '').trim(),
        cart_type: (document.getElementById('optionCartType')?.value || '').trim(),
        puffs: (document.getElementById('optionPuffs')?.value || '').trim(),
        ohm: (document.getElementById('optionOhm')?.value || '').trim(),
        description: (document.getElementById('optionDesc')?.value || '').trim(),
        price: parseFloat(document.getElementById('optionPrice')?.value) || 0,
        stock: parseInt(document.getElementById('optionStock')?.value) || 0,
        barcode: (document.getElementById('optionBarcode')?.value || '').trim() || null,
        image_url: (document.getElementById('optionImageUrl')?.value || '').trim() || null,
    };
    if (!body.name) { toast('El nombre es requerido', 'error'); return; }
    try {
        if (editId) {
            await api(`/api/catalog/options/${editId}`, { method: 'PUT', body: JSON.stringify(body) });
            toast('Opción actualizada');
        } else {
            body.product_model_id = parseInt(document.getElementById('optionModelId').value);
            await api('/api/catalog/options', { method: 'POST', body: JSON.stringify(body) });
            toast('Opción creada');
        }
        closeModal('optionModal');
        await loadTree();
        if (selectedBrandId) await loadBrandDetail(selectedBrandId);
    } catch (e) { /* toast already shown */ }
});

async function deleteOption(id, name) {
    const ok = await confirmAction(`¿Eliminar la opción <strong>${name}</strong>?`);
    if (!ok) return;
    try {
        await api(`/api/catalog/options/${id}`, { method: 'DELETE' });
        toast('Opción eliminada');
        await loadTree();
        if (selectedBrandId) await loadBrandDetail(selectedBrandId);
    } catch (e) { /* toast already shown */ }
}
// Init
// ═══════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
    updateNav();
    loadTree();
});

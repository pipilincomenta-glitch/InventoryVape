/* Actualizar Stock — stock.js (persistent counts) */
const API = '';
const tok = () => localStorage.getItem('token') || '';
const hdr = () => ({ 'Authorization': `Bearer ${tok()}`, 'Content-Type': 'application/json' });

if (!tok()) window.location.href = '/login';

// ─── State ──
let allProducts = [];
let selectedProduct = null;
let pendingChanges = []; // [{ product_id, product_name, brand_name, model_name, old_stock, new_stock }]

// ─── Helpers ──
const $ = id => document.getElementById(id);
const esc = s => String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));

function toast(msg, type = 'success') {
    const existing = document.querySelector('.toast-msg');
    if (existing) existing.remove();
    const el = document.createElement('div');
    el.className = 'toast-msg';
    el.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:500;z-index:9999;animation:fadeIn .3s;' +
        (type === 'error' ? 'background:var(--danger,#ff3b30);color:#fff;' : 'background:var(--success,#34c759);color:#fff;');
    el.textContent = (type === 'error' ? '❌ ' : '✅ ') + msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
}

function stockBadge(stock) {
    if (stock === 0) return `<span class="stock-badge empty">Sin stock</span>`;
    if (stock <= 3) return `<span class="stock-badge low">${stock}</span>`;
    return `<span class="stock-badge ok">${stock}</span>`;
}

function fmtDate(d) {
    return new Date(d).toLocaleString('es', { day:'2-digit', month:'short', year:'numeric', hour:'2-digit', minute:'2-digit' });
}

// ─── Tab Navigation ──
function showTab(name, event) {
    $('tab-update').style.display = name === 'update' ? '' : 'none';
    $('tab-history').style.display = name === 'history' ? '' : 'none';
    document.querySelectorAll('.stock-sidebar nav a').forEach(a => a.classList.remove('active'));
    event.target.closest('a').classList.add('active');
    if (name === 'history') loadHistory();
}

// ─── Load Products ──
async function loadProducts() {
    try {
        const res = await fetch(`${API}/api/catalog/options`, { headers: hdr() });
        const data = await res.json();
        allProducts = data.options || data || [];
    } catch (e) { console.error('Load products error:', e); }
}

// ─── Search ──
function doSearch() {
    const q = ($('searchInput')?.value || '').trim().toLowerCase();
    if (!q) { $('resultsCard').style.display = 'none'; return; }

    const matches = allProducts.filter(p =>
        (p.name || '').toLowerCase().includes(q) ||
        (p.brand_name || '').toLowerCase().includes(q) ||
        (p.model_name || '').toLowerCase().includes(q) ||
        (p.barcode || '').toLowerCase().includes(q)
    );

    $('resultsCard').style.display = '';
    $('emptyState').style.display = 'none';
    $('selectedCard').style.display = 'none';

    if (!matches.length) {
        $('resultsTitle').textContent = 'Sin resultados';
        $('resultsContainer').innerHTML = `<p style="color:var(--text-secondary);padding:20px;text-align:center;">No se encontraron productos para "${esc(q)}"</p>`;
        return;
    }

    $('resultsTitle').textContent = `${matches.length} resultado(s)`;
    $('resultsContainer').innerHTML = `
        <table class="results-table">
            <thead><tr><th>Producto</th><th>Marca</th><th>Modelo</th><th>Stock</th></tr></thead>
            <tbody>${matches.map(p => `
                <tr onclick="selectProduct(${p.id})">
                    <td><strong>${esc(p.name)}</strong></td>
                    <td style="color:var(--text-secondary);font-size:13px;">${esc(p.brand_name || '—')}</td>
                    <td style="color:var(--text-secondary);font-size:13px;">${esc(p.model_name || '—')}</td>
                    <td>${stockBadge(p.stock || 0)}</td>
                </tr>`).join('')}
            </tbody>
        </table>`;
}

// ─── Select Product ──
function selectProduct(id) {
    const product = allProducts.find(p => p.id === id);
    if (!product) return;
    selectedProduct = product;

    document.querySelectorAll('.results-table tr').forEach(r => r.classList.remove('selected'));
    event?.target?.closest('tr')?.classList.add('selected');

    const currentStock = product.stock || 0;
    $('selectedCard').style.display = '';
    $('selectedCard').innerHTML = `
        <div class="selected-card">
            <div class="product-header">
                <div>
                    <div class="product-name">${esc(product.name)}</div>
                    <div class="product-meta">${esc(product.brand_name || '')} — ${esc(product.model_name || '')}</div>
                </div>
                <button class="btn-sm secondary" onclick="closeSelected()">✕ Cerrar</button>
            </div>
            <div class="stock-row">
                <div class="current-stock">
                    Stock actual: <strong>${currentStock}</strong>
                </div>
                <div class="new-stock-input">
                    <span style="font-size:14px;color:var(--text-secondary);">→</span>
                    <input type="number" id="newStockInput" min="0" value="${currentStock}" oninput="updateDiff()" onkeydown="if(event.key==='Enter')addPendingChange()">
                    <span id="diffIndicator" class="diff-indicator neutral" style="font-size:14px;">= 0</span>
                </div>
            </div>
            <div class="actions">
                <button class="btn primary" onclick="addPendingChange()">➕ Agregar al Conte</button>
                <button class="btn secondary" onclick="closeSelected()">Cancelar</button>
            </div>
        </div>`;

    setTimeout(() => { const inp = $('newStockInput'); if (inp) { inp.focus(); inp.select(); } }, 100);
}

function closeSelected() { selectedProduct = null; $('selectedCard').style.display = 'none'; }

function updateDiff() {
    if (!selectedProduct) return;
    const newVal = parseInt($('newStockInput').value) || 0;
    const oldVal = selectedProduct.stock || 0;
    const diff = newVal - oldVal;
    const indicator = $('diffIndicator');
    if (diff === 0) { indicator.textContent = '= 0'; indicator.className = 'diff-indicator neutral'; }
    else if (diff > 0) { indicator.textContent = `+${diff}`; indicator.className = 'diff-indicator positive'; }
    else { indicator.textContent = `${diff}`; indicator.className = 'diff-indicator negative'; }
}

// ─── Pending Changes ──
function addPendingChange() {
    if (!selectedProduct) return;
    const newStock = parseInt($('newStockInput')?.value);
    if (isNaN(newStock) || newStock < 0) { toast('Ingresa un número válido', 'error'); return; }
    const oldStock = selectedProduct.stock || 0;
    if (newStock === oldStock) { toast('El stock es el mismo', 'error'); return; }

    // Check if already pending — update it
    const existing = pendingChanges.find(c => c.product_id === selectedProduct.id);
    if (existing) {
        existing.new_stock = newStock;
    } else {
        pendingChanges.push({
            product_id: selectedProduct.id,
            product_name: selectedProduct.name,
            brand_name: selectedProduct.brand_name || '',
            model_name: selectedProduct.model_name || '',
            old_stock: oldStock,
            new_stock: newStock,
        });
    }

    toast(`${selectedProduct.name}: ${oldStock} → ${newStock}`);
    closeSelected();
    renderPending();
    if ($('resultsCard').style.display !== 'none') doSearch();
}

function removePending(idx) {
    pendingChanges.splice(idx, 1);
    renderPending();
}

function clearPending() {
    if (!pendingChanges.length) return;
    if (!confirm('¿Limpiar todos los cambios pendientes?')) return;
    pendingChanges = [];
    renderPending();
}

function renderPending() {
    const card = $('pendingCard');
    const container = $('pendingContainer');
    if (!pendingChanges.length) { card.style.display = 'none'; return; }

    card.style.display = '';
    container.innerHTML = `
        <table class="results-table">
            <thead><tr><th>Producto</th><th>Antes</th><th>Ahora</th><th>Cambio</th><th></th></tr></thead>
            <tbody>${pendingChanges.map((c, i) => {
                const diff = c.new_stock - c.old_stock;
                const cls = diff > 0 ? 'positive' : 'negative';
                return `<tr>
                    <td><strong>${esc(c.product_name)}</strong><br><span style="font-size:11px;color:var(--text-secondary);">${esc(c.brand_name)} — ${esc(c.model_name)}</span></td>
                    <td>${c.old_stock}</td>
                    <td>${c.new_stock}</td>
                    <td><span class="diff-indicator ${cls}">${diff > 0 ? '+' : ''}${diff}</span></td>
                    <td><button class="btn-sm danger" onclick="removePending(${i})">✕</button></td>
                </tr>`;
            }).join('')}
            </tbody>
        </table>`;

    $('pendingSummary').textContent = `${pendingChanges.length} cambio(s) pendiente(s)`;
}

// ─── Save All Changes ──
async function saveAllChanges() {
    if (!pendingChanges.length) { toast('No hay cambios para guardar', 'error'); return; }
    const countName = ($('countName')?.value || '').trim();
    if (!countName) { toast('Escribe un nombre para el conteo', 'error'); $('countName')?.focus(); return; }

    try {
        // 1. Save count to DB
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const countRes = await fetch(`${API}/api/admin/stock-counts${sidParam}`, {
            method: 'POST', headers: hdr(),
            body: JSON.stringify({ count_name: countName, items: pendingChanges }),
        });
        const countData = await countRes.json();
        if (!countRes.ok) { toast(countData.detail || 'Error al guardar', 'error'); return; }

        // 2. Apply stock updates
        let applied = 0;
        for (const c of pendingChanges) {
            try {
                await fetch(`${API}/api/admin/stock/${c.product_id}`, {
                    method: 'PUT', headers: hdr(),
                    body: JSON.stringify({ stock: c.new_stock }),
                });
                // Update local data
                const idx = allProducts.findIndex(p => p.id === c.product_id);
                if (idx >= 0) allProducts[idx].stock = c.new_stock;
                applied++;
            } catch (e) { console.error('Stock update error:', e); }
        }

        toast(`Conteo "${countName}" guardado — ${applied} producto(s) actualizado(s)`);
        pendingChanges = [];
        renderPending();
        $('countName').value = '';
        if ($('resultsCard').style.display !== 'none') doSearch();

    } catch (e) {
        console.error('Save error:', e);
        toast('Error de conexión', 'error');
    }
}

// ─── History (from DB) ──
async function loadHistory() {
    try {
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const res = await fetch(`${API}/api/admin/stock-counts${sidParam}`, { headers: hdr() });
        const data = await res.json();
        const counts = data.counts || [];
        const container = $('historyContainer');

        if (!counts.length) {
            container.innerHTML = `<div class="empty-state"><div class="icon">📋</div><p>Aún no se han guardado conteos.</p></div>`;
            return;
        }

        container.innerHTML = counts.map(c => `
            <div class="glass-card" style="margin-bottom:16px;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
                    <div>
                        <h3 style="margin:0;font-size:16px;color:var(--text-primary);text-transform:none;letter-spacing:0;">${esc(c.name)}</h3>
                        <p style="margin:4px 0 0;font-size:12px;color:var(--text-secondary);">
                            👤 ${esc(c.worker_name)} · 📅 ${fmtDate(c.created_at)} · 📦 ${c.total_changes} cambio(s)
                        </p>
                    </div>
                </div>
                <table class="results-table" style="font-size:13px;">
                    <thead><tr><th>Producto</th><th>Antes</th><th>Ahora</th><th>Cambio</th></tr></thead>
                    <tbody>${c.items.map(item => {
                        const diff = item.new_stock - item.old_stock;
                        const cls = diff > 0 ? 'positive' : 'negative';
                        return `<tr>
                            <td><strong>${esc(item.product_name)}</strong><br><span style="font-size:11px;color:var(--text-secondary);">${esc(item.brand_name)} — ${esc(item.model_name)}</span></td>
                            <td>${item.old_stock}</td>
                            <td>${item.new_stock}</td>
                            <td><span class="diff-indicator ${cls}">${diff > 0 ? '+' : ''}${diff}</span></td>
                        </tr>`;
                    }).join('')}
                    </tbody>
                </table>
            </div>
        `).join('');

    } catch (e) {
        console.error('Load history error:', e);
        $('historyContainer').innerHTML = `<div class="empty-state"><div class="icon">⚠️</div><p>Error al cargar historial.</p></div>`;
    }
}

// ─── Print ──
function printList() {
    const w = window.open('', '_blank');
    w.document.write(`<!DOCTYPE html><html><head><title>Lista de Inventario</title>
    <style>body{font-family:Arial,sans-serif;padding:20px;}table{width:100%;border-collapse:collapse;}th,td{padding:8px;border:1px solid #ddd;text-align:left;font-size:13px;}th{background:#f5f5f5;}</style>
    </head><body>
    <h2>VapeStore — Lista de Inventario</h2>
    <p>Fecha: ${new Date().toLocaleString('es')}</p>
    <table><thead><tr><th>#</th><th>Producto</th><th>Marca</th><th>Modelo</th><th>Stock</th><th style="width:120px;">Conteo Real</th></tr></thead>
    <tbody>${allProducts.map((p, i) => `<tr><td>${i+1}</td><td>${p.name}</td><td>${p.brand_name||'—'}</td><td>${p.model_name||'—'}</td><td>${p.stock||0}</td><td></td></tr>`).join('')}</tbody></table>
    </body></html>`);
    w.document.close();
    w.print();
}

// ─── F2 to refocus search ──
document.addEventListener('keydown', e => { if (e.key === 'F2') { e.preventDefault(); $('searchInput')?.focus(); } });

// ─── Init ──
document.addEventListener('DOMContentLoaded', async () => {
    await loadProducts();
    $('searchInput')?.focus();
});

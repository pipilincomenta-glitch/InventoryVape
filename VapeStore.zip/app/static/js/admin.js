/* Admin Dashboard JS */
const API = '';
const token = localStorage.getItem('token');
const headers = { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' };

// ─── Escape HTML ─────────────────────────────
const esc = s => String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));

// ─── Toast ──────────────────────────────────
function toast(msg, type = 'success') {
    const existing = document.querySelector('.toast-msg');
    if (existing) existing.remove();
    const el = document.createElement('div');
    el.className = 'toast-msg';
    el.style.cssText = 'position:fixed;bottom:24px;right:24px;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:500;z-index:9999;animation:fadeIn .3s;' +
        (type === 'error' ? 'background:var(--danger,#ff3b30);color:#fff;' : 'background:var(--success,#34c759);color:#fff;');
    el.textContent = (type === 'error' ? '❌ ' : '✅ ') + msg;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
}

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
}

function updateNav() {
    const user = JSON.parse(localStorage.getItem('user'));
    const nav = document.getElementById('userNav');
    if (nav && user) nav.innerHTML = `<span class="user-badge">${user.name} (Admin)</span>`;
}

// ─── Modal helpers ────────────────────────────
function showModal(id) { document.getElementById(id).classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

// ─── Section navigation ───────────────────────
let currentSection = null;

function showSection(name) {
    // Hide all sections
    document.querySelectorAll('.dashboard-section').forEach(s => s.classList.remove('active'));
    // Show target
    const section = document.getElementById(`section-${name}`);
    if (section) {
        section.classList.add('active');
        currentSection = name;
        // Load data for section
        if (name === 'analytics') loadAnalytics();
        if (name === 'workers') loadWorkerCards();
        if (name === 'orders') loadRecentOrders();
        if (name === 'stock') loadStockTable();
    }
}

function hideSection() {
    document.querySelectorAll('.dashboard-section').forEach(s => s.classList.remove('active'));
    currentSection = null;
}

// ─── Create Worker ────────────────────────────
document.getElementById('workerForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const res = await fetch(`${API}/api/auth/register-worker`, {
        method: 'POST', headers,
        body: JSON.stringify({
            name: document.getElementById('wName').value,
            email: document.getElementById('wEmail').value,
            password: document.getElementById('wPassword').value,
            phone: document.getElementById('wPhone').value,
            role: 'worker',
        }),
    });
    if (res.ok) {
        closeModal('workerModal');
        document.getElementById('workerForm').reset();
        loadWorkerCards();
        loadDashboard();
        alert('✅ Trabajador creado');
    } else {
        const d = await res.json();
        alert(d.detail || 'Error');
    }
});

// ─── Dashboard Stats ──────────────────────────
async function loadDashboard() {
    try {
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const res = await fetch(`${API}/api/admin/dashboard${sidParam}`, { headers });
        const data = await res.json();
        let statsHtml = '';
        if (data.today) {
            statsHtml += `
            <div class="stat-card"><div class="stat-value">${data.today.orders || 0}</div><div class="stat-label">Ventas Hoy</div></div>
            <div class="stat-card"><div class="stat-value">$${(data.today.revenue || 0).toFixed(2)}</div><div class="stat-label">Ingresos Hoy</div></div>
            <div class="stat-card"><div class="stat-value">${data.today.pending_orders || 0}</div><div class="stat-label">Pendientes</div></div>`;
        }
        if (data.products) {
            statsHtml += `
            <div class="stat-card"><div class="stat-value">${data.products.total || 0}</div><div class="stat-label">Productos</div></div>
            <div class="stat-card ${data.products.low_stock > 0 ? 'warning' : ''}"><div class="stat-value">${data.products.low_stock || 0}</div><div class="stat-label">Stock Bajo</div></div>`;
        }
        document.getElementById('stats').innerHTML = statsHtml;
    } catch (e) { console.error('Dashboard error:', e); }
}

// ─── Analytics (doughnut chart) ────────────────
async function loadAnalytics() {
    try {
        const [analyticsRes, salesRes] = await Promise.all([
            fetch(`${API}/api/admin/analytics`, { headers }),
            fetch(`${API}/api/admin/analytics/comparison`, { headers }),
        ]);
        const data = await analyticsRes.json();

        document.getElementById('analyticsCards').innerHTML = `
            <div class="stat-card"><div class="stat-value">$${data.total_revenue.toFixed(2)}</div><div class="stat-label">Ingresos Totales</div></div>
            <div class="stat-card"><div class="stat-value">${data.total_orders}</div><div class="stat-label">Órdenes Totales</div></div>
            <div class="stat-card"><div class="stat-value">${data.unique_clients}</div><div class="stat-label">Clientes Únicos</div></div>
            <div class="stat-card"><div class="stat-value">${data.conversion_rate}%</div><div class="stat-label">Tasa Conversión</div></div>
        `;

        // Doughnut chart with top products by revenue
        const salesData = salesRes.ok ? await salesRes.json() : {};
        const topProducts = salesData.top_by_rev || [];
        const canvas = document.getElementById('salesChart');
        if (!canvas) return;

        if (topProducts.length === 0) {
            canvas.style.display = 'none';
            return;
        }
        canvas.style.display = '';

        const palette = ['#6C5CE7', '#00B894', '#E17055', '#0984E3', '#FDCB6E', '#E84393', '#00CEC9', '#A29BFE'];
        const existing = Chart.getChart(canvas);
        if (existing) existing.destroy();

        new Chart(canvas, {
            type: 'doughnut',
            data: {
                labels: topProducts.map(p => p.name),
                datasets: [{
                    data: topProducts.map(p => p.revenue),
                    backgroundColor: palette.slice(0, topProducts.length),
                    borderColor: 'transparent',
                    borderWidth: 2,
                    hoverOffset: 8,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                cutout: '55%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: { color: '#ccc', padding: 12, font: { size: 11 }, usePointStyle: true, pointStyleWidth: 10 },
                    },
                    tooltip: { callbacks: { label: ctx => ' $' + ctx.parsed.toFixed(2) } },
                },
            },
        });
    } catch (e) { console.error('Analytics error:', e); }
}

// ─── Workers (cards with performance) ─────────
async function loadWorkerCards() {
    try {
        const [workersRes, perfRes] = await Promise.all([
            fetch(`${API}/api/auth/workers`, { headers }),
            fetch(`${API}/api/admin/workers?days=30`, { headers }),
        ]);
        const { workers } = await workersRes.json();
        const { workers: perf } = await perfRes.json();

        const perfMap = {};
        perf.forEach(p => { perfMap[p.id] = p; });

        document.getElementById('workersGrid').innerHTML = workers.map(w => {
            const p = perfMap[w.id] || { total_orders: 0, total_revenue: 0, active_days: 0 };
            return `
                <div class="worker-card">
                    <div style="display:flex;justify-content:space-between;align-items:center;">
                        <h3>${w.name}</h3>
                        <span class="status-badge ${w.active ? 'available' : 'out'}">${w.active ? 'Activo' : 'Inactivo'}</span>
                    </div>
                    <p style="color:var(--text-secondary);font-size:13px;margin:4px 0;">${w.email} ${w.phone ? '· ' + w.phone : ''}</p>
                    <div class="worker-stats">
                        <div class="worker-stat"><div class="val">${p.total_orders}</div><div class="lbl">Órdenes</div></div>
                        <div class="worker-stat"><div class="val">$${p.total_revenue.toFixed(0)}</div><div class="lbl">Revenue</div></div>
                        <div class="worker-stat"><div class="val">${p.active_days}</div><div class="lbl">Días Activos</div></div>
                    </div>
                    <div style="margin-top:12px;text-align:right;">
                        <button class="btn-sm danger" onclick="deactivateWorker(${w.id}, '${esc(w.name).replace(/'/g, "\\'")}')">Desactivar</button>
                    </div>
                </div>`;
        }).join('') || '<p class="empty">No hay trabajadores</p>';
    } catch (e) { console.error('Workers error:', e); }
}

async function deactivateWorker(id, name) {
    if (!confirm(`¿Desactivar a ${name}?`)) return;
    await fetch(`${API}/api/auth/workers/${id}`, { method: 'DELETE', headers });
    loadWorkerCards();
}

// ─── Recent Orders ────────────────────────────
async function loadRecentOrders() {
    try {
        const res = await fetch(`${API}/api/admin/recent-orders?limit=20`, { headers });
        const { orders } = await res.json();
        document.getElementById('ordersList').innerHTML = orders.map(o => {
            const statusColors = { pending: 'var(--warning,#ff9500)', confirmed: 'var(--accent,#0071e3)', paid: 'var(--success,#34c759)', completed: 'var(--success,#34c759)', cancelled: 'var(--danger,#ff3b30)' };
            const color = statusColors[o.status] || '#86868b';
            return `
                <div class="order-card">
                    <div class="order-header">
                        <div>
                            <strong>#${o.id}</strong>
                            <span style="color:${color};font-weight:600;font-size:13px;margin-left:8px;">${o.status.toUpperCase()}</span>
                        </div>
                        <div style="text-align:right;">
                            <div style="font-weight:700;">$${o.total.toFixed(2)}</div>
                            <div style="font-size:12px;color:var(--text-secondary);">${new Date(o.created_at).toLocaleString('es')}</div>
                        </div>
                    </div>
                    <div style="font-size:13px;color:var(--text-secondary);">
                        ${o.client_name ? 'Cliente: ' + o.client_name : ''} ${o.worker_name ? '· Trabajador: ' + o.worker_name : ''}
                    </div>
                    ${o.items.length ? `<ul class="order-items">${o.items.map(i => `<li>${i.product_name} × ${i.quantity} — $${(i.unit_price * i.quantity).toFixed(2)}</li>`).join('')}</ul>` : ''}
                </div>`;
        }).join('') || '<p class="empty">No hay órdenes recientes</p>';
    } catch (e) { console.error('Orders error:', e); }
}

// ─── Stock Update ─────────────────────────────
// ─── Inventory Count ──────────────────────────
let allProducts = [];
let countItems = {}; // { productId: { product, counted } }

async function loadStockTable() {
    try {
        const res = await fetch(`${API}/api/products`, { headers });
        const { products } = await res.json();
        allProducts = products;
    } catch (e) { console.error('Stock load error:', e); }
}

function findProductForCount() {
    const query = document.getElementById('scanInput').value.trim();
    const qty = parseInt(document.getElementById('scanQty').value) || 1;
    if (!query) return;

    // Search by barcode first, then by name
    let product = allProducts.find(p => p.barcode && p.barcode === query);
    if (!product) {
        product = allProducts.find(p => p.name.toLowerCase().includes(query.toLowerCase()));
    }
    if (!product) {
        toast('Producto no encontrado', 'error');
        return;
    }

    // Add or update count
    if (countItems[product.id]) {
        countItems[product.id].counted += qty;
    } else {
        countItems[product.id] = { product, counted: qty };
    }

    // Clear scan input, keep focus
    document.getElementById('scanInput').value = '';
    document.getElementById('scanQty').value = '1';
    document.getElementById('scanInput').focus();
    renderCountTable();
}

function updateCountQty(productId, newQty) {
    if (countItems[productId]) {
        countItems[productId].counted = parseInt(newQty) || 0;
        renderCountTable();
    }
}

function removeCountItem(productId) {
    delete countItems[productId];
    renderCountTable();
}

function renderCountTable() {
    const items = Object.values(countItems);
    const container = document.getElementById('countedItems');

    // Update stats
    document.getElementById('countTotal').textContent = items.length;
    const diffs = items.filter(i => i.counted !== i.product.stock).length;
    document.getElementById('countDiffs').textContent = diffs;

    if (!items.length) {
        container.innerHTML = '<p class="empty">Escanea o busca productos para iniciar el conteo</p>';
        return;
    }

    container.innerHTML = `
        <table class="count-table">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cód. Barras</th>
                    <th>Stock Sistema</th>
                    <th>Contado</th>
                    <th>Diferencia</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>${items.map(i => {
                const diff = i.counted - i.product.stock;
                const diffClass = diff === 0 ? 'match' : diff > 0 ? 'over' : 'under';
                const diffText = diff === 0 ? '✓ OK' : (diff > 0 ? `+${diff}` : `${diff}`);
                return `
                    <tr>
                        <td><strong>${i.product.name}</strong></td>
                        <td style="color:var(--text-secondary);font-size:13px;">${i.product.barcode || '—'}</td>
                        <td>${i.product.stock}</td>
                        <td><input type="number" class="counted-input" min="0" value="${i.counted}" onchange="updateCountQty(${i.product.id}, this.value)"></td>
                        <td><span class="diff-badge ${diffClass}">${diffText}</span></td>
                        <td><button class="btn-sm danger" onclick="removeCountItem(${i.product.id})">✕</button></td>
                    </tr>`;
            }).join('')}
            </tbody>
        </table>
        <div class="count-footer">
            <div>
                <strong>${items.length}</strong> items · <strong>${diffs}</strong> con diferencia
            </div>
            <button class="btn primary" onclick="applyStockCount()">✅ Aplicar Cambios</button>
        </div>`;
}

async function applyStockCount() {
    const items = Object.values(countItems);
    const changes = items.filter(i => i.counted !== i.product.stock);
    if (!changes.length) { alert('No hay cambios para aplicar'); return; }

    if (!confirm(`¿Aplicar ${changes.length} cambio(s) de stock?`)) return;

    let applied = 0;
    for (const i of changes) {
        try {
            await fetch(`${API}/api/admin/stock/${i.product.id}`, {
                method: 'PUT', headers,
                body: JSON.stringify({ stock: i.counted }),
            });
            applied++;
        } catch (e) { console.error('Stock apply error:', e); }
    }

    alert(`✅ ${applied} producto(s) actualizado(s)`);
    countItems = {};
    renderCountTable();
    loadStockTable();
    loadDashboard();
}

// Allow scan mode with barcode scanner (auto-focus back to scan input)
document.addEventListener('keydown', (e) => {
    if (currentSection === 'stock' && e.key === 'F2') {
        e.preventDefault();
        document.getElementById('scanInput').focus();
    }
});

// ─── Init ─────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    updateNav();
    loadDashboard();
});

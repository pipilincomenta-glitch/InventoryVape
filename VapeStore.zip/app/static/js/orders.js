/* Purchase Orders — VapeStore (simplified flow) */
const API = '';
const tok = () => localStorage.getItem('token') || '';
const hdr = () => ({ 'Authorization': `Bearer ${tok()}`, 'Content-Type': 'application/json' });

// ── State ──
let allPOs = [];
let currentPO = null;
let currentFilter = 'all';
let allProducts = [];
let newItems = []; // items for new PO form

// ── Helpers ──
const $ = id => document.getElementById(id);
const fmt = n => '$' + (parseFloat(n) || 0).toFixed(2);
const esc = s => String(s || '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function badge(status) {
    const c = { pending: '#e67e22', ordered: '#3498db', received: '#9b59b6', completed: '#27ae60', cancelled: '#e74c3c' };
    return `<span class="po-badge" style="background:${c[status] || '#95a5a6'};color:#fff">${esc(status)}</span>`;
}

function toast(msg, type = 'success') {
    const el = document.createElement('div');
    el.style.cssText = `position:fixed;top:20px;right:20px;z-index:9999;padding:12px 20px;border-radius:10px;font-size:14px;font-weight:500;color:#fff;transition:opacity .3s;` +
        (type === 'error' ? 'background:var(--danger,#ff3b30)' : 'background:var(--success,#34c759)');
    el.textContent = (type === 'error' ? '❌ ' : '✅ ') + msg;
    document.body.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 400); }, 3000);
}

// ── Views ──
const ORDERS_VIEW_KEY = 'vapestore_orders_view';

function showView(name) {
    ['list', 'new', 'detail', 'archive'].forEach(v => {
        const el = $('view-' + v);
        if (el) el.style.display = v === name ? '' : 'none';
    });
    document.querySelectorAll('.po-sidebar nav a').forEach(a => a.classList.remove('active'));
    const map = { list: 'nav-list', new: 'nav-new', archive: 'nav-archive' };
    if (map[name]) $(map[name])?.classList.add('active');
    if (name !== 'detail') localStorage.setItem(ORDERS_VIEW_KEY, name);
    if (name === 'list') loadList();
    if (name === 'archive') loadArchive();
    if (name === 'new') initNewForm();
}

// ── Load Products ──
async function loadProducts() {
    try {
        const res = await fetch(`${API}/api/catalog/options`, { headers: hdr() });
        const data = await res.json();
        allProducts = data.options || data || [];
    } catch (e) { console.error(e); }
}

function populateProductSelect(selectId) {
    const sel = $(selectId);
    if (!sel) return;
    sel.innerHTML = '<option value="">Buscar producto...</option>' +
        allProducts.map(p => `<option value="${p.id}" data-cost="${p.price || 0}">${esc(p.brand_name)} — ${esc(p.model_name)} — ${esc(p.name)} ($${p.price || 0}) [stock: ${p.stock || 0}]</option>`).join('');
}

// ── PO List ──
async function loadList() {
    try {
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const res = await fetch(`${API}/api/admin/purchase-orders${sidParam}`, { headers: hdr() });
        const data = await res.json();
        allPOs = data.orders || data || [];
        renderList();
    } catch (e) { console.error(e); toast('Error al cargar órdenes', 'error'); }
}

function renderList() {
    let filtered = allPOs.filter(po => !['completed', 'cancelled'].includes(po.status));
    if (currentFilter !== 'all') filtered = allPOs.filter(po => po.status === currentFilter);
    const q = ($('poSearch')?.value || '').toLowerCase();
    if (q) filtered = filtered.filter(po => (po.vendor_name || '').toLowerCase().includes(q) || (po.reference || '').toLowerCase().includes(q));

    $('poListBody').innerHTML = filtered.map(po => `
        <tr onclick="openDetail(${po.id})" style="cursor:pointer">
            <td><strong>#${po.id}</strong></td>
            <td>${esc(po.vendor_name)}</td>
            <td><span style="font-size:12px;color:var(--text-secondary);">${esc(po.store_name || '—')}</span></td>
            <td>${esc(po.reference || '—')}</td>
            <td>${badge(po.status)}</td>
            <td>${po.created_at ? new Date(po.created_at).toLocaleDateString('es') : '—'}</td>
            <td>${fmt(po.total || 0)}</td>
            <td onclick="event.stopPropagation()"><button class="btn-sm danger" onclick="deletePO(${po.id})">✕</button></td>
        </tr>`).join('') || '';
    $('poListEmpty').style.display = filtered.length ? 'none' : '';
}

function filterList() { renderList(); }
function setFilter(f, btn) {
    currentFilter = f;
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    btn?.classList.add('active');
    renderList();
}

// ── New PO ──
function initNewForm() {
    newItems = [];
    populateProductSelect('newProductSelect');
    $('newVendor').value = '';
    $('newRef').value = '';
    $('newNotes').value = '';
    $('newShipping').value = '0';
    $('newDiscount').value = '0';
    renderNewItems();
}

function addNewItem() {
    const sel = $('newProductSelect');
    const pid = parseInt(sel.value);
    if (!pid) { toast('Selecciona un producto', 'error'); return; }
    const qty = parseInt($('newProdQty').value) || 1;
    const cost = parseFloat($('newProdCost').value) || 0;
    const product = allProducts.find(p => p.id === pid);
    if (!product) return;

    // Check if already added
    const existing = newItems.find(i => i.product_id === pid);
    if (existing) {
        existing.quantity += qty;
    } else {
        newItems.push({ product_id: pid, product_name: `${product.brand_name} — ${product.model_name} — ${product.name}`, quantity: qty, unit_cost: cost, retail_price: product.price || 0 });
    }
    sel.value = '';
    $('newProdQty').value = '1';
    $('newProdCost').value = '0';
    renderNewItems();
}

function removeNewItem(idx) {
    newItems.splice(idx, 1);
    renderNewItems();
}

function updateNewItemQty(idx, val) { newItems[idx].quantity = parseInt(val) || 0; renderNewItems(); }
function updateNewItemCost(idx, val) { newItems[idx].unit_cost = parseFloat(val) || 0; renderNewItems(); }

function renderNewItems() {
    const tbody = $('newItemsBody');
    const table = $('newItemsTable');
    if (!newItems.length) { table.style.display = 'none'; calcNewTotal(); return; }
    table.style.display = '';
    tbody.innerHTML = newItems.map((item, i) => `
        <tr>
            <td>${i + 1}</td>
            <td><strong>${esc(item.product_name)}</strong></td>
            <td><input type="number" class="num-input" min="1" value="${item.quantity}" onchange="updateNewItemQty(${i}, this.value)"></td>
            <td><input type="number" class="num-input" min="0" step="0.01" value="${item.unit_cost}" onchange="updateNewItemCost(${i}, this.value)"></td>
            <td>${fmt(item.quantity * item.unit_cost)}</td>
            <td><button class="btn-sm danger" onclick="removeNewItem(${i})">✕</button></td>
        </tr>`).join('');
    calcNewTotal();
}

function calcNewTotal() {
    const sub = newItems.reduce((s, i) => s + (i.quantity * i.unit_cost), 0);
    const ship = parseFloat($('newShipping')?.value) || 0;
    const disc = parseFloat($('newDiscount')?.value) || 0;
    $('newSubtotal').value = fmt(sub);
    $('newTotal').textContent = fmt(sub + ship - disc);
}

async function saveNewPO() {
    const vendor = $('newVendor').value.trim();
    if (!vendor) { toast('Ingresa el proveedor', 'error'); return; }
    if (!newItems.length) { toast('Agrega al menos un producto', 'error'); return; }

    try {
        // Create PO
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const res = await fetch(`${API}/api/admin/purchase-orders${sidParam}`, {
            method: 'POST', headers: hdr(),
            body: JSON.stringify({
                vendor_name: vendor,
                reference: $('newRef').value.trim(),
                notes: $('newNotes').value.trim(),
                shipping_cost: parseFloat($('newShipping').value) || 0,
                discount: parseFloat($('newDiscount').value) || 0,
            }),
        });
        const data = await res.json();
        const poId = data.id;

        // Add items
        for (const item of newItems) {
            await fetch(`${API}/api/admin/purchase-orders/${poId}/items`, {
                method: 'POST', headers: hdr(),
                body: JSON.stringify(item),
            });
        }

        toast('Orden creada');
        openDetail(poId);
    } catch (e) {
        console.error(e);
        toast('Error al crear orden', 'error');
    }
}

// ── PO Detail ──
async function openDetail(id) {
    try {
        const res = await fetch(`${API}/api/admin/purchase-orders/${id}`, { headers: hdr() });
        currentPO = await res.json();
        renderDetail();
        showView('detail');
    } catch (e) { console.error(e); toast('Error al cargar orden', 'error'); }
}

function renderDetail() {
    const po = currentPO;
    if (!po) return;
    $('detTitle').textContent = `PO #${po.id}`;
    $('detSubtitle').textContent = `${po.vendor_name} — ${po.store_name ? '🏪 ' + po.store_name + ' — ' : ''}${fmt(po.total || 0)}`;
    $('detVendor').value = po.vendor_name || '';
    $('detRef').value = po.reference || '';
    $('detStatus').value = po.status || 'pending';
    $('detNotes').value = po.notes || '';
    $('detDate').textContent = po.created_at ? new Date(po.created_at).toLocaleString('es') : '—';

    // Summary
    const items = po.items || [];
    const totalQty = items.reduce((s, i) => s + (i.quantity || 0), 0);
    const recvQty = items.reduce((s, i) => s + (i.received_qty || 0), 0);
    $('detItemCount').textContent = items.length;
    $('detTotalQty').textContent = totalQty;
    $('detReceivedQty').textContent = recvQty;
    $('detSubtotal').textContent = fmt(po.subtotal || 0);
    $('detShipping').textContent = fmt(po.shipping_cost || 0);
    $('detDiscount').textContent = fmt(po.discount || 0);
    $('detTotal').textContent = fmt(po.total || 0);

    // Disable receive if already completed
    $('btnReceive').disabled = po.status === 'completed';
    $('btnReceive').style.opacity = po.status === 'completed' ? '0.5' : '1';

    // Items table
    populateProductSelect('detAddProduct');
    renderDetailItems();
}

function renderDetailItems() {
    const items = currentPO?.items || [];
    $('detItemsBody').innerHTML = items.map((item, i) => `
        <tr>
            <td>${i + 1}</td>
            <td><strong>${esc(item.product_name)}</strong></td>
            <td><input type="number" class="num-input" min="1" value="${item.quantity}" onchange="updateItemField(${item.id}, 'quantity', this.value)"></td>
            <td><input type="number" class="num-input" min="0" step="0.01" value="${item.unit_cost}" onchange="updateItemField(${item.id}, 'unit_cost', this.value)"></td>
            <td><input type="number" class="num-input" min="0" value="${item.received_qty || 0}" onchange="updateItemField(${item.id}, 'received_qty', this.value)" style="border:2px solid ${(item.received_qty || 0) > 0 ? 'var(--success,#34c759)' : 'var(--glass-border, rgba(0,0,0,0.15))'}"></td>
            <td>${fmt((item.received_qty || 0) * (item.unit_cost || 0))}</td>
            <td><button class="btn-sm danger" onclick="deleteItem(${item.id})">✕</button></td>
        </tr>`).join('') || '<tr><td colspan="7" style="text-align:center;color:var(--text-secondary);padding:20px;">Sin productos. Agrega uno abajo.</td></tr>';
}
// ═══════════════════════════════════════════════
// Product Search (search → results table)
// ═══════════════════════════════════════════════
function doSearch(mode) {
  const input = $(mode === 'new' ? 'newSearch' : 'detSearch');
  const resultsDiv = $(mode === 'new' ? 'newResults' : 'detResults');
  const q = (input?.value || '').trim().toLowerCase();
  if (!q) { resultsDiv.innerHTML = ''; return; }

  const matches = allProducts.filter(p =>
    (p.name || '').toLowerCase().includes(q) ||
    (p.brand_name || '').toLowerCase().includes(q) ||
    (p.model_name || '').toLowerCase().includes(q) ||
    (p.barcode || '').toLowerCase().includes(q)
  );

  if (!matches.length) {
    resultsDiv.innerHTML = '<p style="color:var(--text-secondary);padding:16px;text-align:center;">No se encontraron productos para "' + esc(q) + '"</p>';
    return;
  }

  resultsDiv.innerHTML = `
    <p style="font-size:13px;color:var(--text-secondary);margin-bottom:8px;">${matches.length} resultado(s) — haz clic en "+ Agregar" para añadir a la orden</p>
    <table class="po-table">
      <thead><tr><th>Producto</th><th>Marca</th><th>Modelo</th><th>Precio</th><th>Stock</th><th></th></tr></thead>
      <tbody>${matches.map(p => `
        <tr>
          <td><strong>${esc(p.name)}</strong></td>
          <td>${esc(p.brand_name || '—')}</td>
          <td>${esc(p.model_name || '—')}</td>
          <td>${fmt(p.price || 0)}</td>
          <td>${p.stock || 0}</td>
          <td><button class="btn-sm primary" onclick="addFromSearch(${p.id}, '${mode}')">+ Agregar</button></td>
        </tr>`).join('')}
      </tbody>
    </table>`;
}

function addFromSearch(id, mode) {
  const product = allProducts.find(p => p.id === id);
  if (!product) return;
  const name = `${product.brand_name} — ${product.model_name} — ${product.name}`;

  if (mode === 'new') {
    const existing = newItems.find(i => i.product_id === id);
    if (existing) { existing.quantity += 1; }
    else { newItems.push({ product_id: id, product_name: name, quantity: 1, unit_cost: product.price || 0, retail_price: product.price || 0 }); }
    renderNewItems();
  } else if (mode === 'detail' && currentPO) {
    fetch(`${API}/api/admin/purchase-orders/${currentPO.id}/items`, {
      method: 'POST', headers: hdr(),
      body: JSON.stringify({ product_id: id, product_name: name, quantity: 1, unit_cost: product.price || 0, retail_price: product.price || 0 }),
    }).then(() => {
      fetch(`${API}/api/admin/purchase-orders/${currentPO.id}`, { headers: hdr() })
        .then(r => r.json())
        .then(data => { currentPO = data; renderDetail(); })
        .catch(e => toast('Error al cargar detalle', 'error'));
    }).catch(e => toast('Error al agregar item', 'error'));
  }
  toast(`${product.name} agregado`);
}
async function updateItemField(itemId, field, value) {
    const body = {};
    body[field] = field === 'quantity' || field === 'received_qty' ? parseInt(value) || 0 : parseFloat(value) || 0;
    try {
        await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}/items/${itemId}`, {
            method: 'PUT', headers: hdr(), body: JSON.stringify(body),
        });
        // Reload detail
        const res = await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}`, { headers: hdr() });
        currentPO = await res.json();
        renderDetail();
    } catch (e) { console.error(e); }
}

async function addDetailItem() {
    const sel = $('detAddProduct');
    const pid = parseInt(sel.value);
    if (!pid) { toast('Selecciona un producto', 'error'); return; }
    const qty = parseInt($('detAddQty').value) || 1;
    const cost = parseFloat($('detAddCost').value) || 0;
    const product = allProducts.find(p => p.id === pid);
    if (!product) return;

    try {
        await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}/items`, {
            method: 'POST', headers: hdr(),
            body: JSON.stringify({ product_id: pid, product_name: `${product.brand_name} — ${product.model_name} — ${product.name}`, quantity: qty, unit_cost: cost, retail_price: product.price || 0 }),
        });
        sel.value = '';
        $('detAddQty').value = '1';
        $('detAddCost').value = '0';
        // Reload
        const res = await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}`, { headers: hdr() });
        currentPO = await res.json();
        renderDetail();
        toast('Producto agregado');
    } catch (e) { console.error(e); toast('Error al agregar', 'error'); }
}

async function deleteItem(itemId) {
    if (!confirm('¿Eliminar este producto?')) return;
    try {
        await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}/items/${itemId}`, { method: 'DELETE', headers: hdr() });
        const res = await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}`, { headers: hdr() });
        currentPO = await res.json();
        renderDetail();
    } catch (e) { console.error(e); }
}

// ── Actions ──
async function updateStatus() {
    const status = $('detStatus').value;
    try {
        await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}`, {
            method: 'PUT', headers: hdr(), body: JSON.stringify({ status }),
        });
        currentPO.status = status;
        renderDetail();
        toast('Estado actualizado');
    } catch (e) { console.error(e); }
}

async function receiveStock() {
    if (!currentPO) return;
    const items = currentPO.items || [];
    const toReceive = items.filter(i => (i.received_qty || 0) > 0);
    if (!toReceive.length) { toast('No hay cantidades recibidas para procesar', 'error'); return; }

    const summary = toReceive.map(i => `• ${i.product_name}: +${i.received_qty}`).join('\n');
    if (!confirm(`¿Recibir stock?\n\nEsto sumará las cantidades recibidas al inventario:\n\n${summary}\n\n¿Continuar?`)) return;

    try {
        const res = await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}/checkin`, { method: 'POST', headers: hdr() });
        const data = await res.json();
        toast(`${data.updated} producto(s) actualizado(s) en inventario`);
        // Reload
        const reload = await fetch(`${API}/api/admin/purchase-orders/${currentPO.id}`, { headers: hdr() });
        currentPO = await reload.json();
        renderDetail();
    } catch (e) { console.error(e); toast('Error al recibir stock', 'error'); }
}

async function deletePO(id) {
    if (!confirm('¿Eliminar esta orden?')) return;
    try {
        await fetch(`${API}/api/admin/purchase-orders/${id}`, { method: 'DELETE', headers: hdr() });
        toast('Orden eliminada');
        loadList();
    } catch (e) { console.error(e); }
}

async function deleteCurrentPO() {
    if (!currentPO) return;
    await deletePO(currentPO.id);
    showView('list');
}

// ── Archive ──
async function loadArchive() {
    try {
        const sid = getStoreId();
        const sidParam = sid ? `?store_id=${sid}` : '';
        const res = await fetch(`${API}/api/admin/purchase-orders${sidParam}`, { headers: hdr() });
        const data = await res.json();
        const archived = (data.orders || data || []).filter(po => ['completed', 'cancelled'].includes(po.status));
        $('archiveBody').innerHTML = archived.map(po => `
            <tr onclick="openDetail(${po.id})" style="cursor:pointer">
                <td><strong>#${po.id}</strong></td>
                <td>${esc(po.vendor_name)}</td>
                <td><span style="font-size:12px;color:var(--text-secondary);">${esc(po.store_name || '—')}</span></td>
                <td>${badge(po.status)}</td>
                <td>${po.created_at ? new Date(po.created_at).toLocaleDateString('es') : '—'}</td>
                <td>${fmt(po.total || 0)}</td>
            </tr>`).join('') || '';
        $('archiveEmpty').style.display = archived.length ? 'none' : '';
    } catch (e) { console.error(e); }
}

// ── Init ──
document.addEventListener('DOMContentLoaded', async () => {
    await loadProducts();
    await initOrdersStoreFilter();
    const savedView = localStorage.getItem(ORDERS_VIEW_KEY) || 'list';
    showView(savedView);
});

// ── Orders-specific store filter ──
async function initOrdersStoreFilter() {
    const sel = document.getElementById('ordersStoreSelector');
    if (!sel) return;
    // Managers are locked to their store — hide filter
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    if (user && user.role === 'manager') {
        const container = document.getElementById('ordersStoreFilter');
        if (container) container.style.display = 'none';
        return;
    }
    try {
        const token = localStorage.getItem('token');
        const res = await fetch('/api/admin/stores', { headers: { Authorization: 'Bearer ' + token } });
        if (!res.ok) return;
        const data = await res.json();
        const stores = data.stores || [];
        sel.innerHTML = '<option value="all">Todas las tiendas</option>' +
            stores.map(s => '<option value="' + s.id + '">' + esc(s.name) + '</option>').join('');
        const saved = localStorage.getItem('vapestore_selected_store') || 'all';
        sel.value = saved;
        sel.addEventListener('change', () => {
            const v = sel.value;
            if (v === 'all' || !v) {
                localStorage.removeItem('vapestore_selected_store');
            } else {
                localStorage.setItem('vapestore_selected_store', v);
            }
            // Also sync the global store-selector dropdown if it exists
            const globalSel = document.getElementById('storeSelector');
            if (globalSel) globalSel.value = v;
            // Reload current view
            const currentView = localStorage.getItem(ORDERS_VIEW_KEY) || 'list';
            showView(currentView);
        });
    } catch (e) { console.warn('Orders store filter init failed:', e); }
}

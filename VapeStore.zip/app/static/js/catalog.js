/* Catalog JavaScript - Public product browsing */
const API = '';
let selectedCategory = null;

// ─── Escape HTML ─────────────────────────────
const esc = s => String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));

function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = '/login';
}

function updateNav() {
    const user = JSON.parse(localStorage.getItem('user'));
    const nav = document.getElementById('userNav');
    if (!nav) return;
    if (user) {
        nav.innerHTML = `
            <span class="user-badge">${user.name}</span>
            <button class="btn-sm" onclick="logout()">Salir</button>
        `;
    } else {
        nav.innerHTML = `<a href="/login" class="btn-sm primary">Iniciar Sesión</a>`;
    }
}

async function loadCategories() {
    const res = await fetch(`${API}/api/products/categories`);
    const { categories } = await res.json();
    const container = document.getElementById('categories');
    container.innerHTML = categories.map(c =>
        `<button class="cat-btn ${selectedCategory === c.id ? 'active' : ''}"
                 onclick="filterCategory(${c.id})">${c.icon || '📦'} ${esc(c.name)}</button>`
    ).join('') + `<button class="cat-btn ${!selectedCategory ? 'active' : ''}" onclick="filterCategory(null)">Todos</button>`;
}

async function loadProducts(categoryId = null) {
    let url = `${API}/api/products/catalog`;
    if (categoryId) url += `?category_id=${categoryId}`;
    const search = document.getElementById('search')?.value;
    if (search) url += `${categoryId ? '&' : '?'}search=${encodeURIComponent(search)}`;

    const res = await fetch(url);
    const { products } = await res.json();
    const container = document.getElementById('products');
    container.innerHTML = products.length === 0
        ? '<p class="empty">No se encontraron productos</p>'
        : products.map(p => `
            <div class="product-card ${p.out_of_service ? 'unavailable' : ''}">
                <div class="product-icon">${p.category_icon || '📦'}</div>
                <h3>${esc(p.name)}</h3>
                <p>${esc(p.description || '')}</p>
                <div class="product-meta">
                    ${p.has_offer ? `<span class="offer-badge">🔥 ${esc(p.offer_name)}</span>` : ''}
                    ${p.out_of_service ? '<span class="status-badge unavailable">Fuera de servicio</span>' : ''}
                    ${p.stock > 0 ? '<span class="status-badge available">Disponible</span>' : '<span class="status-badge out">Agotado</span>'}
                </div>
            </div>
        `).join('');
}

function filterCategory(id) {
    selectedCategory = id;
    loadCategories();
    loadProducts(id);
}

document.addEventListener('DOMContentLoaded', () => {
    updateNav();
    loadCategories();
    loadProducts();
    document.getElementById('search')?.addEventListener('input', () => loadProducts(selectedCategory));
});

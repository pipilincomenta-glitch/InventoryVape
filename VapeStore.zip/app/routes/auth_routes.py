"""Authentication routes - register, login, profile."""
from fastapi import APIRouter, Depends, HTTPException, Query
import sqlite3
from app.database import get_db, row_to_dict
from app.schemas import UserCreate, UserLogin, TokenResponse
from app.auth import hash_password, verify_password, create_access_token, get_current_user, require_role

router = APIRouter(prefix="/api/auth", tags=["auth"])


@router.post("/register", response_model=TokenResponse)
def register(user: UserCreate, db: sqlite3.Connection = Depends(get_db)):
    """Register a new client account."""
    # Only clients can self-register
    if user.role != "client":
        raise HTTPException(status_code=403, detail="Only clients can self-register")

    existing = db.execute(
        "SELECT id FROM users WHERE email = ?", (user.email,)
    ).fetchone()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    cursor = db.execute(
        "INSERT INTO users (name, email, password_hash, role, phone) VALUES (?, ?, ?, ?, ?)",
        (user.name, user.email, hash_password(user.password), user.role, user.phone),
    )
    db.commit()
    user_id = cursor.lastrowid
    token = create_access_token(user_id, user.role, user.name)

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {"id": user_id, "name": user.name, "email": user.email, "role": user.role},
    }


@router.post("/register-worker", status_code=201)
def register_worker(
    user: UserCreate,
    admin: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Admin creates a worker account."""
    existing = db.execute(
        "SELECT id FROM users WHERE email = ?", (user.email,)
    ).fetchone()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    cursor = db.execute(
        "INSERT INTO users (name, email, password_hash, role, phone) VALUES (?, ?, ?, ?, ?)",
        (user.name, user.email, hash_password(user.password), user.role or 'worker', user.phone),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Worker account created"}


@router.get("/workers")
def get_workers(
    admin: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all worker and manager accounts (admin only)."""
    rows = db.execute(
        "SELECT id, name, email, phone, role, active, created_at FROM users WHERE role IN ('worker', 'manager') ORDER BY name"
    ).fetchall()
    return {"workers": [dict(r) for r in rows]}


@router.delete("/workers/{worker_id}")
def deactivate_worker(
    worker_id: int,
    admin: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Deactivate a worker account (admin only)."""
    db.execute("UPDATE users SET active = 0 WHERE id = ? AND role = 'worker'", (worker_id,))
    db.commit()
    return {"message": "Worker deactivated"}


@router.put("/workers/{worker_id}")
def update_worker(
    worker_id: int,
    user: UserCreate,
    admin: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update worker/manager info (admin only)."""
    existing = db.execute(
        "SELECT id FROM users WHERE id = ? AND role IN ('worker', 'manager')",
        (worker_id,),
    ).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Worker not found")
    updates = []
    params = []
    if user.name:
        updates.append("name = ?")
        params.append(user.name)
    if user.email:
        # Check email uniqueness
        dup = db.execute("SELECT id FROM users WHERE email = ? AND id != ?", (user.email, worker_id)).fetchone()
        if dup:
            raise HTTPException(status_code=400, detail="Email already in use")
        updates.append("email = ?")
        params.append(user.email)
    if user.phone is not None:
        updates.append("phone = ?")
        params.append(user.phone)
    if user.password and len(user.password) >= 6:
        updates.append("password_hash = ?")
        params.append(hash_password(user.password))
    if user.role and user.role in ('worker', 'manager'):
        updates.append("role = ?")
        params.append(user.role)
    if updates:
        params.append(worker_id)
        db.execute(f"UPDATE users SET {', '.join(updates)} WHERE id = ?", params)
        db.commit()
    return {"message": "Worker updated"}


@router.put("/workers/{worker_id}/reactivate")
def reactivate_worker(
    worker_id: int,
    admin: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Reactivate a worker account (admin only)."""
    db.execute("UPDATE users SET active = 1 WHERE id = ? AND role = 'worker'", (worker_id,))
    db.commit()
    return {"message": "Worker reactivated"}


@router.post("/workers/{worker_id}/reset-password")
def reset_worker_password(
    worker_id: int,
    body: dict,
    admin: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Reset worker password (admin only)."""
    existing = db.execute("SELECT id FROM users WHERE id = ? AND role = 'worker'", (worker_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Worker not found")
    new_pass = body.get("password", "")
    if not new_pass or len(new_pass) < 4:
        raise HTTPException(status_code=400, detail="Password must be at least 4 characters")
    db.execute("UPDATE users SET password_hash = ? WHERE id = ?", (hash_password(new_pass), worker_id))
    db.commit()
    return {"message": "Password reset"}


@router.post("/login", response_model=TokenResponse)
def login(credentials: UserLogin, db: sqlite3.Connection = Depends(get_db)):
    """Login with email and password."""
    user = db.execute(
        "SELECT * FROM users WHERE email = ? AND active = 1",
        (credentials.email,),
    ).fetchone()

    if not user or not verify_password(credentials.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # For managers, look up their assigned store
    store_id = None
    store_name = None
    if user["role"] == "manager":
        ws = db.execute(
            """SELECT ws.store_id, s.name as store_name
               FROM worker_stores ws
               JOIN stores s ON ws.store_id = s.id
               WHERE ws.worker_id = ? AND ws.active = 1
               LIMIT 1""",
            (user["id"],),
        ).fetchone()
        if ws:
            store_id = ws["store_id"]
            store_name = ws["store_name"]

    # Generate JWT with store_id for managers
    if user["role"] == "manager" and store_id:
        from app.auth import create_token
        token = create_token({
            "user_id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "store_id": store_id,
            "store_name": store_name,
        })
    else:
        token = create_access_token(user["id"], user["role"], user["name"])

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": user["id"],
            "name": user["name"],
            "email": user["email"],
            "role": user["role"],
            "store_id": store_id,
            "store_name": store_name,
        },
    }


@router.get("/me")
def get_profile(user: dict = Depends(get_current_user), db: sqlite3.Connection = Depends(get_db)):
    """Get current user profile."""
    profile = db.execute(
        "SELECT id, name, email, role, phone, created_at FROM users WHERE id = ?",
        (user["user_id"],),
    ).fetchone()
    if not profile:
        raise HTTPException(status_code=404, detail="User not found")
    return dict(profile)


# ═══════════════════════════════════════════════
# PIN-BASED LOGIN (Workers)
# ═══════════════════════════════════════════════

# In-memory rate limiter for PIN attempts
_pin_attempts = {}  # {pin_key: {"count": N, "locked_until": datetime}}

@router.post("/pin-login")
def pin_login(
    pin: str = Query(..., min_length=4, max_length=6),
    db: sqlite3.Connection = Depends(get_db),
):
    """Worker PIN login — returns token + store info."""
    from datetime import datetime, timedelta

    # Check rate limiting
    now = datetime.now()
    lock_key = pin
    if lock_key in _pin_attempts:
        attempt = _pin_attempts[lock_key]
        if attempt.get("locked_until") and now < attempt["locked_until"]:
            remaining = (attempt["locked_until"] - now).seconds
            raise HTTPException(status_code=429, detail=f"Demasiados intentos. Espera {remaining}s")
        if now > attempt.get("locked_until", now):
            _pin_attempts[lock_key] = {"count": 0}

    # Look up PIN in worker_stores
    ws = db.execute(
        """SELECT ws.*, u.id as uid, u.name, u.email, u.role, u.active,
                  s.name as store_name
           FROM worker_stores ws
           JOIN users u ON ws.worker_id = u.id
           JOIN stores s ON ws.store_id = s.id
           WHERE ws.pin = ? AND ws.active = 1 AND u.active = 1""",
        (pin,),
    ).fetchone()

    if not ws:
        # Track failed attempt
        if lock_key not in _pin_attempts:
            _pin_attempts[lock_key] = {"count": 0}
        _pin_attempts[lock_key]["count"] += 1
        if _pin_attempts[lock_key]["count"] >= 5:
            _pin_attempts[lock_key]["locked_until"] = now + timedelta(minutes=5)
            raise HTTPException(status_code=429, detail="PIN bloqueado 5 minutos por intentos fallidos")
        raise HTTPException(status_code=401, detail="PIN inválido")

    # Clear rate limit on success
    _pin_attempts.pop(lock_key, None)

    # Generate JWT with store_id
    from app.auth import create_token
    token = create_token({
        "user_id": ws["uid"],
        "name": ws["name"],
        "email": ws["email"],
        "role": ws["role"],
        "store_id": ws["store_id"],
        "store_name": ws["store_name"],
    })

    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": ws["uid"],
            "name": ws["name"],
            "email": ws["email"],
            "role": ws["role"],
        },
        "store": {
            "id": ws["store_id"],
            "name": ws["store_name"],
        },
    }


# ═══════════════════════════════════════════════
# STORES ENDPOINTS
# ═══════════════════════════════════════════════

@router.get("/stores")
def list_stores(
    db: sqlite3.Connection = Depends(get_db),
):
    """List all active stores (public — for login screen)."""
    rows = db.execute(
        "SELECT id, name, address, phone FROM stores WHERE active = 1 ORDER BY name"
    ).fetchall()
    return {"stores": [dict(r) for r in rows]}

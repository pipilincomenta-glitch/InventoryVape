"""Order routes - create, manage, checkout."""
from fastapi import APIRouter, Depends, HTTPException
import sqlite3
from datetime import datetime
from app.database import get_db, rows_to_list
from app.schemas import OrderCreate, OrderConfirm
from app.auth import get_current_user, require_role

router = APIRouter(prefix="/api/orders", tags=["orders"])


@router.post("", status_code=201)
def create_order(
    order: OrderCreate,
    user: dict = Depends(get_current_user),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new order (client reserves product)."""
    if user["role"] != "client":
        raise HTTPException(status_code=403, detail="Only clients can create orders")

    # Validate products exist and have stock
    total = 0
    for item in order.items:
        product = db.execute(
            "SELECT id, name, price, stock, out_of_service FROM products WHERE id = ? AND active = 1",
            (item.product_id,),
        ).fetchone()
        if not product:
            raise HTTPException(status_code=404, detail=f"Product {item.product_id} not found")
        if product["out_of_service"]:
            raise HTTPException(status_code=400, detail=f"{product['name']} is out of service")
        if product["stock"] < item.quantity:
            raise HTTPException(status_code=400, detail=f"Insufficient stock for {product['name']}")
        total += product["price"] * item.quantity

    # Create order
    cursor = db.execute(
        "INSERT INTO orders (client_id, status, total, notes) VALUES (?, 'pending', ?, ?)",
        (user["user_id"], total, order.notes),
    )
    order_id = cursor.lastrowid

    # Create order items and reduce stock
    for item in order.items:
        product = db.execute(
            "SELECT price FROM products WHERE id = ?", (item.product_id,)
        ).fetchone()
        db.execute(
            "INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?)",
            (order_id, item.product_id, item.quantity, product["price"]),
        )
        db.execute(
            "UPDATE products SET stock = stock - ? WHERE id = ?",
            (item.quantity, item.product_id),
        )

    db.commit()
    return {
        "order_id": order_id,
        "total": total,
        "message": "Order created successfully",
    }


@router.get("/my")
def get_my_orders(
    user: dict = Depends(get_current_user),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get current user's orders."""
    orders = db.execute(
        """SELECT o.*, u.name as worker_name
           FROM orders o
           LEFT JOIN users u ON o.worker_id = u.id
           WHERE o.client_id = ?
           ORDER BY o.created_at DESC""",
        (user["user_id"],),
    ).fetchall()

    result = []
    for order in orders:
        items = db.execute(
            """SELECT oi.*, p.name as product_name
               FROM order_items oi
               JOIN products p ON oi.product_id = p.id
               WHERE oi.order_id = ?""",
            (order["id"],),
        ).fetchall()
        o = dict(order)
        o["items"] = rows_to_list(items)
        result.append(o)

    return {"orders": result}


@router.get("/pending")
def get_pending_orders(
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get pending orders (worker/admin)."""
    orders = db.execute(
        """SELECT o.*, u.name as client_name, u.phone as client_phone
           FROM orders o
           JOIN users u ON o.client_id = u.id
           WHERE o.status = 'pending'
           ORDER BY o.created_at ASC""",
    ).fetchall()

    result = []
    for order in orders:
        items = db.execute(
            """SELECT oi.*, p.name as product_name
               FROM order_items oi
               JOIN products p ON oi.product_id = p.id
               WHERE oi.order_id = ?""",
            (order["id"],),
        ).fetchall()
        o = dict(order)
        o["items"] = rows_to_list(items)
        result.append(o)

    return {"orders": result}


@router.post("/{order_id}/confirm")
def confirm_order(
    order_id: int,
    confirm: OrderConfirm,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Confirm an order (worker assigns themselves)."""
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order["status"] != "pending":
        raise HTTPException(status_code=400, detail="Order is not pending")

    db.execute(
        "UPDATE orders SET worker_id = ?, status = 'confirmed', updated_at = ? WHERE id = ?",
        (confirm.worker_id, datetime.now().isoformat(), order_id),
    )
    db.commit()
    return {"message": "Order confirmed"}


@router.post("/{order_id}/pay")
def pay_order(
    order_id: int,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
    ):
    """Mark order as paid."""
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order["status"] not in ("pending", "confirmed"):
        raise HTTPException(status_code=400, detail="Order cannot be paid in current status")

    db.execute(
        "UPDATE orders SET status = 'paid', worker_id = ?, updated_at = ? WHERE id = ?",
        (user["user_id"], datetime.now().isoformat(), order_id),
    )
    db.commit()
    return {"message": "Order paid"}


@router.post("/{order_id}/complete")
def complete_order(
    order_id: int,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Mark order as completed."""
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")
    if order["status"] != "paid":
        raise HTTPException(status_code=400, detail="Order must be paid first")

    db.execute(
        "UPDATE orders SET status = 'completed', updated_at = ? WHERE id = ?",
        (datetime.now().isoformat(), order_id),
    )
    db.commit()
    return {"message": "Order completed"}


@router.post("/{order_id}/cancel")
def cancel_order(
    order_id: int,
    user: dict = Depends(get_current_user),
    db: sqlite3.Connection = Depends(get_db),
):
    """Cancel an order and restore stock."""
    order = db.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    if not order:
        raise HTTPException(status_code=404, detail="Order not found")

    # Authorization: only the order's client, or admin/worker, can cancel
    if user["role"] == "client" and order["client_id"] != user["user_id"]:
        raise HTTPException(status_code=403, detail="Not authorized to cancel this order")

    if order["status"] in ("paid", "completed"):
        raise HTTPException(status_code=400, detail="Cannot cancel paid/completed order")

    # Restore stock
    items = db.execute(
        "SELECT product_id, quantity FROM order_items WHERE order_id = ?",
        (order_id,),
    ).fetchall()
    for item in items:
        db.execute(
            "UPDATE products SET stock = stock + ? WHERE id = ?",
            (item["quantity"], item["product_id"]),
        )

    db.execute(
        "UPDATE orders SET status = 'cancelled', updated_at = ? WHERE id = ?",
        (datetime.now().isoformat(), order_id),
    )
    db.commit()
    return {"message": "Order cancelled and stock restored"}

"""Catalog routes - brands, product models, product options CRUD."""
from fastapi import APIRouter, Depends, HTTPException, Query
import sqlite3
from app.database import get_db, rows_to_list, row_to_dict
from app.schemas import BrandCreate, BrandUpdate, ModelCreate, ModelUpdate, OptionCreate, OptionUpdate
from app.auth import get_current_user, require_role

router = APIRouter(prefix="/api/catalog", tags=["catalog"])


# ─── Brands ───────────────────────────────────
@router.get("/brands")
def get_brands(
    category_id: int = Query(None),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all active brands, optionally filtered by category."""
    query = "SELECT b.*, c.name as category_name FROM brands b LEFT JOIN categories c ON b.category_id = c.id WHERE b.active = 1"
    params = []
    if category_id:
        query += " AND b.category_id = ?"
        params.append(category_id)
    query += " ORDER BY b.name"
    rows = db.execute(query, params).fetchall()
    return {"brands": rows_to_list(rows)}


@router.get("/brands/{brand_id}")
def get_brand(brand_id: int, db: sqlite3.Connection = Depends(get_db)):
    """Get single brand with its models."""
    brand = db.execute(
        """SELECT b.*, c.name as category_name
           FROM brands b
           LEFT JOIN categories c ON b.category_id = c.id
           WHERE b.id = ?""",
        (brand_id,),
    ).fetchone()
    if not brand:
        raise HTTPException(status_code=404, detail="Brand not found")

    models = db.execute(
        "SELECT * FROM product_models WHERE brand_id = ? AND active = 1 ORDER BY name",
        (brand_id,),
    ).fetchall()

    result = dict(brand)
    # Attach options to each model
    models_list = []
    for m in models:
        mdict = dict(m)
        opts = db.execute(
            "SELECT * FROM product_options WHERE product_model_id = ? AND active = 1 ORDER BY option_type, name",
            (mdict["id"],),
        ).fetchall()
        mdict["options"] = rows_to_list(opts)
        models_list.append(mdict)
    result["models"] = models_list
    return result


@router.post("/brands", status_code=201)
def create_brand(
    brand: BrandCreate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new brand (admin only)."""
    try:
        cursor = db.execute(
            "INSERT INTO brands (name, category_id, logo_url) VALUES (?, ?, ?)",
            (brand.name, brand.category_id, brand.logo_url),
        )
        db.commit()
        return {"id": cursor.lastrowid, "message": "Brand created"}
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="Brand already exists in this category")


@router.put("/brands/{brand_id}")
def update_brand(
    brand_id: int,
    brand: BrandUpdate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update a brand (admin only)."""
    existing = db.execute("SELECT id FROM brands WHERE id = ?", (brand_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Brand not found")

    updates = []
    params = []
    if brand.name is not None:
        updates.append("name = ?")
        params.append(brand.name)
    if brand.logo_url is not None:
        updates.append("logo_url = ?")
        params.append(brand.logo_url)
    if brand.active is not None:
        updates.append("active = ?")
        params.append(1 if brand.active else 0)

    if updates:
        params.append(brand_id)
        db.execute(f"UPDATE brands SET {', '.join(updates)} WHERE id = ?", params)
        db.commit()

    return {"message": "Brand updated"}


@router.delete("/brands/{brand_id}")
def delete_brand(
    brand_id: int,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Soft delete a brand (admin only)."""
    db.execute("UPDATE brands SET active = 0 WHERE id = ?", (brand_id,))
    db.commit()
    return {"message": "Brand deleted"}


# ─── Product Models ───────────────────────────
@router.get("/models")
def get_models(
    brand_id: int = Query(None),
    category_id: int = Query(None),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all active product models, optionally filtered by brand or category."""
    query = """
        SELECT pm.*, b.name as brand_name, c.name as category_name
        FROM product_models pm
        JOIN brands b ON pm.brand_id = b.id
        LEFT JOIN categories c ON b.category_id = c.id
        WHERE pm.active = 1 AND b.active = 1
    """
    params = []
    if brand_id:
        query += " AND pm.brand_id = ?"
        params.append(brand_id)
    if category_id:
        query += " AND b.category_id = ?"
        params.append(category_id)
    query += " ORDER BY b.name, pm.name"
    rows = db.execute(query, params).fetchall()
    return {"models": rows_to_list(rows)}


@router.get("/models/{model_id}")
def get_model(model_id: int, db: sqlite3.Connection = Depends(get_db)):
    """Get single product model with its options."""
    model = db.execute(
        """SELECT pm.*, b.name as brand_name, c.name as category_name
           FROM product_models pm
           JOIN brands b ON pm.brand_id = b.id
           LEFT JOIN categories c ON b.category_id = c.id
           WHERE pm.id = ?""",
        (model_id,),
    ).fetchone()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")

    options = db.execute(
        "SELECT * FROM product_options WHERE product_model_id = ? AND active = 1 ORDER BY option_type, name",
        (model_id,),
    ).fetchall()

    result = dict(model)
    result["options"] = rows_to_list(options)
    return result


@router.post("/models", status_code=201)
def create_model(
    model: ModelCreate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new product model (admin only)."""
    brand = db.execute("SELECT id FROM brands WHERE id = ?", (model.brand_id,)).fetchone()
    if not brand:
        raise HTTPException(status_code=404, detail="Brand not found")

    cursor = db.execute(
        "INSERT INTO product_models (name, brand_id, description, image_url) VALUES (?, ?, ?, ?)",
        (model.name, model.brand_id, model.description, model.image_url),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Model created"}


@router.put("/models/{model_id}")
def update_model(
    model_id: int,
    model: ModelUpdate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update a product model (admin only)."""
    existing = db.execute("SELECT id FROM product_models WHERE id = ?", (model_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Model not found")

    updates = []
    params = []
    if model.name is not None:
        updates.append("name = ?")
        params.append(model.name)
    if model.description is not None:
        updates.append("description = ?")
        params.append(model.description)
    if model.image_url is not None:
        updates.append("image_url = ?")
        params.append(model.image_url)
    if model.active is not None:
        updates.append("active = ?")
        params.append(1 if model.active else 0)

    if updates:
        params.append(model_id)
        db.execute(f"UPDATE product_models SET {', '.join(updates)} WHERE id = ?", params)
        db.commit()

    return {"message": "Model updated"}


@router.delete("/models/{model_id}")
def delete_model(
    model_id: int,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Soft delete a product model (admin only)."""
    db.execute("UPDATE product_models SET active = 0 WHERE id = ?", (model_id,))
    db.commit()
    return {"message": "Model deleted"}


# ─── Product Options ──────────────────────────
@router.get("/options")
def get_options(
    model_id: int = Query(None),
    option_type: str = Query(None),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all active product options, optionally filtered by model or type."""
    query = """
        SELECT po.*, pm.name as model_name, b.name as brand_name, c.name as category_name
        FROM product_options po
        JOIN product_models pm ON po.product_model_id = pm.id
        JOIN brands b ON pm.brand_id = b.id
        LEFT JOIN categories c ON b.category_id = c.id
        WHERE po.active = 1 AND pm.active = 1 AND b.active = 1
    """
    params = []
    if model_id:
        query += " AND po.product_model_id = ?"
        params.append(model_id)
    if option_type:
        query += " AND po.option_type = ?"
        params.append(option_type)
    query += " ORDER BY po.option_type, po.name"
    rows = db.execute(query, params).fetchall()
    return {"options": rows_to_list(rows)}


@router.get("/options/{option_id}")
def get_option(option_id: int, db: sqlite3.Connection = Depends(get_db)):
    """Get single product option."""
    option = db.execute(
        """SELECT po.*, pm.name as model_name, b.name as brand_name, c.name as category_name
           FROM product_options po
           JOIN product_models pm ON po.product_model_id = pm.id
           JOIN brands b ON pm.brand_id = b.id
           LEFT JOIN categories c ON b.category_id = c.id
           WHERE po.id = ?""",
        (option_id,),
    ).fetchone()
    if not option:
        raise HTTPException(status_code=404, detail="Option not found")
    return dict(option)


@router.post("/options", status_code=201)
def create_option(
    option: OptionCreate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new product option (admin only)."""
    model = db.execute("SELECT id FROM product_models WHERE id = ?", (option.product_model_id,)).fetchone()
    if not model:
        raise HTTPException(status_code=404, detail="Model not found")

    try:
        cursor = db.execute(
            """INSERT INTO product_options (name, product_model_id, option_type, price, stock, barcode, familia, image_url, nicotine_mg, device_type, cart_type, puffs, ohm, description)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (option.name, option.product_model_id, option.option_type,
             option.price, option.stock, option.barcode,
             option.familia or "", option.image_url or "",
             option.nicotine_mg or "", option.device_type or "",
             option.cart_type or "", option.puffs or "", option.ohm or "", option.description or ""),
        )
        db.commit()
        return {"id": cursor.lastrowid, "message": "Option created"}
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=409, detail="Option barcode already exists")


@router.put("/options/{option_id}")
def update_option(
    option_id: int,
    option: OptionUpdate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update a product option (admin only)."""
    existing = db.execute("SELECT id FROM product_options WHERE id = ?", (option_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Option not found")

    updates = []
    params = []
    if option.name is not None:
        updates.append("name = ?")
        params.append(option.name)
    if option.option_type is not None:
        updates.append("option_type = ?")
        params.append(option.option_type)
    if option.price is not None:
        updates.append("price = ?")
        params.append(option.price)
    if option.stock is not None:
        updates.append("stock = ?")
        params.append(option.stock)
    if option.barcode is not None:
        updates.append("barcode = ?")
        params.append(option.barcode)
    if option.familia is not None:
        updates.append("familia = ?")
        params.append(option.familia)
    if option.image_url is not None:
        updates.append("image_url = ?")
        params.append(option.image_url)
    if option.nicotine_mg is not None:
        updates.append("nicotine_mg = ?")
        params.append(option.nicotine_mg)
    if option.device_type is not None:
        updates.append("device_type = ?")
        params.append(option.device_type)
    if option.cart_type is not None:
        updates.append("cart_type = ?")
        params.append(option.cart_type)
    if option.puffs is not None:
        updates.append("puffs = ?")
        params.append(option.puffs)
    if option.ohm is not None:
        updates.append("ohm = ?")
        params.append(option.ohm)
    if option.description is not None:
        updates.append("description = ?")
        params.append(option.description)
    if option.active is not None:
        updates.append("active = ?")
        params.append(1 if option.active else 0)

    if updates:
        params.append(option_id)
        db.execute(f"UPDATE product_options SET {', '.join(updates)} WHERE id = ?", params)
        db.commit()

    return {"message": "Option updated"}


@router.delete("/options/{option_id}")
def delete_option(
    option_id: int,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Soft delete a product option (admin only)."""
    db.execute("UPDATE product_options SET active = 0 WHERE id = ?", (option_id,))
    db.commit()
    return {"message": "Option deleted"}


# ─── Catalog Tree (full hierarchy) ────────────
@router.get("/tree")
def get_catalog_tree(db: sqlite3.Connection = Depends(get_db)):
    """Get the catalog tree structure: Categories → Brands → Models (with option counts).
    Options are loaded lazily via /api/catalog/brands/{id} to keep this response small.
    """
    rows = db.execute("""
        SELECT
            c.id as cat_id, c.name as cat_name, c.sort_order as cat_sort, c.active as cat_active,
            b.id as brand_id, b.name as brand_name, b.logo_url, b.category_id as brand_cat_id, b.active as brand_active,
            pm.id as model_id, pm.name as model_name, pm.description as model_desc, pm.brand_id as model_brand_id, pm.active as model_active,
            COUNT(po.id) as option_count
        FROM categories c
        LEFT JOIN brands b ON b.category_id = c.id AND b.active = 1
        LEFT JOIN product_models pm ON pm.brand_id = b.id AND pm.active = 1
        LEFT JOIN product_options po ON po.product_model_id = pm.id AND po.active = 1
        WHERE c.active = 1
        GROUP BY c.id, b.id, pm.id
        ORDER BY c.sort_order, b.name, pm.name
    """).fetchall()

    # Build nested structure
    cats_dict = {}
    for r in rows:
        cat_id = r["cat_id"]
        if cat_id not in cats_dict:
            cats_dict[cat_id] = {
                "id": cat_id, "name": r["cat_name"], "sort_order": r["cat_sort"],
                "active": r["cat_active"], "brands_dict": {}
            }

        brand_id = r["brand_id"]
        if brand_id and brand_id not in cats_dict[cat_id]["brands_dict"]:
            cats_dict[cat_id]["brands_dict"][brand_id] = {
                "id": brand_id, "name": r["brand_name"], "logo_url": r["logo_url"],
                "category_id": r["brand_cat_id"], "active": r["brand_active"],
                "models": []
            }

        model_id = r["model_id"]
        if model_id:
            bd = cats_dict[cat_id]["brands_dict"].get(brand_id)
            if bd:
                bd["models"].append({
                    "id": model_id, "name": r["model_name"], "description": r["model_desc"],
                    "brand_id": r["model_brand_id"], "active": r["model_active"],
                    "option_count": r["option_count"]
                })

    # Convert to sorted list format
    result = []
    for cat_id in sorted(cats_dict.keys(), key=lambda x: cats_dict[x]["sort_order"] or 0):
        cat = cats_dict[cat_id]
        cat_brands = []
        for brand_id in sorted(cat["brands_dict"].keys(), key=lambda x: cat["brands_dict"][x]["name"] or ""):
            brand = cat["brands_dict"][brand_id]
            brand["models"].sort(key=lambda m: m["name"] or "")
            cat_brands.append(brand)
        cat.pop("brands_dict")
        cat["brands"] = cat_brands
        result.append(cat)

    return {"tree": result}

"""Product routes - catalog, CRUD, categories."""
from fastapi import APIRouter, Depends, HTTPException, Query
import sqlite3
from app.database import get_db, rows_to_list, row_to_dict
from app.schemas import ProductCreate, ProductUpdate, CategoryCreate, OfferCreate
from app.auth import get_current_user, require_role

router = APIRouter(prefix="/api/products", tags=["products"])


# ─── Categories ───────────────────────────────
@router.get("/categories")
def get_categories(db: sqlite3.Connection = Depends(get_db)):
    """Get all active categories."""
    rows = db.execute(
        "SELECT * FROM categories WHERE active = 1 ORDER BY sort_order"
    ).fetchall()
    return {"categories": rows_to_list(rows)}


@router.post("/categories", status_code=201)
def create_category(
    cat: CategoryCreate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new category (admin only)."""
    cursor = db.execute(
        "INSERT INTO categories (name, description, icon, sort_order) VALUES (?, ?, ?, ?)",
        (cat.name, cat.description, cat.icon, cat.sort_order),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Category created"}


# ─── Products (Public - no prices) ────────────
@router.get("/catalog")
def get_catalog(
    category_id: int = Query(None),
    search: str = Query(None),
    db: sqlite3.Connection = Depends(get_db),
):
    """Public catalog - no prices shown to clients. Returns brand/model/option hierarchy."""
    query = """
        SELECT p.id, p.name, p.description, p.category_id, p.brand_id, p.model_id, p.option_id,
               p.image_url, p.stock, p.out_of_service, p.options,
               c.name as category_name, c.icon as category_icon,
               b.name as brand_name,
               pm.name as model_name,
               po.name as option_name,
               o.name as offer_name, o.discount_type, o.value as offer_value
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN brands b ON p.brand_id = b.id
        LEFT JOIN product_models pm ON p.model_id = pm.id
        LEFT JOIN product_options po ON p.option_id = po.id
        LEFT JOIN offers o ON p.id = o.product_id AND o.active = 1
            AND (o.start_date IS NULL OR o.start_date <= date('now'))
            AND (o.end_date IS NULL OR o.end_date >= date('now'))
        WHERE p.active = 1
    """
    params = []

    if category_id:
        query += " AND p.category_id = ?"
        params.append(category_id)
    if search:
        query += " AND (p.name LIKE ? OR p.description LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])

    query += " ORDER BY p.name"
    rows = db.execute(query, params).fetchall()

    products = []
    for r in rows:
        p = dict(r)
        p["has_offer"] = p["offer_name"] is not None
        products.append(p)

    return {"products": products}


# ─── Products (Admin/Worker - with prices) ────
@router.get("")
def get_products(
    active_only: bool = Query(True),
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all products with prices (admin/worker only)."""
    query = "SELECT * FROM products"
    if active_only:
        query += " WHERE active = 1"
    query += " ORDER BY name"
    rows = db.execute(query).fetchall()
    return {"products": rows_to_list(rows)}


@router.get("/{product_id}")
def get_product(product_id: int, db: sqlite3.Connection = Depends(get_db)):
    """Get single product details."""
    product = db.execute(
        """SELECT p.*, c.name as category_name
           FROM products p
           LEFT JOIN categories c ON p.category_id = c.id
           WHERE p.id = ?""",
        (product_id,),
    ).fetchone()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    offer = db.execute(
        """SELECT * FROM offers
           WHERE product_id = ? AND active = 1
           AND (start_date IS NULL OR start_date <= date('now'))
           AND (end_date IS NULL OR end_date >= date('now'))""",
        (product_id,),
    ).fetchone()

    result = dict(product)
    result["offer"] = dict(offer) if offer else None
    return result


# ─── Admin only: Create/Delete ────────────────
@router.post("", status_code=201)
def create_product(
    product: ProductCreate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new product (ADMIN only). Auto-generates name from brand+model+option."""
    # Auto-generate product name if not provided
    name = product.name
    if not name:
        parts = []
        if product.brand_id:
            brand = db.execute("SELECT name FROM brands WHERE id = ?", (product.brand_id,)).fetchone()
            if brand: parts.append(brand["name"])
        if product.model_id:
            model = db.execute("SELECT name FROM product_models WHERE id = ?", (product.model_id,)).fetchone()
            if model: parts.append(model["name"])
        if product.option_id:
            opt = db.execute("SELECT name FROM product_options WHERE id = ?", (product.option_id,)).fetchone()
            if opt: parts.append(opt["name"])
        name = " - ".join(parts) if parts else "Producto"

    cursor = db.execute(
        """INSERT INTO products
           (name, description, category_id, brand_id, model_id, option_id,
            barcode, image_url, price, stock, min_stock, options)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            name, product.description, product.category_id,
            product.brand_id, product.model_id, product.option_id,
            product.barcode, product.image_url, product.price,
            product.stock, product.min_stock, product.options,
        ),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Product created"}


@router.delete("/{product_id}")
def delete_product(
    product_id: int,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Soft delete a product (ADMIN only)."""
    db.execute("UPDATE products SET active = 0 WHERE id = ?", (product_id,))
    db.commit()
    return {"message": "Product deleted"}


# ─── Worker: Toggle status only ───────────────
@router.post("/{product_id}/toggle-service")
def toggle_service(
    product_id: int,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Toggle product out of service status (Worker/Admin)."""
    product = db.execute(
        "SELECT out_of_service FROM products WHERE id = ?", (product_id,)
    ).fetchone()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    new_status = 0 if product["out_of_service"] else 1
    db.execute(
        "UPDATE products SET out_of_service = ? WHERE id = ?",
        (new_status, product_id),
    )
    db.commit()
    return {
        "out_of_service": new_status,
        "message": "Out of service" if new_status else "Back in service",
    }


@router.post("/{product_id}/toggle-stock")
def toggle_stock(
    product_id: int,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Set product stock to 0 or restore to min_stock (Worker/Admin)."""
    product = db.execute(
        "SELECT stock, min_stock FROM products WHERE id = ?", (product_id,)
    ).fetchone()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")

    if product["stock"] > 0:
        new_stock = 0
        message = "Marked out of stock"
    else:
        new_stock = product["min_stock"]
        message = "Stock restored"

    db.execute(
        "UPDATE products SET stock = ? WHERE id = ?",
        (new_stock, product_id),
    )
    db.commit()
    return {"stock": new_stock, "message": message}


# ─── Offers (Admin only) ──────────────────────
@router.get("/offers/all")
def get_offers(
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all offers (admin only)."""
    rows = db.execute("""
        SELECT o.*, p.name as product_name
        FROM offers o
        JOIN products p ON o.product_id = p.id
        WHERE o.active = 1
        ORDER BY o.name
    """).fetchall()
    return {"offers": rows_to_list(rows)}


@router.post("/offers", status_code=201)
def create_offer(
    offer: OfferCreate,
    user: dict = Depends(require_role("admin")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new offer (admin only)."""
    cursor = db.execute(
        """INSERT INTO offers (product_id, name, discount_type, value, start_date, end_date)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (offer.product_id, offer.name, offer.discount_type, offer.value,
         offer.start_date, offer.end_date),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Offer created"}

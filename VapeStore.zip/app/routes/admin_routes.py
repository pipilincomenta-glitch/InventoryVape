"""Admin dashboard routes - analytics, reports, worker management."""
from fastapi import APIRouter, Depends, Query, HTTPException
from pydantic import BaseModel
from typing import Optional
import sqlite3
from datetime import datetime, timedelta
from app.database import get_db, rows_to_list
from app.auth import require_role

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ─── Store filter helper ───────────────────────
def store_filter(store_id: Optional[int], table: str = "o", col: str = "store_id", user: dict = None):
    """Return (where_clause, params) for optional store filtering.
       For managers, always filters by their assigned store regardless of store_id param.
       Usage: where, params = store_filter(sid, "o", user=user) → ("AND o.store_id = ?", [sid])"""
    # Managers are locked to their assigned store
    if user and user.get("role") == "manager" and user.get("store_id"):
        return f"AND {table}.{col} = ?", [user["store_id"]]
    if store_id is not None:
        return f"AND {table}.{col} = ?", [store_id]
    return "", []

@router.get("/dashboard")
def get_dashboard(
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get admin dashboard summary."""
    today = datetime.now().strftime("%Y-%m-%d")
    sf, sp = store_filter(store_id, "orders", user=user)

    # Today's stats
    today_orders = db.execute(
        "SELECT COUNT(*) as count, COALESCE(SUM(total), 0) as revenue "
        "FROM orders WHERE DATE(created_at) = ? AND status IN ('paid', 'completed') " + sf,
        (today, *sp),
    ).fetchone()

    # Pending orders
    pending = db.execute(
        "SELECT COUNT(*) as count FROM orders WHERE status = 'pending' " + sf,
        sp,
    ).fetchone()

    # Total products (count from product_options, not empty products table)
    products = db.execute(
        "SELECT COUNT(*) as count FROM product_options WHERE active = 1"
    ).fetchone()

    # Low stock alerts (from store_inventory when store_id provided)
    if store_id:
        low_stock = db.execute(
            "SELECT COUNT(*) as count FROM store_inventory WHERE store_id = ? AND stock <= 3",
            (store_id,)
        ).fetchone()
    else:
        low_stock = db.execute(
            "SELECT COUNT(*) as count FROM product_options WHERE active = 1 AND stock <= 3"
        ).fetchone()

    # Active workers today
    active_workers = db.execute(
        "SELECT COUNT(DISTINCT worker_id) as count FROM orders "
        "WHERE DATE(created_at) = ? AND worker_id IS NOT NULL " + sf,
        (today, *sp),
    ).fetchone()

    return {
        "today": {
            "orders": today_orders["count"],
            "revenue": today_orders["revenue"],
            "pending_orders": pending["count"],
            "active_workers": active_workers["count"],
        },
        "products": {
            "total": products["count"],
            "low_stock": low_stock["count"],
        },
    }


@router.get("/sales")
def get_sales_chart(
    days: int = Query(30, ge=1, le=365),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get sales data for charts."""
    rows = db.execute(
        """SELECT DATE(created_at) as sale_date,
                  COUNT(*) as orders,
                  SUM(total) as revenue
           FROM orders
           WHERE status IN ('paid', 'completed')
           AND created_at >= date('now', ?)
           GROUP BY DATE(created_at)
           ORDER BY sale_date""",
        (f"-{days} days",),
    ).fetchall()
    return {"data": rows_to_list(rows)}


@router.get("/top-products")
def get_top_products(
    days: int = Query(30, ge=1, le=365),
    limit: int = Query(10, ge=1, le=50),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get top selling products."""
    rows = db.execute(
        """SELECT p.id, p.name, SUM(oi.quantity) as total_sold,
                  SUM(oi.quantity * oi.unit_price) as total_revenue
           FROM order_items oi
           JOIN products p ON oi.product_id = p.id
           JOIN orders o ON oi.order_id = o.id
           WHERE o.status IN ('paid', 'completed')
           AND o.created_at >= date('now', ?)
           GROUP BY p.id
           ORDER BY total_sold DESC
           LIMIT ?""",
        (f"-{days} days", limit),
    ).fetchall()
    return {"products": rows_to_list(rows)}


@router.get("/workers")
def get_workers_performance(
    days: int = Query(7, ge=1, le=90),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get worker performance stats."""
    rows = db.execute(
        """SELECT u.id, u.name,
                  COUNT(o.id) as total_orders,
                  COALESCE(SUM(o.total), 0) as total_revenue,
                  COUNT(DISTINCT DATE(o.created_at)) as active_days
           FROM users u
           LEFT JOIN orders o ON u.id = o.worker_id
               AND o.status IN ('paid', 'completed')
               AND o.created_at >= date('now', ?)
           WHERE u.role = 'worker' AND u.active = 1
           GROUP BY u.id
           ORDER BY total_orders DESC""",
        (f"-{days} days",),
    ).fetchall()
    return {"workers": rows_to_list(rows)}


@router.get("/analytics")
def get_analytics(
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get advanced analytics."""
    # Average order value
    avg_order = db.execute(
        "SELECT COALESCE(AVG(total), 0) as avg_value FROM orders "
        "WHERE status IN ('paid', 'completed')"
    ).fetchone()

    # Total revenue all time
    total_revenue = db.execute(
        "SELECT COALESCE(SUM(total), 0) as total FROM orders "
        "WHERE status IN ('paid', 'completed')"
    ).fetchone()

    # Total orders all time
    total_orders = db.execute(
        "SELECT COUNT(*) as count FROM orders WHERE status IN ('paid', 'completed')"
    ).fetchone()

    # Unique clients
    unique_clients = db.execute(
        "SELECT COUNT(DISTINCT client_id) as count FROM orders "
        "WHERE status IN ('paid', 'completed')"
    ).fetchone()

    # Conversion rate (pending vs completed)
    pending_count = db.execute(
        "SELECT COUNT(*) as count FROM orders WHERE status = 'pending'"
    ).fetchone()
    completed_count = db.execute(
        "SELECT COUNT(*) as count FROM orders WHERE status IN ('paid', 'completed')"
    ).fetchone()

    conversion = 0
    if pending_count["count"] + completed_count["count"] > 0:
        conversion = round(
            completed_count["count"] / (pending_count["count"] + completed_count["count"]) * 100,
            1,
        )

    return {
        "avg_order_value": round(avg_order["avg_value"], 2),
        "total_revenue": total_revenue["total"],
        "total_orders": total_orders["count"],
        "unique_clients": unique_clients["count"],
        "conversion_rate": conversion,
    }


@router.get("/analytics/comparison")
def get_analytics_comparison(
    store_id: Optional[int] = Query(None),
    brand_id: Optional[int] = Query(None),
    category_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get comparative analytics: today vs yesterday, week vs last week, month vs last month."""
    sf, sp = store_filter(store_id, "orders", user=user)
    sf2, sp2 = store_filter(store_id, "o", user=user)  # for JOIN queries using alias "o"

    # Build brand/category filter for top products queries
    top_extra_joins = ""
    top_extra_params = []
    top_sf2 = sf2  # copy of sf2 for top products (may get extra filters)
    if brand_id:
        top_extra_joins += " JOIN product_models pm ON p.product_model_id = pm.id JOIN brands b ON pm.brand_id = b.id"
        top_extra_params.append(brand_id)
        top_sf2 += " AND b.id = ?"
    elif category_id:
        top_extra_joins += " JOIN product_models pm ON p.product_model_id = pm.id JOIN brands b ON pm.brand_id = b.id JOIN categories c ON b.category_id = c.id"
        top_extra_params.append(category_id)
        top_sf2 += " AND c.id = ?"
    def period_stats(start, end, prev_start, prev_end):
        current = db.execute(
            "SELECT COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue"
            " FROM orders WHERE status IN ('paid','completed')"
            " AND created_at >= ? AND created_at < ? " + sf,
            (start, end, *sp),
        ).fetchone()
        prev = db.execute(
            "SELECT COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue"
            " FROM orders WHERE status IN ('paid','completed')"
            " AND created_at >= ? AND created_at < ? " + sf,
            (prev_start, prev_end, *sp),
        ).fetchone()
        return {
            "current_orders": current["orders"],
            "current_revenue": round(current["revenue"], 2),
            "prev_orders": prev["orders"],
            "prev_revenue": round(prev["revenue"], 2),
        }

    from datetime import datetime as dt, timedelta
    now = dt.now()
    today = now.strftime("%Y-%m-%d")
    yesterday = (now - timedelta(days=1)).strftime("%Y-%m-%d")
    tomorrow = (now + timedelta(days=1)).strftime("%Y-%m-%d")

    # This week (Mon-Sun)
    week_start = (now - timedelta(days=now.weekday())).strftime("%Y-%m-%d")
    last_week_start = (now - timedelta(days=now.weekday() + 7)).strftime("%Y-%m-%d")
    last_week_end = week_start

    # This month
    month_start = now.replace(day=1).strftime("%Y-%m-%d")
    last_month_end = month_start
    last_month_start = (now.replace(day=1) - timedelta(days=1)).replace(day=1).strftime("%Y-%m-%d")

    # Ticket promedio
    avg_ticket = db.execute(
        "SELECT COALESCE(AVG(total), 0) as avg_val FROM orders"
        " WHERE status IN ('paid','completed') " + sf,
        sp,
    ).fetchone()
    avg_ticket_prev = db.execute(
        "SELECT COALESCE(AVG(total), 0) as avg_val FROM orders"
        " WHERE status IN ('paid','completed')"
        " AND created_at >= ? AND created_at < ? " + sf,
        (last_month_start, last_month_end, *sp),
    ).fetchone()

    # Sales chart data (last 30 days)
    sales_chart = db.execute(
        "SELECT DATE(created_at) as day, COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue"
        " FROM orders WHERE status IN ('paid','completed')"
        " AND created_at >= date('now', '-30 days') " + sf +
        " GROUP BY DATE(created_at) ORDER BY day",
        sp,
    ).fetchall()

    # Top products by quantity
    top_by_qty = db.execute(
        "SELECT p.name, SUM(oi.quantity) as qty, SUM(oi.quantity * oi.unit_price) as revenue"
        " FROM order_items oi"
        " JOIN product_options p ON oi.product_id = p.id"
        " JOIN orders o ON oi.order_id = o.id"
        + top_extra_joins +
        " WHERE o.status IN ('paid','completed')"
        " AND o.created_at >= date('now', '-30 days') " + top_sf2 +
        " GROUP BY p.id ORDER BY qty DESC LIMIT 10",
        (*sp2, *top_extra_params),
    ).fetchall()

    # Top products by revenue
    top_by_rev = db.execute(
        "SELECT p.name, SUM(oi.quantity) as qty, SUM(oi.quantity * oi.unit_price) as revenue"
        " FROM order_items oi"
        " JOIN product_options p ON oi.product_id = p.id"
        " JOIN orders o ON oi.order_id = o.id"
        + top_extra_joins +
        " WHERE o.status IN ('paid','completed')"
        " AND o.created_at >= date('now', '-30 days') " + top_sf2 +
        " GROUP BY p.id ORDER BY revenue DESC LIMIT 10",
        (*sp2, *top_extra_params),
    ).fetchall()

    # Recent 10 orders
    recent_orders = db.execute(
        "SELECT o.id, o.total, o.status, o.created_at, u.name as worker_name"
        " FROM orders o LEFT JOIN users u ON o.worker_id = u.id"
        " WHERE o.status IN ('paid','completed') " + sf2 +
        " ORDER BY o.created_at DESC LIMIT 10",
        sp2,
    ).fetchall()

    return {
        "today": period_stats(today, tomorrow, yesterday, today),
        "week": period_stats(week_start, tomorrow, last_week_start, last_week_end),
        "month": period_stats(month_start, tomorrow, last_month_start, last_month_end),
        "avg_ticket": {
            "current": round(avg_ticket["avg_val"], 2),
            "prev": round(avg_ticket_prev["avg_val"], 2),
        },
        "sales_chart": [dict(r) for r in sales_chart],
        "top_by_qty": [dict(r) for r in top_by_qty],
        "top_by_rev": [dict(r) for r in top_by_rev],
        "recent_orders": [dict(r) for r in recent_orders],
    }


@router.get("/recent-orders")
def get_recent_orders(
    limit: int = Query(20, ge=1, le=100),
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get recent orders with items."""
    sf, sp = store_filter(store_id, "o", user=user)
    orders = db.execute(
        f"""SELECT o.id, o.status, o.total, o.notes, o.created_at,
                  o.client_id, o.worker_id, o.store_id,
                  u.name as client_name, w.name as worker_name,
                  s.name as store_name
           FROM orders o
           LEFT JOIN users u ON o.client_id = u.id
           LEFT JOIN users w ON o.worker_id = w.id
           LEFT JOIN stores s ON o.store_id = s.id
           WHERE 1=1 {sf}
           ORDER BY o.created_at DESC LIMIT ?""",
        (*sp, limit),
    ).fetchall()
    result = []
    for order in orders:
        items = db.execute(
            """SELECT oi.quantity, oi.unit_price, p.name as product_name
               FROM order_items oi
               JOIN products p ON oi.product_id = p.id
               WHERE oi.order_id = ?""",
            (order["id"],),
        ).fetchall()
        order_dict = dict(order)
        order_dict["items"] = [dict(i) for i in items]
        result.append(order_dict)
    return {"orders": result}


class StockUpdate(BaseModel):
    stock: int

@router.put("/stock/{product_id}")
def update_stock(
    product_id: int,
    body: StockUpdate,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update product_option stock (admin or worker)."""
    option = db.execute("SELECT id, stock, name FROM product_options WHERE id = ?", (product_id,)).fetchone()
    if not option:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    old_stock = option["stock"]
    db.execute("UPDATE product_options SET stock = ? WHERE id = ?", (body.stock, product_id))
    db.commit()
    return {"message": f"Stock actualizado: {old_stock} → {body.stock}", "old_stock": old_stock, "new_stock": body.stock, "name": option["name"]}


# ─── Purchase Orders ─────────────────────────────
class POCreate(BaseModel):
    vendor_name: str
    reference: str = ""
    notes: str = ""
    shipping_cost: float = 0
    discount: float = 0

class POUpdate(BaseModel):
    vendor_name: Optional[str] = None
    reference: Optional[str] = None
    status: Optional[str] = None
    notes: Optional[str] = None
    shipping_cost: Optional[float] = None
    discount: Optional[float] = None

class POItemAdd(BaseModel):
    product_id: Optional[int] = None
    product_name: str
    quantity: int = 1
    unit_cost: float = 0
    retail_price: float = 0

class POItemUpdate(BaseModel):
    quantity: Optional[int] = None
    unit_cost: Optional[float] = None
    retail_price: Optional[float] = None
    received_qty: Optional[int] = None


@router.get("/purchase-orders")
def list_purchase_orders(
    status: str = Query(None),
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    sf, sp = store_filter(store_id, "po", user=user)
    query = """SELECT po.*, s.name as store_name
        FROM purchase_orders po
        LEFT JOIN stores s ON po.store_id = s.id
        WHERE 1=1 """
    params = list(sp)
    if status:
        query += " AND po.status = ?"
        params.append(status)
    query += sf + " ORDER BY created_at DESC"
    rows = db.execute(query, params).fetchall()
    return {"orders": rows_to_list(rows)}


@router.post("/purchase-orders", status_code=201)
def create_purchase_order(
    po: POCreate,
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    cursor = db.execute(
        "INSERT INTO purchase_orders (vendor_name, reference, notes, shipping_cost, discount, created_by, store_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (po.vendor_name, po.reference, po.notes, po.shipping_cost, po.discount, user["user_id"], store_id),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Purchase order created"}


@router.get("/purchase-orders/{po_id}")
def get_purchase_order(
    po_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    po = db.execute("""SELECT po.*, s.name as store_name
        FROM purchase_orders po
        LEFT JOIN stores s ON po.store_id = s.id
        WHERE po.id = ?""", (po_id,)).fetchone()
    if not po:
        raise HTTPException(status_code=404, detail="Purchase order not found")
    items = db.execute("SELECT * FROM purchase_order_items WHERE po_id = ? ORDER BY id", (po_id,)).fetchall()
    result = dict(po)
    result["items"] = [dict(i) for i in items]
    # Calculate totals
    subtotal = sum(i["quantity"] * i["unit_cost"] for i in items)
    result["subtotal"] = round(subtotal, 2)
    result["total"] = round(subtotal + (po["shipping_cost"] or 0) - (po["discount"] or 0), 2)
    return result


@router.put("/purchase-orders/{po_id}")
def update_purchase_order(
    po_id: int,
    po: POUpdate,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    existing = db.execute("SELECT id FROM purchase_orders WHERE id = ?", (po_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Purchase order not found")
    updates, params = [], []
    for field in ["vendor_name", "reference", "status", "notes", "shipping_cost", "discount"]:
        val = getattr(po, field)
        if val is not None:
            updates.append(f"{field} = ?")
            params.append(val)
    if updates:
        updates.append("updated_at = CURRENT_TIMESTAMP")
        params.append(po_id)
        db.execute(f"UPDATE purchase_orders SET {', '.join(updates)} WHERE id = ?", params)
        db.commit()
    return {"message": "Purchase order updated"}


@router.delete("/purchase-orders/{po_id}")
def delete_purchase_order(
    po_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    db.execute("DELETE FROM purchase_order_items WHERE po_id = ?", (po_id,))
    db.execute("DELETE FROM purchase_orders WHERE id = ?", (po_id,))
    db.commit()
    return {"message": "Purchase order deleted"}


@router.post("/purchase-orders/{po_id}/items", status_code=201)
def add_po_item(
    po_id: int,
    item: POItemAdd,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    po = db.execute("SELECT id FROM purchase_orders WHERE id = ?", (po_id,)).fetchone()
    if not po:
        raise HTTPException(status_code=404, detail="Purchase order not found")
    cursor = db.execute(
        "INSERT INTO purchase_order_items (po_id, product_id, product_name, quantity, unit_cost, retail_price) VALUES (?, ?, ?, ?, ?, ?)",
        (po_id, item.product_id, item.product_name, item.quantity, item.unit_cost, item.retail_price),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Item added"}


@router.put("/purchase-orders/{po_id}/items/{item_id}")
def update_po_item(
    po_id: int, item_id: int,
    item: POItemUpdate,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    updates, params = [], []
    for field in ["quantity", "unit_cost", "retail_price", "received_qty"]:
        val = getattr(item, field)
        if val is not None:
            updates.append(f"{field} = ?")
            params.append(val)
    if updates:
        params.extend([item_id, po_id])
        db.execute(f"UPDATE purchase_order_items SET {', '.join(updates)} WHERE id = ? AND po_id = ?", params)
        db.commit()
    return {"message": "Item updated"}


@router.delete("/purchase-orders/{po_id}/items/{item_id}")
def delete_po_item(
    po_id: int, item_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    db.execute("DELETE FROM purchase_order_items WHERE id = ? AND po_id = ?", (item_id, po_id))
    db.commit()
    return {"message": "Item removed"}


@router.post("/purchase-orders/{po_id}/checkin")
def checkin_po(
    po_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Receive items from PO — updates product stock."""
    po = db.execute("SELECT * FROM purchase_orders WHERE id = ?", (po_id,)).fetchone()
    if not po:
        raise HTTPException(status_code=404, detail="Purchase order not found")
    items = db.execute("SELECT * FROM purchase_order_items WHERE po_id = ?", (po_id,)).fetchall()
    updated = 0
    for item in items:
        if item["received_qty"] > 0 and item["product_id"]:
            db.execute(
                "UPDATE product_options SET stock = stock + ? WHERE id = ?",
                (item["received_qty"], item["product_id"]),
            )
            updated += 1
    db.execute("UPDATE purchase_orders SET status = 'received', updated_at = CURRENT_TIMESTAMP WHERE id = ?", (po_id,))
    db.commit()
    return {"message": f"Check-in complete: {updated} product(s) updated", "updated": updated}


# ─── Stock Counts (historial de conteos) ──────────────────────
class StockCountSave(BaseModel):
    count_name: str
    items: list  # [{ product_id, product_name, brand_name, model_name, old_stock, new_stock }]

@router.post("/stock-counts", status_code=201)
def save_stock_count(
    body: StockCountSave,
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Save a stock count session with all its items."""
    cursor = db.execute(
        "INSERT INTO stock_counts (name, created_by, store_id) VALUES (?, ?, ?)",
        (body.count_name, user["user_id"], store_id),
    )
    count_id = cursor.lastrowid
    for item in body.items:
        db.execute(
            "INSERT INTO stock_count_items (count_id, product_option_id, product_name, brand_name, model_name, old_stock, new_stock) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (count_id, item["product_id"], item["product_name"], item.get("brand_name", ""), item.get("model_name", ""), item["old_stock"], item["new_stock"]),
        )
    db.commit()
    return {"id": count_id, "message": f"Conteo '{body.count_name}' guardado con {len(body.items)} cambio(s)"}


@router.get("/stock-counts")
def list_stock_counts(
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """List all stock counts with their items."""
    sf, sp = store_filter(store_id, "sc", user=user)
    counts = db.execute(
        "SELECT sc.*, u.name as worker_name"
        " FROM stock_counts sc"
        " LEFT JOIN users u ON sc.created_by = u.id"
        " WHERE 1=1 " + sf +
        " ORDER BY sc.created_at DESC LIMIT 50",
        sp,
    ).fetchall()
    result = []
    for c in counts:
        items = db.execute(
            "SELECT * FROM stock_count_items WHERE count_id = ? ORDER BY id", (c["id"],)
        ).fetchall()
        result.append({
            "id": c["id"],
            "name": c["name"],
            "worker_name": c["worker_name"] or "—",
            "created_at": c["created_at"],
            "items": [dict(i) for i in items],
            "total_changes": len(items),
        })
    return {"counts": result}


@router.delete("/stock-counts/{count_id}")
def delete_stock_count(
    count_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Delete a stock count (admin only)."""
    db.execute("DELETE FROM stock_count_items WHERE count_id = ?", (count_id,))
    db.execute("DELETE FROM stock_counts WHERE id = ?", (count_id,))
    db.commit()
    return {"message": "Conteo eliminado"}


# ─── Work Shifts (control de horas) ──────────────────────
@router.post("/workers/{worker_id}/clock-in")
def clock_in(
    worker_id: int,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Clock in a worker. Admin can clock in any worker, worker can only clock in themselves."""
    if user["role"] == "worker" and user["user_id"] != worker_id:
        raise HTTPException(status_code=403, detail="Solo puedes registrar tu propia entrada")
    # Check if already clocked in (no clock_out yet)
    active = db.execute(
        "SELECT id FROM work_shifts WHERE worker_id = ? AND clock_out IS NULL", (worker_id,)
    ).fetchone()
    if active:
        raise HTTPException(status_code=400, detail="Ya hay un turno activo para este trabajador")
    cursor = db.execute(
        "INSERT INTO work_shifts (worker_id, clock_in) VALUES (?, datetime('now'))",
        (worker_id,),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Entrada registrada"}


@router.post("/workers/{worker_id}/clock-out")
def clock_out(
    worker_id: int,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Clock out a worker."""
    if user["role"] == "worker" and user["user_id"] != worker_id:
        raise HTTPException(status_code=403, detail="Solo puedes registrar tu propia salida")
    active = db.execute(
        "SELECT id FROM work_shifts WHERE worker_id = ? AND clock_out IS NULL", (worker_id,)
    ).fetchone()
    if not active:
        raise HTTPException(status_code=400, detail="No hay turno activo para este trabajador")
    db.execute(
        "UPDATE work_shifts SET clock_out = datetime('now') WHERE id = ?",
        (active["id"],),
    )
    db.commit()
    return {"message": "Salida registrada", "shift_id": active["id"]}


@router.get("/workers/{worker_id}/shifts")
def get_worker_shifts(
    worker_id: int,
    days: int = Query(30, ge=1, le=90),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get work shifts for a worker."""
    rows = db.execute(
        """SELECT id, worker_id, clock_in, clock_out, notes,
                CASE WHEN clock_out IS NOT NULL
                    THEN ROUND((julianday(clock_out) - julianday(clock_in)) * 24, 2)
                    ELSE NULL END as hours_worked
           FROM work_shifts
           WHERE worker_id = ? AND clock_in >= date('now', ?)
           ORDER BY clock_in DESC""",
        (worker_id, f"-{days} days"),
    ).fetchall()
    return {"shifts": [dict(r) for r in rows]}


@router.delete("/workers/{worker_id}/shifts/{shift_id}")
def delete_work_shift(
    worker_id: int,
    shift_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Delete a work shift record."""
    shift = db.execute("SELECT id, worker_id FROM work_shifts WHERE id = ?", (shift_id,)).fetchone()
    if not shift:
        raise HTTPException(status_code=404, detail="Turno no encontrado")
    db.execute("DELETE FROM work_shifts WHERE id = ?", (shift_id,))
    db.commit()
    return {"message": "Turno eliminado"}


@router.get("/workers/{worker_id}/sales")
def get_worker_sales(
    worker_id: int,
    days: int = Query(30, ge=1, le=90),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get sales stats for a worker."""
    stats = db.execute(
        """SELECT COUNT(*) as total_orders,
                  COALESCE(SUM(total), 0) as total_revenue,
                  COALESCE(AVG(total), 0) as avg_order,
                  COUNT(DISTINCT DATE(created_at)) as active_days
           FROM orders
           WHERE worker_id = ? AND status IN ('paid', 'completed')
           AND created_at >= date('now', ?)""",
        (worker_id, f"-{days} days"),
    ).fetchone()
    # Daily breakdown
    daily = db.execute(
        """SELECT DATE(created_at) as day, COUNT(*) as orders, SUM(total) as revenue
           FROM orders
           WHERE worker_id = ? AND status IN ('paid', 'completed')
           AND created_at >= date('now', ?)
           GROUP BY DATE(created_at)
           ORDER BY day DESC""",
        (worker_id, f"-{days} days"),
    ).fetchall()
    return {
        "stats": dict(stats) if stats else {},
        "daily": [dict(d) for d in daily],
    }


@router.get("/shifts/week")
def get_week_shifts(
    start: str = Query(..., description="Week start date YYYY-MM-DD"),
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all shifts for a full week (Mon-Sun) — used by calendar view."""
    from datetime import datetime as dt
    start_dt = dt.strptime(start, "%Y-%m-%d")
    # End = start + 6 days
    end_dt = start_dt + timedelta(days=6)
    end_str = end_dt.strftime("%Y-%m-%d") + " 23:59:59"

    sf, sp = store_filter(store_id, "ws", user=user)
    rows = db.execute(
        "SELECT ws.id, ws.worker_id, ws.clock_in, ws.clock_out, ws.notes,"
        " u.name as worker_name,"
        " CASE WHEN ws.clock_out IS NOT NULL"
        "     THEN ROUND((julianday(ws.clock_out) - julianday(ws.clock_in)) * 24, 2)"
        "     ELSE NULL END as hours_worked"
        " FROM work_shifts ws"
        " LEFT JOIN users u ON ws.worker_id = u.id"
        " WHERE ws.clock_in >= ? AND ws.clock_in <= ? " + sf +
        " ORDER BY ws.clock_in",
        (start + " 00:00:00", end_str, *sp),
    ).fetchall()
    return {"shifts": [dict(r) for r in rows]}


@router.get("/workers/all-stats")
def get_all_workers_stats(
    days: int = Query(30, ge=1, le=90),
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get combined stats for all workers (hours + sales)."""
    sf, sp = store_filter(store_id, "ws", user=user)
    sf2, sp2 = store_filter(store_id, "orders", user=user)
    # Workers with shift hours
    hours = db.execute(
        "SELECT u.id, u.name, u.email, u.phone, u.active, u.created_at,"
        " COALESCE(SUM("
        "   CASE WHEN ws.clock_out IS NOT NULL"
        "   THEN (julianday(ws.clock_out) - julianday(ws.clock_in)) * 24"
        "   ELSE 0 END"
        " ), 0) as total_hours,"
        " COUNT(ws.id) as total_shifts"
        " FROM users u"
        " LEFT JOIN work_shifts ws ON u.id = ws.worker_id"
        "     AND ws.clock_in >= date('now', ?) " + sf +
        " WHERE u.role = 'worker'"
        " GROUP BY u.id ORDER BY u.name",
        (*sp, f"-{days} days"),
    ).fetchall()
    # Workers with sales
    sales = db.execute(
        "SELECT worker_id,"
        " COUNT(*) as total_orders,"
        " COALESCE(SUM(total), 0) as total_revenue,"
        " COALESCE(AVG(total), 0) as avg_order"
        " FROM orders"
        " WHERE worker_id IS NOT NULL AND status IN ('paid', 'completed')"
        " AND created_at >= date('now', ?) " + sf2 +
        " GROUP BY worker_id",
        (f"-{days} days", *sp2),
    ).fetchall()
    sales_map = {s["worker_id"]: dict(s) for s in sales}

    result = []
    for h in hours:
        d = dict(h)
        s = sales_map.get(h["id"], {})
        d["total_orders"] = s.get("total_orders", 0)
        d["total_revenue"] = s.get("total_revenue", 0)
        d["avg_order"] = s.get("avg_order", 0)
        result.append(d)
    return {"workers": result}


# ─── Scheduled Shifts (programación de horarios) ──────────────────────
class ScheduledShiftCreate(BaseModel):
    worker_id: int
    date: str  # YYYY-MM-DD
    start_time: str  # HH:MM
    end_time: str  # HH:MM
    notes: str = ""

class ScheduledShiftUpdate(BaseModel):
    start_time: Optional[str] = None
    end_time: Optional[str] = None
    notes: Optional[str] = None


@router.get("/scheduled-shifts")
def get_scheduled_shifts(
    start: str = Query(..., description="Start date YYYY-MM-DD"),
    end: str = Query(..., description="End date YYYY-MM-DD"),
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get all scheduled shifts for a date range."""
    sf, sp = store_filter(store_id, "ss", user=user)
    rows = db.execute(
        "SELECT ss.*, u.name as worker_name"
        " FROM scheduled_shifts ss"
        " LEFT JOIN users u ON ss.worker_id = u.id"
        " WHERE ss.date >= ? AND ss.date <= ? " + sf +
        " ORDER BY ss.date, ss.start_time",
        (start, end, *sp),
    ).fetchall()
    return {"shifts": [dict(r) for r in rows]}


@router.get("/scheduled-shifts/{shift_id}")
def get_scheduled_shift(
    shift_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get a single scheduled shift by ID."""
    row = db.execute(
        """SELECT ss.*, u.name as worker_name
           FROM scheduled_shifts ss
           LEFT JOIN users u ON ss.worker_id = u.id
           WHERE ss.id = ?""",
        (shift_id,),
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Turno no encontrado")
    return {"shift": dict(row)}


@router.post("/scheduled-shifts", status_code=201)
def create_scheduled_shift(
    body: ScheduledShiftCreate,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a scheduled shift."""
    # Check for overlapping shifts for the same worker on the same day
    existing = db.execute(
        """SELECT id FROM scheduled_shifts
           WHERE worker_id = ? AND date = ?
           AND ((start_time <= ? AND end_time > ?) OR (start_time < ? AND end_time >= ?) OR (start_time >= ? AND end_time <= ?))""",
        (body.worker_id, body.date, body.end_time, body.start_time, body.end_time, body.start_time, body.start_time, body.end_time),
    ).fetchall()
    if existing:
        raise HTTPException(status_code=400, detail="Este trabajador ya tiene un turno programado en este horario")

    cursor = db.execute(
        """INSERT INTO scheduled_shifts (worker_id, date, start_time, end_time, notes, created_by)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (body.worker_id, body.date, body.start_time, body.end_time, body.notes, user["user_id"]),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Turno programado creado"}


@router.put("/scheduled-shifts/{shift_id}")
def update_scheduled_shift(
    shift_id: int,
    body: ScheduledShiftUpdate,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update a scheduled shift."""
    existing = db.execute("SELECT id FROM scheduled_shifts WHERE id = ?", (shift_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Turno no encontrado")
    updates, params = [], []
    for field in ["start_time", "end_time", "notes"]:
        val = getattr(body, field)
        if val is not None:
            updates.append(f"{field} = ?")
            params.append(val)
    if updates:
        params.append(shift_id)
        db.execute(f"UPDATE scheduled_shifts SET {', '.join(updates)} WHERE id = ?", params)
        db.commit()
    return {"message": "Turno actualizado"}


@router.delete("/scheduled-shifts/{shift_id}")
def delete_scheduled_shift(
    shift_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Delete a scheduled shift."""
    db.execute("DELETE FROM scheduled_shifts WHERE id = ?", (shift_id,))
    db.commit()
    return {"message": "Turno eliminado"}


@router.post("/scheduled-shifts/copy-week", status_code=201)
def copy_week_shifts(
    from_start: str = Query(..., description="Source week start YYYY-MM-DD"),
    to_start: str = Query(..., description="Target week start YYYY-MM-DD"),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Copy all scheduled shifts from one week to another."""
    from datetime import datetime as dt
    from_delta = dt.strptime(to_start, "%Y-%m-%d") - dt.strptime(from_start, "%Y-%m-%d")

    source_shifts = db.execute(
        "SELECT * FROM scheduled_shifts WHERE date >= ? AND date <= ?",
        (from_start, (dt.strptime(from_start, "%Y-%m-%d") + timedelta(days=6)).strftime("%Y-%m-%d")),
    ).fetchall()

    copied = 0
    for s in source_shifts:
        shift_date = dt.strptime(s["date"], "%Y-%m-%d") + from_delta
        new_date = shift_date.strftime("%Y-%m-%d")
        # Skip if already exists
        exists = db.execute(
            "SELECT id FROM scheduled_shifts WHERE worker_id = ? AND date = ? AND start_time = ?",
            (s["worker_id"], new_date, s["start_time"]),
        ).fetchone()
        if not exists:
            db.execute(
                """INSERT INTO scheduled_shifts (worker_id, date, start_time, end_time, notes, created_by)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (s["worker_id"], new_date, s["start_time"], s["end_time"], s["notes"], user["user_id"]),
            )
            copied += 1
    db.commit()
    return {"message": f"{copied} turno(s) copiado(s)", "copied": copied}


# ═══════════════════════════════════════════════
# EXPENSES / BUDGET TRACKING
# ═══════════════════════════════════════════════

@router.get("/expenses")
def list_expenses(
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """List all expenses, ordered by date desc."""
    sf, sp = store_filter(store_id, "e", user=user)
    rows = db.execute(
        "SELECT * FROM expenses e WHERE 1=1 " + sf + " ORDER BY expense_date DESC, id DESC",
        sp,
    ).fetchall()
    return {"expenses": [dict(r) for r in rows]}


@router.post("/expenses", status_code=201)
def create_expense(
    provider: str = Query(...),
    amount: float = Query(...),
    expense_date: str = Query(...),
    notes: str = Query(""),
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new expense entry."""
    cursor = db.execute(
        "INSERT INTO expenses (provider, amount, expense_date, notes, created_by, store_id) VALUES (?, ?, ?, ?, ?, ?)",
        (provider, amount, expense_date, notes, user["user_id"], store_id),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "Gasto registrado"}


@router.delete("/expenses/{expense_id}")
def delete_expense(
    expense_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Delete an expense entry."""
    existing = db.execute("SELECT id FROM expenses WHERE id = ?", (expense_id,)).fetchone()
    if not existing:
        raise HTTPException(status_code=404, detail="Expense not found")
    db.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
    db.commit()
    return {"message": "Gasto eliminado"}


# ═══════════════════════════════════════════════
# STORES MANAGEMENT (Admin)
# ═══════════════════════════════════════════════

@router.get("/stores")
def admin_list_stores(
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """List all stores with worker count."""
    rows = db.execute("""
        SELECT s.*, COUNT(ws.id) as worker_count
        FROM stores s
        LEFT JOIN worker_stores ws ON s.id = ws.store_id AND ws.active = 1
        GROUP BY s.id
        ORDER BY s.name
    """).fetchall()
    return {"stores": [dict(r) for r in rows]}


@router.post("/stores", status_code=201)
def create_store(
    name: str = Query(...),
    address: str = Query(""),
    phone: str = Query(""),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Create a new store."""
    cursor = db.execute(
        "INSERT INTO stores (name, address, phone) VALUES (?, ?, ?)",
        (name, address, phone),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": f"Tienda '{name}' creada"}


@router.put("/stores/{store_id}")
def update_store(
    store_id: int,
    name: str = Query(...),
    address: str = Query(""),
    phone: str = Query(""),
    active: int = Query(1),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update a store."""
    db.execute(
        "UPDATE stores SET name=?, address=?, phone=?, active=? WHERE id=?",
        (name, address, phone, active, store_id),
    )
    db.commit()
    return {"message": "Tienda actualizada"}


@router.delete("/stores/{store_id}")
def delete_store(
    store_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Deactivate a store."""
    db.execute("UPDATE stores SET active = 0 WHERE id = ?", (store_id,))
    db.commit()
    return {"message": "Tienda desactivada"}


# ═══════════════════════════════════════════════
# WORKER-STORE PIN MANAGEMENT (Admin)
# ═══════════════════════════════════════════════

@router.get("/workers/{worker_id}/pins")
def list_worker_pins(
    worker_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """List all PINs for a worker."""
    rows = db.execute("""
        SELECT ws.*, s.name as store_name
        FROM worker_stores ws
        JOIN stores s ON ws.store_id = s.id
        WHERE ws.worker_id = ?
        ORDER BY s.name
    """, (worker_id,)).fetchall()
    return {"pins": [dict(r) for r in rows]}


@router.post("/workers/{worker_id}/pins", status_code=201)
def create_worker_pin(
    worker_id: int,
    store_id: int = Query(...),
    pin: str = Query(..., min_length=4, max_length=6),
    is_primary: int = Query(0),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Assign a PIN to a worker for a specific store."""
    # Check if PIN already exists for this store
    existing = db.execute(
        "SELECT id FROM worker_stores WHERE pin = ? AND store_id = ?",
        (pin, store_id),
    ).fetchone()
    if existing:
        raise HTTPException(status_code=400, detail="Este PIN ya existe en esta tienda")

    cursor = db.execute(
        "INSERT INTO worker_stores (worker_id, store_id, pin, is_primary) VALUES (?, ?, ?, ?)",
        (worker_id, store_id, pin, is_primary),
    )
    db.commit()
    return {"id": cursor.lastrowid, "message": "PIN asignado"}


@router.put("/workers/{worker_id}/pins/{pin_id}")
def update_worker_pin(
    worker_id: int,
    pin_id: int,
    pin: str = Query(..., min_length=4, max_length=6),
    is_primary: int = Query(0),
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Update a worker PIN."""
    db.execute(
        "UPDATE worker_stores SET pin=?, is_primary=? WHERE id=? AND worker_id=?",
        (pin, is_primary, pin_id, worker_id),
    )
    db.commit()
    return {"message": "PIN actualizado"}


@router.delete("/workers/{worker_id}/pins/{pin_id}")
def delete_worker_pin(
    worker_id: int,
    pin_id: int,
    user: dict = Depends(require_role("admin", "manager")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Remove a worker PIN."""
    db.execute("DELETE FROM worker_stores WHERE id = ? AND worker_id = ?", (pin_id, worker_id))
    db.commit()
    return {"message": "PIN eliminado"}

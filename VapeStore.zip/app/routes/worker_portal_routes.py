"""Worker Portal routes — POS, Hours, Analytics."""
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List
import sqlite3
from datetime import datetime, timedelta, timezone
from app.database import get_db, rows_to_list
from app.auth import get_current_user, require_role

router = APIRouter(prefix="/api/worker", tags=["worker-portal"])


# ──────────────────────────────────────────────
# POS: Product Search & Scan
# ──────────────────────────────────────────────

@router.get("/products/search")
def search_products(
    q: str = Query("", min_length=1),
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Search products by name or barcode for POS."""
    sf = ""
    sp = []
    if store_id:
        sf = "AND si.store_id = ?"
        sp = [store_id]

    rows = db.execute(
        f"""SELECT po.id, po.name, po.price, po.barcode,
                   po.familia, po.image_url, po.nicotine_mg, po.puffs,
                   COALESCE(si.stock, 0) as stock,
                   pm.name as model_name, b.name as brand_name, c.name as category_name
            FROM product_options po
            LEFT JOIN store_inventory si ON po.id = si.product_option_id
            LEFT JOIN product_models pm ON po.product_model_id = pm.id
            LEFT JOIN brands b ON pm.brand_id = b.id
            LEFT JOIN categories c ON b.category_id = c.id
            WHERE po.active = 1
            AND (po.name LIKE ? OR po.barcode LIKE ? OR po.familia LIKE ? OR b.name LIKE ? OR pm.name LIKE ?)
            {sf}
            ORDER BY po.name
            LIMIT 30""",
        (f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%", f"%{q}%", *sp),
    ).fetchall()
    return {"products": rows_to_list(rows)}


@router.get("/products/scan/{barcode}")
def scan_barcode(
    barcode: str,
    store_id: Optional[int] = Query(None),
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Scan a barcode to get product details."""
    sf = ""
    sp = []
    if store_id:
        sf = "AND si.store_id = ?"
        sp = [store_id]

    row = db.execute(
        f"""SELECT po.id, po.name, po.price, po.barcode,
                   po.familia, po.image_url, po.nicotine_mg, po.puffs,
                   COALESCE(si.stock, 0) as stock,
                   pm.name as model_name, b.name as brand_name, c.name as category_name
            FROM product_options po
            LEFT JOIN store_inventory si ON po.id = si.product_option_id
            LEFT JOIN product_models pm ON po.product_model_id = pm.id
            LEFT JOIN brands b ON pm.brand_id = b.id
            LEFT JOIN categories c ON b.category_id = c.id
            WHERE po.active = 1 AND po.barcode = ?
            {sf}""",
        (barcode, *sp),
    ).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    return dict(row)


# ──────────────────────────────────────────────
# POS: Checkout / Sale
# ──────────────────────────────────────────────

class CartItem(BaseModel):
    product_option_id: int
    quantity: int = 1

class CheckoutRequest(BaseModel):
    items: List[CartItem]
    payment_method: str = "cash"  # cash | card | split
    tax_rate: float = 0.13  # 13% default (Canadian tax)
    customer_email: Optional[str] = None  # for points
    customer_name: Optional[str] = None  # customer name for tracking
    discount: float = 0.0
    split_cash: Optional[float] = None  # for split payments
    split_card: Optional[float] = None  # for split payments

@router.post("/pos/checkout")
def pos_checkout(
    req: CheckoutRequest,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Process a POS sale."""
    if not req.items:
        raise HTTPException(status_code=400, detail="Carrito vacío")

    # Disable FK constraints temporarily (order_items.product_id references product_options, not products)
    db.execute("PRAGMA foreign_keys=OFF")

    # Get worker's store
    ws = db.execute(
        "SELECT store_id FROM worker_stores WHERE worker_id = ? AND active = 1 LIMIT 1",
        (user["user_id"],),
    ).fetchone()
    store_id_val = ws["store_id"] if ws else None

    subtotal = 0
    sale_items = []

    for item in req.items:
        product = db.execute(
            "SELECT id, name, price FROM product_options WHERE id = ? AND active = 1",
            (item.product_option_id,),
        ).fetchone()
        if not product:
            raise HTTPException(status_code=404, detail=f"Producto {item.product_option_id} no encontrado")

        line_total = product["price"] * item.quantity
        subtotal += line_total
        sale_items.append({
            "product_option_id": product["id"],
            "product_name": product["name"],
            "quantity": item.quantity,
            "unit_price": product["price"],
            "line_total": round(line_total, 2),
        })

    tax = round(subtotal * req.tax_rate, 2)
    discount = round(req.discount, 2)
    total = round(subtotal + tax - discount, 2)

    # Create order
    store_id = db.execute(
        "SELECT store_id FROM worker_stores WHERE worker_id = ? AND active = 1 LIMIT 1",
        (user["user_id"],),
    ).fetchone()
    store_id_val = store_id["store_id"] if store_id else None

    cursor = db.execute(
        """INSERT INTO orders (worker_id, status, total, notes, store_id, created_at, updated_at)
           VALUES (?, 'paid', ?, ?, ?, ?, ?)""",
        (
            user["user_id"],
            total,
            f"POS Sale | {req.payment_method} | tax={tax} discount={discount}"
            + (f" | cash={req.split_cash} card={req.split_card}" if req.payment_method == 'split' else "")
            + (f" | cliente={req.customer_name}" if req.customer_name else ""),
            store_id_val,
            datetime.now().isoformat(),
            datetime.now().isoformat(),
        ),
    )
    order_id = cursor.lastrowid

    # Create order items and atomically reduce stock
    for si in sale_items:
        db.execute(
            """INSERT INTO order_items (order_id, product_id, quantity, unit_price, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (order_id, si["product_option_id"], si["quantity"], si["unit_price"], datetime.now().isoformat()),
        )
        # Atomic stock decrement — fails if insufficient stock
        if store_id_val:
            cur = db.execute(
                "UPDATE store_inventory SET stock = stock - ?, updated_at = datetime('now') WHERE stock >= ? AND product_option_id = ? AND store_id = ?",
                (si["quantity"], si["quantity"], si["product_option_id"], store_id_val),
            )
            if cur.rowcount != si["quantity"]:
                db.rollback()
                db.execute("PRAGMA foreign_keys=ON")
                raise HTTPException(status_code=400, detail=f"Stock insuficiente: {si['product_name']} (disponible: {si['quantity'] - cur.rowcount})")

    # Points system: 1 point per dollar spent
    points_earned = int(total)
    if req.customer_email:
        customer = db.execute("SELECT id FROM users WHERE email = ?", (req.customer_email,)).fetchone()
        if customer:
            db.execute(
                """INSERT INTO customer_points (customer_id, points, order_id, created_at)
                   VALUES (?, ?, ?, ?)""",
                (customer["id"], points_earned, order_id, datetime.now().isoformat()),
            )

    db.commit()
    db.execute("PRAGMA foreign_keys=ON")

    return {
        "order_id": order_id,
        "subtotal": subtotal,
        "tax": tax,
        "discount": discount,
        "total": total,
        "payment_method": req.payment_method,
        "points_earned": points_earned,
        "items": sale_items,
        "customer_name": req.customer_name,
        "message": "Venta procesada exitosamente",
    }


# ──────────────────────────────────────────────
# POS: Refund
# ──────────────────────────────────────────────

class RefundRequest(BaseModel):
    order_id: int
    reason: str = ""
    full_refund: bool = True

@router.post("/pos/refund")
def pos_refund(
    req: RefundRequest,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Process a refund for a completed order."""
    order = db.execute("SELECT * FROM orders WHERE id = ?", (req.order_id,)).fetchone()
    if not order:
        raise HTTPException(status_code=404, detail="Orden no encontrada")
    if order["status"] == "refunded":
        raise HTTPException(status_code=400, detail="Orden ya fue reembolsada")

    # Restore stock in store_inventory
    items = db.execute(
        "SELECT product_id, quantity FROM order_items WHERE order_id = ?",
        (req.order_id,),
    ).fetchall()
    # Get the store from the order
    store_id = order["store_id"]
    for item in items:
        if store_id:
            db.execute(
                "UPDATE store_inventory SET stock = stock + ?, updated_at = datetime('now') WHERE product_option_id = ? AND store_id = ?",
                (item["quantity"], item["product_id"], store_id),
            )

    # Mark as refunded
    db.execute(
        "UPDATE orders SET status = 'refunded', notes = notes || ?, updated_at = ? WHERE id = ?",
        (f"\nREFUND: {req.reason}", datetime.now().isoformat(), req.order_id),
    )

    # Revoke points if customer had them
    if order["worker_id"]:
        db.execute(
            "UPDATE customer_points SET points = -points WHERE order_id = ?",
            (req.order_id,),
        )

    db.commit()

    return {
        "order_id": req.order_id,
        "refund_amount": order["total"],
        "message": "Reembolso procesado",
    }


# ──────────────────────────────────────────────
# POS: Product-level Refund (scan products)
# ──────────────────────────────────────────────

class ProductRefundRequest(BaseModel):
    items: List[CartItem]
    reason: str = ""

@router.post("/pos/refund-items")
def pos_refund_items(
    req: ProductRefundRequest,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Process a product-level refund (scan items to refund)."""
    if not req.items:
        raise HTTPException(status_code=400, detail="Sin productos para reembolsar")

    db.execute("PRAGMA foreign_keys=OFF")

    # Get worker's store
    ws = db.execute(
        "SELECT store_id FROM worker_stores WHERE worker_id = ? AND active = 1 LIMIT 1",
        (user["user_id"],),
    ).fetchone()
    store_id_val = ws["store_id"] if ws else None

    subtotal = 0
    refund_items = []

    for item in req.items:
        product = db.execute(
            "SELECT id, name, price FROM product_options WHERE id = ? AND active = 1",
            (item.product_option_id,),
        ).fetchone()
        if not product:
            raise HTTPException(status_code=404, detail=f"Producto {item.product_option_id} no encontrado")

        line_total = product["price"] * item.quantity
        subtotal += line_total
        refund_items.append({
            "product_option_id": product["id"],
            "product_name": product["name"],
            "quantity": item.quantity,
            "unit_price": product["price"],
            "line_total": round(line_total, 2),
        })

    tax = round(subtotal * 0.13, 2)
    total = round(subtotal + tax, 2)

    # Create refund order
    cursor = db.execute(
        """INSERT INTO orders (worker_id, status, total, notes, store_id, created_at, updated_at)
           VALUES (?, 'refunded', ?, ?, ?, ?, ?)""",
        (
            user["user_id"],
            total,
            f"REFUND Items | {req.reason}" + (f" | cliente={req.reason}" if req.reason else ""),
            store_id_val,
            datetime.now().isoformat(),
            datetime.now().isoformat(),
        ),
    )
    order_id = cursor.lastrowid

    # Create order items and restore stock
    for ri in refund_items:
        db.execute(
            """INSERT INTO order_items (order_id, product_id, quantity, unit_price, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (order_id, ri["product_option_id"], ri["quantity"], ri["unit_price"], datetime.now().isoformat()),
        )
        # Restore stock in store_inventory
        if store_id_val:
            db.execute(
                "UPDATE store_inventory SET stock = stock + ?, updated_at = datetime('now') WHERE product_option_id = ? AND store_id = ?",
                (ri["quantity"], ri["product_option_id"], store_id_val),
            )

    db.commit()

    return {
        "order_id": order_id,
        "total": abs(total),
        "items": refund_items,
        "message": f"Reembolso de ${abs(total):.2f} procesado",
    }


# ──────────────────────────────────────────────
# POS: Recent sales (for receipt lookup)
# ──────────────────────────────────────────────

@router.get("/pos/recent-sales")
def recent_sales(
    limit: int = Query(20, le=50),
    store_id: Optional[int] = Query(None),
    status: Optional[str] = Query(None),  # 'paid', 'refunded', or None for all
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get recent sales for the worker."""
    sf = ""
    sp = []
    if store_id:
        sf = "AND o.store_id = ?"
        sp = [store_id]

    status_filter = ""
    if status:
        status_filter = "AND o.status = ?"
        sp.append(status)
    else:
        status_filter = "AND o.status IN ('paid', 'completed', 'refunded')"

    orders = db.execute(
        f"""SELECT o.id, o.total, o.status, o.notes, o.created_at,
                   u.name as worker_name
            FROM orders o
            LEFT JOIN users u ON o.worker_id = u.id
            WHERE o.worker_id = ? {status_filter}
            {sf}
            ORDER BY o.created_at DESC
            LIMIT ?""",
        (user["user_id"], *sp, limit),
    ).fetchall()

    return {"sales": rows_to_list(orders)}


@router.get("/pos/order/{order_id}")
def get_order_detail(
    order_id: int,
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get full order detail with items."""
    order = db.execute(
        """SELECT o.*, u.name as worker_name
           FROM orders o
           LEFT JOIN users u ON o.worker_id = u.id
           WHERE o.id = ?""",
        (order_id,),
    ).fetchone()
    if not order:
        raise HTTPException(status_code=404, detail="Orden no encontrada")

    items = db.execute(
        """SELECT oi.*, po.name as product_name
           FROM order_items oi
           LEFT JOIN product_options po ON oi.product_id = po.id
           WHERE oi.order_id = ?""",
        (order_id,),
    ).fetchall()

    return {
        "order": dict(order),
        "items": rows_to_list(items),
    }


# ──────────────────────────────────────────────
# Worker Hours
# ──────────────────────────────────────────────

@router.get("/shifts")
def get_my_shifts(
    start: Optional[str] = Query(None),
    end: Optional[str] = Query(None),
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get worker's shift history."""
    query = "SELECT * FROM work_shifts WHERE worker_id = ?"
    params = [user["user_id"]]

    if start:
        query += " AND clock_in >= ?"
        params.append(start)
    if end:
        query += " AND clock_in <= ?"
        params.append(end)

    query += " ORDER BY clock_in DESC LIMIT 100"
    shifts = db.execute(query, params).fetchall()

    result = []
    for s in shifts:
        d = dict(s)
        if d["clock_in"] and d["clock_out"]:
            ci = datetime.fromisoformat(d["clock_in"])
            co = datetime.fromisoformat(d["clock_out"])
            d["hours_worked"] = round((co - ci).total_seconds() / 3600, 2)
        else:
            d["hours_worked"] = None
        result.append(d)

    return {"shifts": result}


@router.post("/clock-in")
def clock_in(
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Clock in for a shift."""
    # Check if already clocked in (no clock_out)
    active = db.execute(
        "SELECT id FROM work_shifts WHERE worker_id = ? AND clock_out IS NULL",
        (user["user_id"],),
    ).fetchone()
    if active:
        raise HTTPException(status_code=400, detail="Ya estás registrado. Haz clock-out primero.")

    store_id = db.execute(
        "SELECT store_id FROM worker_stores WHERE worker_id = ? AND active = 1 LIMIT 1",
        (user["user_id"],),
    ).fetchone()
    store_id_val = store_id["store_id"] if store_id else None

    now = datetime.now().isoformat()
    cursor = db.execute(
        "INSERT INTO work_shifts (worker_id, clock_in, store_id, created_at) VALUES (?, ?, ?, ?)",
        (user["user_id"], now, store_id_val, now),
    )
    db.commit()
    return {"shift_id": cursor.lastrowid, "clock_in": now, "message": "Clock-in registrado"}


@router.post("/clock-out")
def clock_out(
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Clock out from current shift."""
    active = db.execute(
        "SELECT id, clock_in FROM work_shifts WHERE worker_id = ? AND clock_out IS NULL",
        (user["user_id"],),
    ).fetchone()
    if not active:
        raise HTTPException(status_code=400, detail="No tienes un turno activo")

    now = datetime.now()
    ci = datetime.fromisoformat(active["clock_in"])
    hours = round((now - ci).total_seconds() / 3600, 2)

    db.execute(
        "UPDATE work_shifts SET clock_out = ? WHERE id = ?",
        (now.isoformat(), active["id"]),
    )
    db.commit()
    return {"shift_id": active["id"], "hours_worked": hours, "message": f"Turno finalizado: {hours}h"}


@router.get("/shifts/summary")
def shifts_summary(
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get weekly/monthly hours summary."""
    now = datetime.now()
    week_start = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0)
    month_start = now.replace(day=1, hour=0, minute=0, second=0)

    # This week
    week_shifts = db.execute(
        "SELECT clock_in, clock_out FROM work_shifts WHERE worker_id = ? AND clock_in >= ?",
        (user["user_id"], week_start.isoformat()),
    ).fetchall()
    week_hours = 0
    for s in week_shifts:
        if s["clock_in"] and s["clock_out"]:
            ci = datetime.fromisoformat(s["clock_in"])
            co = datetime.fromisoformat(s["clock_out"])
            week_hours += (co - ci).total_seconds() / 3600

    # This month
    month_shifts = db.execute(
        "SELECT clock_in, clock_out FROM work_shifts WHERE worker_id = ? AND clock_in >= ?",
        (user["user_id"], month_start.isoformat()),
    ).fetchall()
    month_hours = 0
    for s in month_shifts:
        if s["clock_in"] and s["clock_out"]:
            ci = datetime.fromisoformat(s["clock_in"])
            co = datetime.fromisoformat(s["clock_out"])
            month_hours += (co - ci).total_seconds() / 3600

    # Today
    today_start = now.replace(hour=0, minute=0, second=0)
    today_shifts = db.execute(
        "SELECT clock_in, clock_out FROM work_shifts WHERE worker_id = ? AND clock_in >= ?",
        (user["user_id"], today_start.isoformat()),
    ).fetchall()
    today_hours = 0
    for s in today_shifts:
        if s["clock_in"] and s["clock_out"]:
            ci = datetime.fromisoformat(s["clock_in"])
            co = datetime.fromisoformat(s["clock_out"])
            today_hours += (co - ci).total_seconds() / 3600

    return {
        "today_hours": round(today_hours, 2),
        "week_hours": round(week_hours, 2),
        "month_hours": round(month_hours, 2),
        "today_shifts": len(today_shifts),
        "week_shifts": len(week_shifts),
        "month_shifts": len(month_shifts),
    }


# ──────────────────────────────────────────────
# Worker Analytics
# ──────────────────────────────────────────────

@router.get("/analytics")
def my_analytics(
    user: dict = Depends(require_role("admin", "worker")),
    db: sqlite3.Connection = Depends(get_db),
):
    """Get worker's personal sales analytics."""
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    week_ago = (now - timedelta(days=7)).strftime("%Y-%m-%d")
    month_ago = (now - timedelta(days=30)).strftime("%Y-%m-%d")

    # Today
    today_stats = db.execute(
        "SELECT COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue FROM orders WHERE worker_id = ? AND DATE(created_at) = ? AND status IN ('paid', 'completed')",
        (user["user_id"], today),
    ).fetchone()

    # This week
    week_stats = db.execute(
        "SELECT COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue FROM orders WHERE worker_id = ? AND DATE(created_at) >= ? AND status IN ('paid', 'completed')",
        (user["user_id"], week_ago),
    ).fetchone()

    # This month
    month_stats = db.execute(
        "SELECT COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue FROM orders WHERE worker_id = ? AND DATE(created_at) >= ? AND status IN ('paid', 'completed')",
        (user["user_id"], month_ago),
    ).fetchone()

    # All time
    all_stats = db.execute(
        "SELECT COUNT(*) as orders, COALESCE(SUM(total), 0) as revenue FROM orders WHERE worker_id = ? AND status IN ('paid', 'completed')",
        (user["user_id"],),
    ).fetchone()

    # Refunds
    refunds = db.execute(
        "SELECT COUNT(*) as count, COALESCE(SUM(total), 0) as amount FROM orders WHERE worker_id = ? AND status = 'refunded'",
        (user["user_id"],),
    ).fetchone()

    # Top products sold by this worker
    top_products = db.execute(
        """SELECT po.name, SUM(oi.quantity) as qty, SUM(oi.unit_price * oi.quantity) as revenue
           FROM order_items oi
           JOIN orders o ON oi.order_id = o.id
           JOIN product_options po ON oi.product_id = po.id
           WHERE o.worker_id = ? AND o.status IN ('paid', 'completed')
           GROUP BY oi.product_id
           ORDER BY qty DESC
           LIMIT 10""",
        (user["user_id"],),
    ).fetchall()

    # Sales by day (last 30 days)
    sales_chart = db.execute(
        """SELECT DATE(created_at) as day, COUNT(*) as orders, SUM(total) as revenue
           FROM orders
           WHERE worker_id = ? AND DATE(created_at) >= DATE('now', '-30 days')
           AND status IN ('paid', 'completed')
           GROUP BY DATE(created_at)
           ORDER BY day""",
        (user["user_id"],),
    ).fetchall()

    # Payment method breakdown
    payment_methods = db.execute(
        """SELECT
            CASE WHEN notes LIKE '%split%' THEN 'Mixto'
                 WHEN notes LIKE '%card%' THEN 'Tarjeta'
                 WHEN notes LIKE '%cash%' THEN 'Efectivo'
                 ELSE 'Otro' END as method,
            COUNT(*) as count, SUM(total) as total
           FROM orders WHERE worker_id = ? AND status IN ('paid', 'completed')
           GROUP BY method""",
        (user["user_id"],),
    ).fetchall()

    return {
        "today": dict(today_stats),
        "week": dict(week_stats),
        "month": dict(month_stats),
        "all_time": dict(all_stats),
        "refunds": dict(refunds),
        "top_products": rows_to_list(top_products),
        "sales_chart": rows_to_list(sales_chart),
        "payment_methods": rows_to_list(payment_methods),
    }

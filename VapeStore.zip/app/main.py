"""VapeStore MVP - Main application."""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware
from app.database import init_db
from app.routes import auth_routes, product_routes, order_routes, admin_routes, catalog_routes, worker_portal_routes
import os

@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    yield

app = FastAPI(
    title="VapeStore",
    description="Vape Store Management Platform - MVP",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_routes.router)
app.include_router(product_routes.router)
app.include_router(order_routes.router)
app.include_router(admin_routes.router)
app.include_router(catalog_routes.router)
app.include_router(worker_portal_routes.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "app": "VapeStore", "version": "1.0.0"}


static_dir = os.path.join(os.path.dirname(__file__), "static")
app.mount("/static", StaticFiles(directory=static_dir), name="static")


@app.get("/")
def serve_index():
    return FileResponse(os.path.join(static_dir, "index.html"))


@app.get("/login")
def serve_login():
    return FileResponse(os.path.join(static_dir, "login.html"))


@app.get("/register")
def serve_register():
    return FileResponse(os.path.join(static_dir, "register.html"))


@app.get("/catalog")
def serve_catalog():
    return FileResponse(os.path.join(static_dir, "catalog.html"))


@app.get("/worker")
def serve_worker():
    return FileResponse(os.path.join(static_dir, "worker.html"))


@app.get("/admin")
def serve_admin():
    return FileResponse(os.path.join(static_dir, "admin.html"))


@app.get("/admin/inventory")
def serve_inventory():
    return FileResponse(os.path.join(static_dir, "inventory.html"))


@app.get("/admin/stock")
def serve_stock():
    return FileResponse(os.path.join(static_dir, "stock.html"))


@app.get("/admin/orders")
def serve_orders():
    return FileResponse(os.path.join(static_dir, "orders.html"))


@app.get("/admin/workers")
def serve_workers():
    return FileResponse(os.path.join(static_dir, "workers.html"))


@app.get("/admin/expenses")
def serve_expenses():
    return FileResponse(os.path.join(static_dir, "expenses.html"))


@app.get("/admin/stores")
def serve_stores():
    return FileResponse(os.path.join(static_dir, "stores.html"))


@app.get("/pin-login")
def serve_pin_login():
    return FileResponse(os.path.join(static_dir, "pin-login.html"))


@app.get("/portal")
def serve_portal():
    return FileResponse(os.path.join(static_dir, "portal.html"))

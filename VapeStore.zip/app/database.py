"""Database setup and models for VapeStore MVP."""
import sqlite3
import os
from datetime import datetime

DB_PATH = os.environ.get("DB_PATH", "/app/data/vapestore.db")


def get_db():
    """Get database connection."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
    finally:
        conn.close()


def row_to_dict(row):
    """Convert Row to dict."""
    if row is None:
        return None
    return dict(row)


def rows_to_list(rows):
    """Convert list of Rows to list of dicts."""
    return [dict(r) for r in rows]


def init_db():
    """Initialize database with all tables."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        -- Users table (clients, workers, admins)
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('client', 'worker', 'admin', 'manager')),
            phone TEXT,
            active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Product categories
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            icon TEXT,
            sort_order INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1
        );

        -- Brands (per category)
        CREATE TABLE IF NOT EXISTS brands (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category_id INTEGER REFERENCES categories(id),
            logo_url TEXT,
            active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(name, category_id)
        );

        -- Product models (second level under brand)
        CREATE TABLE IF NOT EXISTS product_models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            brand_id INTEGER REFERENCES brands(id),
            description TEXT,
            image_url TEXT,
            active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Product options (third level - flavors, sizes, variants)
        CREATE TABLE IF NOT EXISTS product_options (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            product_model_id INTEGER REFERENCES product_models(id),
            option_type TEXT DEFAULT 'flavor',
            price REAL DEFAULT 0,
            stock INTEGER DEFAULT 0,
            barcode TEXT UNIQUE,
            active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Products
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT,
            category_id INTEGER REFERENCES categories(id),
            brand_id INTEGER REFERENCES brands(id),
            model_id INTEGER REFERENCES product_models(id),
            option_id INTEGER REFERENCES product_options(id),
            barcode TEXT UNIQUE,
            image_url TEXT,
            price REAL NOT NULL DEFAULT 0,
            stock INTEGER NOT NULL DEFAULT 0,
            min_stock INTEGER DEFAULT 5,
            active INTEGER DEFAULT 1,
            out_of_service INTEGER DEFAULT 0,
            options TEXT,  -- JSON: flavors, nicotine, sizes
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Offers / Promotions
        CREATE TABLE IF NOT EXISTS offers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER REFERENCES products(id),
            name TEXT NOT NULL,
            discount_type TEXT NOT NULL CHECK(discount_type IN ('percent', 'fixed')),
            value REAL NOT NULL,
            start_date TEXT,
            end_date TEXT,
            active INTEGER DEFAULT 1
        );

        -- Orders
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            client_id INTEGER REFERENCES users(id),
            worker_id INTEGER REFERENCES users(id),
            status TEXT NOT NULL DEFAULT 'pending'
                CHECK(status IN ('pending', 'confirmed', 'paid', 'completed', 'cancelled', 'refunded')),
            total REAL DEFAULT 0,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Order items
        CREATE TABLE IF NOT EXISTS order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER REFERENCES orders(id),
            product_id INTEGER REFERENCES products(id),
            quantity INTEGER NOT NULL DEFAULT 1,
            unit_price REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Sales summary view (for admin reports)
        CREATE VIEW IF NOT EXISTS daily_sales AS
        SELECT
            DATE(created_at) as sale_date,
            COUNT(*) as total_orders,
            SUM(total) as total_revenue,
            COUNT(DISTINCT client_id) as unique_clients
        FROM orders
        WHERE status IN ('paid', 'completed')
        GROUP BY DATE(created_at);
    """)

    # ─── Migration: add columns for existing databases ──────
    for col in ["brand_id", "model_id", "option_id"]:
        try:
            conn.execute(f"ALTER TABLE products ADD COLUMN {col} INTEGER")
        except:
            pass
    # Migration: add puffs column to product_options
    try:
        conn.execute("ALTER TABLE product_options ADD COLUMN puffs TEXT DEFAULT ''")
    except:
        pass
    # Migration: purchase orders tables
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS purchase_orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vendor_name TEXT NOT NULL,
            reference TEXT DEFAULT '',
            status TEXT DEFAULT 'pending' CHECK(status IN ('pending','ordered','received','completed','cancelled')),
            created_by INTEGER,
            notes TEXT DEFAULT '',
            shipping_cost REAL DEFAULT 0,
            discount REAL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS purchase_order_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            po_id INTEGER REFERENCES purchase_orders(id) ON DELETE CASCADE,
            product_id INTEGER,  -- references product_options, not products
            product_name TEXT NOT NULL,
            quantity INTEGER NOT NULL DEFAULT 1,
            unit_cost REAL DEFAULT 0,
            retail_price REAL DEFAULT 0,
            received_qty INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    except:
        pass

    # ─── Stock Counts (historial de conteos de inventario) ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS stock_counts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_by INTEGER REFERENCES users(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS stock_count_items (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            count_id INTEGER REFERENCES stock_counts(id) ON DELETE CASCADE,
            product_option_id INTEGER,
            product_name TEXT NOT NULL,
            brand_name TEXT DEFAULT '',
            model_name TEXT DEFAULT '',
            old_stock INTEGER DEFAULT 0,
            new_stock INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    except:
        pass

    # ─── Work Shifts (control de horas) ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS work_shifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER REFERENCES users(id),
            clock_in TIMESTAMP NOT NULL,
            clock_out TIMESTAMP,
            notes TEXT DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    except:
        pass

    # ─── Scheduled Shifts (programación de horarios) ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS scheduled_shifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER REFERENCES users(id),
            date TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_by INTEGER REFERENCES users(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    except:
        pass
    conn.commit()

    # ─── Expenses / Budget tracking ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            provider TEXT NOT NULL,
            amount REAL NOT NULL,
            expense_date TEXT NOT NULL,
            notes TEXT DEFAULT '',
            created_by INTEGER REFERENCES users(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    except:
        pass
    conn.commit()

    # ═══════════════════════════════════════════════
    # CLEAN MIGRATION: Remove seed catalog data
    # ═══════════════════════════════════════════════
    # Wipe seed brands/models/options — user will add their own via admin
    try:
        conn.execute("DELETE FROM product_options")
        conn.execute("DELETE FROM product_models")
        conn.execute("DELETE FROM brands")
        conn.commit()
    except:
        pass

    # ═══════════════════════════════════════════════
    # MULTI-STORE MIGRATION
    # ═══════════════════════════════════════════════

    # ─── Stores table ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS stores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            address TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    except:
        pass

    # ─── Worker-Store assignments with PINs ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS worker_stores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER REFERENCES users(id),
            store_id INTEGER REFERENCES stores(id),
            pin TEXT NOT NULL,
            is_primary INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(pin, store_id)
        )""")
    except:
        pass

    # ─── Add store_id to orders ──
    try:
        conn.execute("ALTER TABLE orders ADD COLUMN store_id INTEGER REFERENCES stores(id)")
    except:
        pass

    # ─── Add store_id to expenses ──
    try:
        conn.execute("ALTER TABLE expenses ADD COLUMN store_id INTEGER REFERENCES stores(id)")
    except:
        pass

    # ─── Add store_id to work_shifts ──
    try:
        conn.execute("ALTER TABLE work_shifts ADD COLUMN store_id INTEGER REFERENCES stores(id)")
    except:
        pass

    # ─── Add store_id to scheduled_shifts ──
    try:
        conn.execute("ALTER TABLE scheduled_shifts ADD COLUMN store_id INTEGER REFERENCES stores(id)")
    except:
        pass

    # ─── Add store_id to stock_counts ──
    try:
        conn.execute("ALTER TABLE stock_counts ADD COLUMN store_id INTEGER REFERENCES stores(id)")
    except:
        pass

    # ─── Add store_id to purchase_orders ──
    try:
        conn.execute("ALTER TABLE purchase_orders ADD COLUMN store_id INTEGER REFERENCES stores(id)")
    except:
        pass

    # ─── Add store_id to product_options (per-store stock) ──
    try:
        conn.execute("ALTER TABLE product_options ADD COLUMN store_id INTEGER REFERENCES stores(id)")
    except:
        pass

    # ─── Customer points system ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS customer_points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER REFERENCES users(id),
            points INTEGER NOT NULL,
            order_id INTEGER REFERENCES orders(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
    except:
        pass

    # ─── Store inventory (stock per store per product) ──
    try:
        conn.execute("""CREATE TABLE IF NOT EXISTS store_inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_option_id INTEGER,
            store_id INTEGER,
            stock INTEGER DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(product_option_id, store_id)
        )""")
    except:
        pass

    # ─── Migrate existing stock to store_inventory ──
    try:
        # Check if store_inventory is empty
        count = conn.execute("SELECT COUNT(*) FROM store_inventory").fetchone()[0]
        if count == 0:
            # Copy stock from product_options to store_inventory for each store
            conn.execute("""
                INSERT OR IGNORE INTO store_inventory (product_option_id, store_id, stock, updated_at)
                SELECT po.id, s.id, po.stock, datetime('now')
                FROM product_options po
                CROSS JOIN stores s
                WHERE po.active = 1
            """)
            # Also create entries for products without store_id (global stock → all stores)
            conn.execute("""
                INSERT OR IGNORE INTO store_inventory (product_option_id, store_id, stock, updated_at)
                SELECT po.id, s.id, po.stock, datetime('now')
                FROM product_options po
                CROSS JOIN stores s
                WHERE po.active = 1 AND po.store_id IS NULL
            """)
    except:
        pass

    conn.commit()

    # ─── Migrate users table to add 'manager' role ──
    try:
        # Check current CHECK constraint
        info = conn.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='users'").fetchone()
        if info and "'manager'" not in info[0]:
            # Recreate table with updated CHECK constraint
            conn.execute("PRAGMA foreign_keys = OFF")
            conn.execute("BEGIN TRANSACTION")
            conn.execute("CREATE TABLE users_new (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('client', 'worker', 'admin', 'manager')), phone TEXT, active INTEGER DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
            conn.execute("INSERT INTO users_new SELECT * FROM users")
            conn.execute("DROP TABLE users")
            conn.execute("ALTER TABLE users_new RENAME TO users")
            conn.execute("COMMIT")
            conn.execute("PRAGMA foreign_keys = ON")
    except:
        pass

    conn.commit()

    # ─── Seed 3 demo stores (only if empty) ──
    store_count = conn.execute("SELECT COUNT(*) FROM stores").fetchone()[0]
    if store_count == 0:
        demo_stores = [
            ("Tienda Centro", "Av. Principal 123, Centro", "+1 555-0101"),
            ("Tienda Norte", "Blvd. Norte 456, Zona Norte", "+1 555-0102"),
            ("Tienda Sur", "Calle Sur 789, Zona Sur", "+1 555-0103"),
        ]
        for name, addr, phone in demo_stores:
            conn.execute(
                "INSERT INTO stores (name, address, phone) VALUES (?, ?, ?)",
                (name, addr, phone),
            )
        conn.commit()

    conn.close()

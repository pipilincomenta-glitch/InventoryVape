"""Pydantic schemas for request/response validation."""
from pydantic import BaseModel, Field, EmailStr
from typing import Optional, List
from datetime import date, datetime


# ─── Auth ─────────────────────────────────────
class UserCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: str = Field(..., max_length=200)
    password: str = Field(..., min_length=6)
    role: str = Field(default="client", pattern="^(client|worker|admin|manager)$")
    phone: Optional[str] = None


class UserLogin(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


# ─── Products ─────────────────────────────────
class ProductCreate(BaseModel):
    name: Optional[str] = None  # Auto-generated if not provided
    description: Optional[str] = None
    category_id: Optional[int] = None
    brand_id: Optional[int] = None
    model_id: Optional[int] = None
    option_id: Optional[int] = None
    barcode: Optional[str] = None
    image_url: Optional[str] = None
    price: float = Field(default=0, ge=0)
    stock: int = Field(default=0, ge=0)
    min_stock: int = Field(default=5, ge=0)
    options: Optional[str] = None  # JSON string


class ProductUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category_id: Optional[int] = None
    barcode: Optional[str] = None
    image_url: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None
    min_stock: Optional[int] = None
    active: Optional[bool] = None
    out_of_service: Optional[bool] = None
    options: Optional[str] = None


class ProductResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    category_id: Optional[int]
    barcode: Optional[str]
    image_url: Optional[str]
    stock: int
    active: int
    out_of_service: int
    options: Optional[str]
    has_offer: bool = False
    offer_name: Optional[str] = None


# ─── Categories ───────────────────────────────
class CategoryCreate(BaseModel):
    name: str = Field(..., max_length=100)
    description: Optional[str] = None
    icon: Optional[str] = None
    sort_order: int = 0


# ─── Brands ───────────────────────────────────
class BrandCreate(BaseModel):
    name: str = Field(..., max_length=100)
    category_id: int
    logo_url: Optional[str] = None


class BrandUpdate(BaseModel):
    name: Optional[str] = None
    logo_url: Optional[str] = None
    active: Optional[bool] = None


# ─── Product Models ───────────────────────────
class ModelCreate(BaseModel):
    name: str = Field(..., max_length=150)
    brand_id: int
    description: Optional[str] = None
    image_url: Optional[str] = None


class ModelUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    image_url: Optional[str] = None
    active: Optional[bool] = None


# ─── Product Options ──────────────────────────
class OptionCreate(BaseModel):
    name: str = Field(..., max_length=150)
    product_model_id: int
    option_type: str = Field(default="flavor", max_length=50)
    price: float = Field(default=0, ge=0)
    stock: int = Field(default=0, ge=0)
    barcode: Optional[str] = None
    familia: Optional[str] = ""
    image_url: Optional[str] = ""
    nicotine_mg: Optional[str] = ""
    device_type: Optional[str] = ""
    cart_type: Optional[str] = ""
    puffs: Optional[str] = ""
    ohm: Optional[str] = ""
    description: Optional[str] = ""


class OptionUpdate(BaseModel):
    name: Optional[str] = None
    option_type: Optional[str] = None
    price: Optional[float] = None
    stock: Optional[int] = None
    barcode: Optional[str] = None
    familia: Optional[str] = None
    image_url: Optional[str] = None
    nicotine_mg: Optional[str] = None
    device_type: Optional[str] = None
    cart_type: Optional[str] = None
    puffs: Optional[str] = None
    ohm: Optional[str] = None
    description: Optional[str] = None
    active: Optional[bool] = None


# ─── Orders ───────────────────────────────────
class OrderItemCreate(BaseModel):
    product_id: int
    quantity: int = Field(default=1, ge=1)


class OrderCreate(BaseModel):
    items: List[OrderItemCreate]
    notes: Optional[str] = None


class OrderConfirm(BaseModel):
    worker_id: int


# ─── Offers ───────────────────────────────────
class OfferCreate(BaseModel):
    product_id: int
    name: str = Field(..., max_length=200)
    discount_type: str = Field(..., pattern="^(percent|fixed)$")
    value: float = Field(..., gt=0)
    start_date: Optional[str] = None
    end_date: Optional[str] = None


# ─── Dashboard (Admin) ───────────────────────
class SalesSummary(BaseModel):
    total_orders: int
    total_revenue: float
    unique_clients: int
    avg_order_value: float


class TopProduct(BaseModel):
    product_id: int
    product_name: str
    total_sold: int
    total_revenue: float

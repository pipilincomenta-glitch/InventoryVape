import requests, json

BASE = "http://localhost:8093"

# Login as admin
r = requests.post(f"{BASE}/api/auth/login", json={"email":"admin@vape.com","password":"admin123"})
token = r.json()["access_token"]
print(f"Token: {token[:20]}...")
headers = {"Authorization": f"Bearer {token}"}

# Assign PIN 1234 to worker 5 (Juan) for store 1 (Tienda Centro)
r = requests.post(f"{BASE}/api/admin/workers/5/pins?store_id=1&pin=1234&is_primary=1", headers=headers)
print(f"PIN assign: {r.status_code} {r.json()}")

# Test PIN login
r = requests.post(f"{BASE}/api/auth/pin-login?pin=1234")
print(f"PIN login: {r.status_code} {json.dumps(r.json(), indent=2)}")
